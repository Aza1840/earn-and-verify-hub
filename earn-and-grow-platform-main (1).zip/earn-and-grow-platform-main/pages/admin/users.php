
<?php
// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: index.php?page=admin-login");
    exit;
}

// Get users
$sql = "SELECT * FROM users WHERE role = 'user' ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<div class="row">
    <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar">
        <?php include 'pages/admin/sidebar.php'; ?>
    </div>
    <div class="col-md-9 col-lg-10">
        <div class="p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="h3 mb-0">Manage Users</h1>
                <a href="index.php?page=admin&section=users&action=add" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Add New User
                </a>
            </div>

            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">User List</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="usersTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Premium</th>
                                    <th>Balance</th>
                                    <th>Joined</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $balance = getUserBalance($row['id']);
                                        echo '<tr>';
                                        echo '<td>' . $row['id'] . '</td>';
                                        echo '<td>' . htmlspecialchars($row['username']) . '</td>';
                                        echo '<td>' . htmlspecialchars($row['email']) . '</td>';
                                        echo '<td>' . ($row['is_premium'] ? '<span class="badge bg-warning">Premium</span>' : 'No') . '</td>';
                                        echo '<td>' . $balance . ' credits</td>';
                                        echo '<td>' . date('Y-m-d', strtotime($row['created_at'])) . '</td>';
                                        echo '<td><span class="badge bg-success">Active</span></td>';
                                        echo '<td>';
                                        echo '<a href="index.php?page=admin&section=users&action=edit&id=' . $row['id'] . '" class="btn btn-sm btn-primary me-2"><i class="fas fa-edit"></i></a>';
                                        echo '<a href="index.php?page=admin&section=users&action=delete&id=' . $row['id'] . '" class="btn btn-sm btn-danger" onclick="return confirm(\'Are you sure you want to delete this user?\');"><i class="fas fa-trash"></i></a>';
                                        echo '</td>';
                                        echo '</tr>';
                                    }
                                } else {
                                    echo '<tr><td colspan="8" class="text-center">No users found</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize datatable
    if (typeof $.fn.DataTable !== 'undefined') {
        $('#usersTable').DataTable({
            order: [[0, 'desc']]
        });
    }
});
</script>

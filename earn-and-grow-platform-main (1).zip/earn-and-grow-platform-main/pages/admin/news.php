
<?php
// Check if admin is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: index.php?page=admin-login");
    exit;
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                // Process add news
                $title = clean_input($_POST['title']);
                $description = clean_input($_POST['description']);
                $content = $_POST['content']; // Using HTML editor, so don't clean
                $reward = intval($_POST['reward']);
                $status = clean_input($_POST['status']);
                
                // Handle thumbnail upload
                $thumbnail = '';
                if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0) {
                    $target_dir = "uploads/news/";
                    if (!file_exists($target_dir)) {
                        mkdir($target_dir, 0777, true);
                    }
                    
                    $file_extension = strtolower(pathinfo($_FILES['thumbnail']['name'], PATHINFO_EXTENSION));
                    $newFileName = uniqid() . '.' . $file_extension;
                    $target_file = $target_dir . $newFileName;
                    
                    // Check if image file is an actual image
                    $check = getimagesize($_FILES['thumbnail']['tmp_name']);
                    if ($check !== false && move_uploaded_file($_FILES['thumbnail']['tmp_name'], $target_file)) {
                        $thumbnail = $target_file;
                    }
                }
                
                // Insert into database
                $sql = "INSERT INTO tasks (title, description, type, url, content, reward, thumbnail, status, created_at) 
                        VALUES (?, ?, 'news', ?, ?, ?, ?, ?, NOW())";
                $stmt = $conn->prepare($sql);
                $url = 'news/' . strtolower(str_replace(' ', '-', $title));
                $stmt->bind_param("sssssis", $title, $description, $url, $content, $reward, $thumbnail, $status);
                
                if ($stmt->execute()) {
                    $_SESSION['message'] = "News article added successfully.";
                    $_SESSION['message_type'] = "success";
                } else {
                    $_SESSION['message'] = "Error adding news article: " . $conn->error;
                    $_SESSION['message_type'] = "danger";
                }
                break;
                
            case 'edit':
                // Process edit news
                $id = intval($_POST['id']);
                $title = clean_input($_POST['title']);
                $description = clean_input($_POST['description']);
                $content = $_POST['content']; // Using HTML editor, so don't clean
                $reward = intval($_POST['reward']);
                $status = clean_input($_POST['status']);
                
                // Handle thumbnail upload if new file selected
                if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0) {
                    $target_dir = "uploads/news/";
                    if (!file_exists($target_dir)) {
                        mkdir($target_dir, 0777, true);
                    }
                    
                    $file_extension = strtolower(pathinfo($_FILES['thumbnail']['name'], PATHINFO_EXTENSION));
                    $newFileName = uniqid() . '.' . $file_extension;
                    $target_file = $target_dir . $newFileName;
                    
                    // Check if image file is an actual image
                    $check = getimagesize($_FILES['thumbnail']['tmp_name']);
                    if ($check !== false && move_uploaded_file($_FILES['thumbnail']['tmp_name'], $target_file)) {
                        // Get old thumbnail to delete
                        $sql = "SELECT thumbnail FROM tasks WHERE id = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("i", $id);
                        $stmt->execute();
                        $oldThumbnail = $stmt->get_result()->fetch_assoc()['thumbnail'] ?? '';
                        
                        // Update with new thumbnail
                        $sql = "UPDATE tasks SET title = ?, description = ?, content = ?, reward = ?, thumbnail = ?, status = ? WHERE id = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("sssissi", $title, $description, $content, $reward, $target_file, $status, $id);
                        
                        if ($stmt->execute()) {
                            // Delete old thumbnail if it exists
                            if (!empty($oldThumbnail) && file_exists($oldThumbnail)) {
                                unlink($oldThumbnail);
                            }
                            
                            $_SESSION['message'] = "News article updated successfully.";
                            $_SESSION['message_type'] = "success";
                        } else {
                            $_SESSION['message'] = "Error updating news article: " . $conn->error;
                            $_SESSION['message_type'] = "danger";
                        }
                    } else {
                        $_SESSION['message'] = "Error uploading thumbnail.";
                        $_SESSION['message_type'] = "danger";
                    }
                } else {
                    // No new thumbnail, just update other fields
                    $sql = "UPDATE tasks SET title = ?, description = ?, content = ?, reward = ?, status = ? WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("sssisi", $title, $description, $content, $reward, $status, $id);
                    
                    if ($stmt->execute()) {
                        $_SESSION['message'] = "News article updated successfully.";
                        $_SESSION['message_type'] = "success";
                    } else {
                        $_SESSION['message'] = "Error updating news article: " . $conn->error;
                        $_SESSION['message_type'] = "danger";
                    }
                }
                break;
                
            case 'delete':
                // Process delete news
                $id = intval($_POST['id']);
                
                // Get thumbnail path to delete file
                $sql = "SELECT thumbnail FROM tasks WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $thumbnail = $stmt->get_result()->fetch_assoc()['thumbnail'] ?? '';
                
                // Delete from database
                $sql = "DELETE FROM tasks WHERE id = ? AND type = 'news'";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $id);
                
                if ($stmt->execute()) {
                    // Delete thumbnail file if it exists
                    if (!empty($thumbnail) && file_exists($thumbnail)) {
                        unlink($thumbnail);
                    }
                    
                    $_SESSION['message'] = "News article deleted successfully.";
                    $_SESSION['message_type'] = "success";
                } else {
                    $_SESSION['message'] = "Error deleting news article: " . $conn->error;
                    $_SESSION['message_type'] = "danger";
                }
                break;
        }
        
        // Redirect to avoid form resubmission
        header("Location: index.php?page=admin&section=news");
        exit;
    }
}

// Get action from URL
$action = isset($_GET['action']) ? $_GET['action'] : '';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Get news article if editing
$editingNews = null;
if ($action === 'edit' && $id > 0) {
    $sql = "SELECT * FROM tasks WHERE id = ? AND type = 'news'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $editingNews = $stmt->get_result()->fetch_assoc();
    
    if (!$editingNews) {
        $_SESSION['message'] = "News article not found.";
        $_SESSION['message_type'] = "danger";
        header("Location: index.php?page=admin&section=news");
        exit;
    }
}

// Get all news articles for listing
$sql = "SELECT * FROM tasks WHERE type = 'news' ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<div class="row">
    <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar">
        <?php include 'pages/admin/sidebar.php'; ?>
    </div>
    
    <div class="col-md-9 col-lg-10">
        <div class="container-fluid py-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0"><?php echo $action === 'edit' ? 'Edit' : ($action === 'add' ? 'Add' : 'Manage'); ?> News Articles</h1>
                    <p class="text-muted">
                        <?php echo $action === 'edit' ? 'Edit an existing news article' : ($action === 'add' ? 'Add a new news article' : 'Manage news articles and tasks'); ?>
                    </p>
                </div>
                <?php if (!in_array($action, ['add', 'edit'])): ?>
                <a href="index.php?page=admin&section=news&action=add" class="btn btn-primary">
                    <i class="fas fa-plus-circle me-2"></i> Add News Article
                </a>
                <?php endif; ?>
            </div>
            
            <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-<?php echo $_SESSION['message_type']; ?> alert-dismissible fade show">
                <?php echo $_SESSION['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['message']); unset($_SESSION['message_type']); endif; ?>
            
            <?php if (in_array($action, ['add', 'edit'])): ?>
                <!-- Add/Edit Form -->
                <div class="card mb-4">
                    <div class="card-body">
                        <form method="post" action="index.php?page=admin&section=news" enctype="multipart/form-data">
                            <input type="hidden" name="action" value="<?php echo $action; ?>">
                            <?php if ($action === 'edit'): ?>
                            <input type="hidden" name="id" value="<?php echo $editingNews['id']; ?>">
                            <?php endif; ?>
                            
                            <div class="row mb-3">
                                <div class="col-md-8">
                                    <label for="title" class="form-label">Title</label>
                                    <input type="text" class="form-control" id="title" name="title" required 
                                           value="<?php echo $action === 'edit' ? htmlspecialchars($editingNews['title']) : ''; ?>">
                                </div>
                                <div class="col-md-4">
                                    <label for="reward" class="form-label">Reward (Credits)</label>
                                    <input type="number" class="form-control" id="reward" name="reward" required min="0" 
                                           value="<?php echo $action === 'edit' ? $editingNews['reward'] : '5'; ?>">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="description" class="form-label">Short Description</label>
                                <textarea class="form-control" id="description" name="description" rows="2" required><?php echo $action === 'edit' ? htmlspecialchars($editingNews['description']) : ''; ?></textarea>
                                <div class="form-text">A brief description shown in news listings.</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="content" class="form-label">Article Content</label>
                                <textarea class="form-control" id="content" name="content" rows="10" required><?php echo $action === 'edit' ? $editingNews['content'] : ''; ?></textarea>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-8">
                                    <label for="thumbnail" class="form-label">Thumbnail Image</label>
                                    <input type="file" class="form-control" id="thumbnail" name="thumbnail" accept="image/*" <?php echo $action === 'add' ? 'required' : ''; ?>>
                                    <div class="form-text">Recommended size: 800x450 pixels</div>
                                </div>
                                <div class="col-md-4">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" id="status" name="status" required>
                                        <option value="active" <?php echo $action === 'edit' && $editingNews['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                                        <option value="inactive" <?php echo $action === 'edit' && $editingNews['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                    </select>
                                </div>
                            </div>
                            
                            <?php if ($action === 'edit' && !empty($editingNews['thumbnail'])): ?>
                            <div class="mb-3">
                                <label class="form-label">Current Thumbnail</label>
                                <div>
                                    <img src="<?php echo $editingNews['thumbnail']; ?>" alt="Current Thumbnail" class="img-thumbnail" style="max-height: 150px;">
                                </div>
                                <div class="form-text">Upload a new image to replace this one, or leave blank to keep it.</div>
                            </div>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between">
                                <a href="index.php?page=admin&section=news" class="btn btn-secondary">Cancel</a>
                                <button type="submit" class="btn btn-primary"><?php echo $action === 'edit' ? 'Update' : 'Create'; ?> News Article</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php else: ?>
                <!-- News Articles Listing -->
                <div class="card">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Thumbnail</th>
                                        <th>Reward</th>
                                        <th>Status</th>
                                        <th>Created</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($result->num_rows > 0) {
                                        while ($news = $result->fetch_assoc()) {
                                            ?>
                                            <tr>
                                                <td>
                                                    <div class="fw-bold"><?php echo htmlspecialchars($news['title']); ?></div>
                                                    <div class="small text-muted"><?php echo substr(htmlspecialchars($news['description']), 0, 100) . (strlen($news['description']) > 100 ? '...' : ''); ?></div>
                                                </td>
                                                <td>
                                                    <?php if (!empty($news['thumbnail'])): ?>
                                                        <img src="<?php echo $news['thumbnail']; ?>" alt="Thumbnail" class="img-thumbnail" style="max-height: 50px;">
                                                    <?php else: ?>
                                                        <span class="badge bg-secondary">No Image</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo $news['reward']; ?> credits</td>
                                                <td>
                                                    <span class="badge bg-<?php echo $news['status'] === 'active' ? 'success' : 'secondary'; ?>">
                                                        <?php echo ucfirst($news['status']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M j, Y', strtotime($news['created_at'])); ?></td>
                                                <td>
                                                    <div class="btn-group">
                                                        <a href="index.php?page=admin&section=news&action=edit&id=<?php echo $news['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteModal" 
                                                                data-bs-id="<?php echo $news['id']; ?>" 
                                                                data-bs-title="<?php echo htmlspecialchars($news['title']); ?>">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    } else {
                                        echo '<tr><td colspan="6" class="text-center py-4">No news articles found</td></tr>';
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the news article "<span id="deleteNewsTitle"></span>"?</p>
                <p class="text-danger">This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <form method="post" action="index.php?page=admin&section=news">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" id="deleteNewsId">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- CKEditor for rich text editing -->
<script src="https://cdn.ckeditor.com/ckeditor5/38.0.1/classic/ckeditor.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize CKEditor for content field
    if (document.getElementById('content')) {
        ClassicEditor
            .create(document.getElementById('content'))
            .catch(error => {
                console.error(error);
            });
    }
    
    // Handle delete modal
    const deleteModal = document.getElementById('deleteModal');
    if (deleteModal) {
        deleteModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const id = button.getAttribute('data-bs-id');
            const title = button.getAttribute('data-bs-title');
            
            document.getElementById('deleteNewsId').value = id;
            document.getElementById('deleteNewsTitle').textContent = title;
        });
    }
});
</script>

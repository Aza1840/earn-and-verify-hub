
<?php
// Get admin data
$adminId = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ? AND role = 'admin'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $adminId);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();

// Redirect if not admin
if (!$admin) {
    header("Location: index.php?page=admin-login");
    exit;
}

// Count users
$sql = "SELECT COUNT(*) as total FROM users WHERE role = 'user'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$totalUsers = $row['total'];

// Count new users in the last 24 hours
$sql = "SELECT COUNT(*) as total FROM users WHERE role = 'user' AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$newUsers = $row['total'];

// Count rewards distributed
$sql = "SELECT SUM(amount) as total FROM transactions WHERE type = 'reward' AND status = 'completed'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$totalEarnings = $row['total'] ?? 0;

// Count rewards this week
$sql = "SELECT SUM(amount) as total FROM transactions WHERE type = 'reward' AND status = 'completed' AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$weeklyEarnings = $row['total'] ?? 0;

// System status
$systemStatus = "Online";
$systemStatusColor = "success";
$systemStatusMessage = "All systems operational";
?>

<div class="row">
    <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar">
        <?php include 'pages/admin/sidebar.php'; ?>
    </div>
    <div class="col-md-9 col-lg-10">
        <div class="p-4">
            <div class="mb-4">
                <h1 class="h3 mb-0">Admin Dashboard</h1>
                <p class="text-muted">
                    Manage your platform
                </p>
            </div>

            <!-- Stats Cards -->
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">Total Users</h5>
                            <p class="text-muted">Platform user count</p>
                            <h2 class="display-4 mb-0"><?php echo $totalUsers; ?></h2>
                            <p class="text-success mb-0">+<?php echo $newUsers; ?> in the last 24 hours</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">Rewards Distributed</h5>
                            <p class="text-muted">Total earnings paid out</p>
                            <h2 class="display-4 mb-0">$<?php echo number_format($totalEarnings, 2); ?></h2>
                            <p class="text-success mb-0">+$<?php echo number_format($weeklyEarnings, 2); ?> this week</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">System Status</h5>
                            <p class="text-muted">Platform health and activity</p>
                            <h2 class="display-4 mb-0 text-<?php echo $systemStatusColor; ?>"><?php echo $systemStatus; ?></h2>
                            <p class="mb-0"><?php echo $systemStatusMessage; ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Management Tabs -->
            <div class="card mb-4">
                <div class="card-header">
                    <ul class="nav nav-tabs card-header-tabs">
                        <li class="nav-item">
                            <a class="nav-link active" href="#" id="videos-tab">Manage Videos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" id="news-tab">Manage News</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" id="users-tab">Manage Users</a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="tab-content">
                        <div class="tab-pane active" id="videos-content">
                            <div class="d-flex justify-content-between align-items-center mb-4">
                                <h3>Manage Videos</h3>
                                <a href="index.php?page=admin&section=videos&action=add" class="btn btn-primary">Add New Video</a>
                            </div>
                            
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>Duration</th>
                                            <th>Reward</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sql = "SELECT * FROM tasks WHERE type = 'video' ORDER BY created_at DESC LIMIT 5";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while($row = $result->fetch_assoc()) {
                                                echo '<tr>';
                                                echo '<td>' . htmlspecialchars($row['title']) . '</td>';
                                                echo '<td>' . htmlspecialchars($row['duration']) . ' mins</td>';
                                                echo '<td>' . htmlspecialchars($row['reward']) . ' credits</td>';
                                                echo '<td><span class="badge bg-success">Active</span></td>';
                                                echo '<td>';
                                                echo '<a href="index.php?page=admin&section=videos&action=edit&id=' . $row['id'] . '" class="btn btn-sm btn-primary me-1">Edit</a>';
                                                echo '<a href="index.php?page=admin&section=videos&action=delete&id=' . $row['id'] . '" class="btn btn-sm btn-danger">Delete</a>';
                                                echo '</td>';
                                                echo '</tr>';
                                            }
                                        } else {
                                            echo '<tr><td colspan="5" class="text-center">No videos found</td></tr>';
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <a href="index.php?page=admin&section=videos" class="btn btn-outline-primary">View All Videos</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Admin Mobile Sidebar Modal -->
<div class="modal fade" id="adminSidebarModal" tabindex="-1" aria-labelledby="adminSidebarModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen-sm-down">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title" id="adminSidebarModalLabel">Admin Menu</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div class="list-group list-group-flush">
                    <a href="index.php?page=admin" class="list-group-item list-group-item-action <?php echo empty($_GET['section']) ? 'active' : ''; ?>">
                        <i class="fas fa-th-large me-2"></i> Dashboard
                    </a>
                    <a href="index.php?page=admin&section=videos" class="list-group-item list-group-item-action <?php echo $_GET['section'] === 'videos' ? 'active' : ''; ?>">
                        <i class="fas fa-video me-2"></i> Videos
                    </a>
                    <a href="index.php?page=admin&section=users" class="list-group-item list-group-item-action <?php echo $_GET['section'] === 'users' ? 'active' : ''; ?>">
                        <i class="fas fa-users me-2"></i> Manage Users
                    </a>
                    <a href="index.php?page=admin&section=email-services" class="list-group-item list-group-item-action <?php echo $_GET['section'] === 'email-services' ? 'active' : ''; ?>">
                        <i class="fas fa-envelope me-2"></i> Email Services
                    </a>
                    <a href="index.php?page=admin&section=email-config" class="list-group-item list-group-item-action <?php echo $_GET['section'] === 'email-config' ? 'active' : ''; ?>">
                        <i class="fas fa-cog me-2"></i> Email Configuration
                    </a>
                    <a href="index.php?page=admin&section=kyc" class="list-group-item list-group-item-action <?php echo $_GET['section'] === 'kyc' ? 'active' : ''; ?>">
                        <i class="fas fa-id-card me-2"></i> KYC Applications
                    </a>
                    <a href="index.php?page=admin&section=deposits" class="list-group-item list-group-item-action <?php echo $_GET['section'] === 'deposits' ? 'active' : ''; ?>">
                        <i class="fas fa-arrow-down me-2"></i> Manage Deposits
                    </a>
                    <a href="index.php?page=admin&section=withdrawals" class="list-group-item list-group-item-action <?php echo $_GET['section'] === 'withdrawals' ? 'active' : ''; ?>">
                        <i class="fas fa-arrow-up me-2"></i> Manage Withdrawals
                    </a>
                    <a href="index.php?page=admin&section=accounts" class="list-group-item list-group-item-action <?php echo $_GET['section'] === 'accounts' ? 'active' : ''; ?>">
                        <i class="fas fa-user-circle me-2"></i> Manage Accounts
                    </a>
                    <a href="index.php?page=admin&section=tasks" class="list-group-item list-group-item-action <?php echo $_GET['section'] === 'tasks' ? 'active' : ''; ?>">
                        <i class="fas fa-tasks me-2"></i> Tasks
                    </a>
                    <a href="index.php?page=admin&section=administrators" class="list-group-item list-group-item-action <?php echo $_GET['section'] === 'administrators' ? 'active' : ''; ?>">
                        <i class="fas fa-user-shield me-2"></i> Administrators
                    </a>
                    <a href="index.php?page=admin&section=settings" class="list-group-item list-group-item-action <?php echo $_GET['section'] === 'settings' ? 'active' : ''; ?>">
                        <i class="fas fa-cogs me-2"></i> Settings
                    </a>
                </div>
                
                <div class="list-group list-group-flush border-top mt-3">
                    <a href="index.php?page=admin&section=profile" class="list-group-item list-group-item-action <?php echo $_GET['section'] === 'profile' ? 'active' : ''; ?>">
                        <i class="fas fa-user me-2"></i> Profile
                    </a>
                    <a href="logout.php?type=admin" class="list-group-item list-group-item-action text-danger">
                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const videosTab = document.getElementById('videos-tab');
    const newsTab = document.getElementById('news-tab');
    const usersTab = document.getElementById('users-tab');
    const videosContent = document.getElementById('videos-content');
    
    videosTab.addEventListener('click', function(e) {
        e.preventDefault();
        videosTab.classList.add('active');
        newsTab.classList.remove('active');
        usersTab.classList.remove('active');
        // Load videos content via AJAX or show/hide divs
    });
    
    newsTab.addEventListener('click', function(e) {
        e.preventDefault();
        videosTab.classList.remove('active');
        newsTab.classList.add('active');
        usersTab.classList.remove('active');
        // Redirect or load news content
        window.location.href = 'index.php?page=admin&section=news';
    });
    
    usersTab.addEventListener('click', function(e) {
        e.preventDefault();
        videosTab.classList.remove('active');
        newsTab.classList.remove('active');
        usersTab.classList.add('active');
        // Redirect or load users content
        window.location.href = 'index.php?page=admin&section=users';
    });
});
</script>

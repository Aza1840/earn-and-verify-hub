
<?php
// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: index.php?page=admin-login");
    exit;
}

// Get existing settings
$settings = getSiteSettings();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $smtpHost = clean_input($_POST["smtp_host"]);
    $smtpPort = intval($_POST["smtp_port"]);
    $smtpUsername = clean_input($_POST["smtp_username"]);
    $smtpPassword = $_POST["smtp_password"]; // Don't clean passwords
    $senderName = clean_input($_POST["sender_name"]);
    $senderEmail = clean_input($_POST["sender_email"]);
    $useSMTP = isset($_POST["use_smtp"]) ? 1 : 0;
    
    // Update settings
    $sql = "UPDATE settings SET 
            value = CASE 
                WHEN name = 'smtp_host' THEN ?
                WHEN name = 'smtp_port' THEN ?
                WHEN name = 'smtp_username' THEN ?
                WHEN name = 'smtp_password' THEN ?
                WHEN name = 'sender_name' THEN ?
                WHEN name = 'sender_email' THEN ?
                WHEN name = 'use_smtp' THEN ?
                ELSE value
            END
            WHERE name IN ('smtp_host', 'smtp_port', 'smtp_username', 'smtp_password', 
                          'sender_name', 'sender_email', 'use_smtp')";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", $smtpHost, $smtpPort, $smtpUsername, $smtpPassword, 
                     $senderName, $senderEmail, $useSMTP);
    
    if ($stmt->execute()) {
        // Check if SMTP settings exist, if not insert them
        $settingsToCheck = ['smtp_host', 'smtp_port', 'smtp_username', 'smtp_password', 
                            'sender_name', 'sender_email', 'use_smtp'];
        
        foreach ($settingsToCheck as $setting) {
            $sql = "SELECT id FROM settings WHERE name = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $setting);
            $stmt->execute();
            
            if ($stmt->get_result()->num_rows === 0) {
                $value = '';
                
                switch ($setting) {
                    case 'smtp_host':
                        $value = $smtpHost;
                        break;
                    case 'smtp_port':
                        $value = $smtpPort;
                        break;
                    case 'smtp_username':
                        $value = $smtpUsername;
                        break;
                    case 'smtp_password':
                        $value = $smtpPassword;
                        break;
                    case 'sender_name':
                        $value = $senderName;
                        break;
                    case 'sender_email':
                        $value = $senderEmail;
                        break;
                    case 'use_smtp':
                        $value = $useSMTP;
                        break;
                }
                
                $sql = "INSERT INTO settings (name, value) VALUES (?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $setting, $value);
                $stmt->execute();
            }
        }
        
        $successMessage = "Email settings updated successfully!";
        logAdminAction($_SESSION['user_id'], "Update email settings", "Admin updated email configuration");
        
        // Refresh settings
        $settings = getSiteSettings();
    } else {
        $errorMessage = "Error updating settings: " . $conn->error;
    }
}
?>

<div class="row">
    <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar">
        <?php include 'pages/admin/sidebar.php'; ?>
    </div>
    <div class="col-md-9 col-lg-10">
        <div class="p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0">Email Configuration</h1>
                    <p class="text-muted">
                        Configure email sending settings
                    </p>
                </div>
                <a href="index.php?page=admin&section=email" class="btn btn-outline-primary">
                    <i class="fas fa-envelope me-1"></i> Email Services
                </a>
            </div>

            <?php if (isset($successMessage)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $successMessage; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if (isset($errorMessage)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $errorMessage; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="card shadow mb-4">
                <div class="card-header py-3 bg-white">
                    <h6 class="m-0 font-weight-bold text-primary">Email Server Settings</h6>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="form-check mb-4">
                            <input class="form-check-input" type="checkbox" id="use_smtp" name="use_smtp" 
                                  <?php echo (isset($settings['use_smtp']) && $settings['use_smtp'] == 1) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="use_smtp">
                                Use SMTP Server (instead of PHP mail function)
                            </label>
                            <div class="form-text">Using an SMTP server is recommended for reliable email delivery.</div>
                        </div>
                        
                        <div id="smtp-settings">
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="smtp_host" class="form-label">SMTP Host</label>
                                        <input type="text" class="form-control" id="smtp_host" name="smtp_host" 
                                               value="<?php echo htmlspecialchars($settings['smtp_host'] ?? ''); ?>">
                                        <div class="form-text">e.g., smtp.gmail.com, smtp.mailserver.com</div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="smtp_port" class="form-label">SMTP Port</label>
                                        <input type="number" class="form-control" id="smtp_port" name="smtp_port" 
                                               value="<?php echo htmlspecialchars($settings['smtp_port'] ?? '587'); ?>">
                                        <div class="form-text">Common ports: 25, 465, 587</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="smtp_username" class="form-label">SMTP Username</label>
                                        <input type="text" class="form-control" id="smtp_username" name="smtp_username" 
                                               value="<?php echo htmlspecialchars($settings['smtp_username'] ?? ''); ?>">
                                        <div class="form-text">Usually your email address</div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="smtp_password" class="form-label">SMTP Password</label>
                                        <input type="password" class="form-control" id="smtp_password" name="smtp_password" 
                                               value="<?php echo htmlspecialchars($settings['smtp_password'] ?? ''); ?>">
                                        <div class="form-text">Your email password or app password</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <hr class="my-4">
                        
                        <h6 class="font-weight-bold mb-3">Sender Information</h6>
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="sender_name" class="form-label">Sender Name</label>
                                    <input type="text" class="form-control" id="sender_name" name="sender_name" 
                                           value="<?php echo htmlspecialchars($settings['sender_name'] ?? $settings['site_name'] ?? 'Rewards Platform'); ?>" required>
                                    <div class="form-text">Name that appears in the "From" field</div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="sender_email" class="form-label">Sender Email</label>
                                    <input type="email" class="form-control" id="sender_email" name="sender_email" 
                                           value="<?php echo htmlspecialchars($settings['sender_email'] ?? $settings['contact_email'] ?? 'no-reply@example.com'); ?>" required>
                                    <div class="form-text">Email address that appears in the "From" field</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-primary">Save Configuration</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const useSmtp = document.getElementById('use_smtp');
    const smtpSettings = document.getElementById('smtp-settings');
    
    function toggleSmtpSettings() {
        if (useSmtp.checked) {
            smtpSettings.style.display = 'block';
        } else {
            smtpSettings.style.display = 'none';
        }
    }
    
    // Set initial state
    toggleSmtpSettings();
    
    // Add change event listener
    useSmtp.addEventListener('change', toggleSmtpSettings);
});
</script>

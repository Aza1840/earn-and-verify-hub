
<?php
// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: index.php?page=admin-login");
    exit;
}

// Handle settings form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $siteName = clean_input($_POST["site_name"]);
    $siteDescription = clean_input($_POST["site_description"]);
    $contactEmail = clean_input($_POST["contact_email"]);
    $taskRewardMultiplier = floatval($_POST["task_reward_multiplier"]);
    $premiumMultiplier = floatval($_POST["premium_multiplier"]);
    $minWithdrawal = floatval($_POST["min_withdrawal"]);
    $referralBonus = floatval($_POST["referral_bonus"]);
    $maintenanceMode = isset($_POST["maintenance_mode"]) ? 1 : 0;
    
    // Update settings in the database
    $sql = "UPDATE settings SET 
            value = CASE 
                WHEN name = 'site_name' THEN ?
                WHEN name = 'site_description' THEN ?
                WHEN name = 'contact_email' THEN ?
                WHEN name = 'task_reward_multiplier' THEN ?
                WHEN name = 'premium_multiplier' THEN ?
                WHEN name = 'min_withdrawal' THEN ?
                WHEN name = 'referral_bonus' THEN ?
                WHEN name = 'maintenance_mode' THEN ?
                ELSE value
            END
            WHERE name IN ('site_name', 'site_description', 'contact_email', 'task_reward_multiplier', 
                          'premium_multiplier', 'min_withdrawal', 'referral_bonus', 'maintenance_mode')";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $siteName, $siteDescription, $contactEmail, $taskRewardMultiplier, 
                     $premiumMultiplier, $minWithdrawal, $referralBonus, $maintenanceMode);
    
    if ($stmt->execute()) {
        $successMessage = "Settings updated successfully!";
    } else {
        $errorMessage = "Error updating settings: " . $conn->error;
    }
    
    // Handle logo upload if present
    if (isset($_FILES['site_logo']) && $_FILES['site_logo']['error'] == 0) {
        $allowed = array('jpg', 'jpeg', 'png', 'gif');
        $filename = $_FILES['site_logo']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        
        if (in_array(strtolower($ext), $allowed)) {
            $newFilename = 'logo_' . time() . '.' . $ext;
            $destination = 'uploads/' . $newFilename;
            
            if (move_uploaded_file($_FILES['site_logo']['tmp_name'], $destination)) {
                // Update logo path in database
                $sql = "UPDATE settings SET value = ? WHERE name = 'site_logo'";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $destination);
                $stmt->execute();
                
                $successMessage = "Settings and logo updated successfully!";
            } else {
                $errorMessage = "Error uploading logo.";
            }
        } else {
            $errorMessage = "Invalid file format. Allowed formats: JPG, JPEG, PNG, GIF.";
        }
    }
}

// Get current settings
$settings = array();
$sql = "SELECT name, value FROM settings";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $settings[$row['name']] = $row['value'];
    }
}
?>

<div class="row">
    <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar">
        <?php include 'pages/admin/sidebar.php'; ?>
    </div>
    <div class="col-md-9 col-lg-10">
        <div class="p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="h3 mb-0">Site Settings</h1>
            </div>

            <?php if (isset($successMessage)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $successMessage; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if (isset($errorMessage)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $errorMessage; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">General Settings</h6>
                </div>
                <div class="card-body">
                    <form method="POST" action="" enctype="multipart/form-data">
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="site_name" class="form-label">Site Name</label>
                                    <input type="text" class="form-control" id="site_name" name="site_name" 
                                           value="<?php echo htmlspecialchars($settings['site_name'] ?? 'Rewards Platform'); ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="site_description" class="form-label">Site Description</label>
                                    <textarea class="form-control" id="site_description" name="site_description" rows="3"><?php echo htmlspecialchars($settings['site_description'] ?? ''); ?></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="contact_email" class="form-label">Contact Email</label>
                                    <input type="email" class="form-control" id="contact_email" name="contact_email"
                                           value="<?php echo htmlspecialchars($settings['contact_email'] ?? ''); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="site_logo" class="form-label">Site Logo</label>
                                    <?php if (!empty($settings['site_logo'])): ?>
                                        <div class="mb-2">
                                            <img src="<?php echo htmlspecialchars($settings['site_logo']); ?>" alt="Current Logo" class="img-fluid" style="max-height: 100px;">
                                        </div>
                                    <?php endif; ?>
                                    <input type="file" class="form-control" id="site_logo" name="site_logo">
                                    <div class="form-text">Recommended size: 200x50 pixels</div>
                                </div>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="maintenance_mode" name="maintenance_mode" 
                                           <?php echo (isset($settings['maintenance_mode']) && $settings['maintenance_mode'] == 1) ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="maintenance_mode">Maintenance Mode</label>
                                </div>
                            </div>
                        </div>

                        <h6 class="font-weight-bold mb-3">Reward Settings</h6>
                        <div class="row mb-4">
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="task_reward_multiplier" class="form-label">Task Reward Multiplier</label>
                                    <input type="number" step="0.01" class="form-control" id="task_reward_multiplier" name="task_reward_multiplier"
                                           value="<?php echo htmlspecialchars($settings['task_reward_multiplier'] ?? '1.0'); ?>" required>
                                    <div class="form-text">Base multiplier for all task rewards</div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="premium_multiplier" class="form-label">Premium User Multiplier</label>
                                    <input type="number" step="0.01" class="form-control" id="premium_multiplier" name="premium_multiplier"
                                           value="<?php echo htmlspecialchars($settings['premium_multiplier'] ?? '2.0'); ?>" required>
                                    <div class="form-text">Additional multiplier for premium users</div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="min_withdrawal" class="form-label">Minimum Withdrawal</label>
                                    <input type="number" step="0.01" class="form-control" id="min_withdrawal" name="min_withdrawal"
                                           value="<?php echo htmlspecialchars($settings['min_withdrawal'] ?? '5.0'); ?>" required>
                                    <div class="form-text">Minimum amount for withdrawals</div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="referral_bonus" class="form-label">Referral Bonus</label>
                                    <input type="number" step="0.01" class="form-control" id="referral_bonus" name="referral_bonus"
                                           value="<?php echo htmlspecialchars($settings['referral_bonus'] ?? '20'); ?>" required>
                                    <div class="form-text">Credits given for each referral</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-primary">Save Settings</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Database Settings</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Database Backup</label>
                                <div class="d-grid gap-2">
                                    <a href="actions/admin/backup_db.php" class="btn btn-outline-primary">
                                        <i class="fas fa-database me-2"></i>Backup Database
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">System Logs</label>
                                <div class="d-grid gap-2">
                                    <a href="index.php?page=admin&section=logs" class="btn btn-outline-secondary">
                                        <i class="fas fa-file-alt me-2"></i>View System Logs
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

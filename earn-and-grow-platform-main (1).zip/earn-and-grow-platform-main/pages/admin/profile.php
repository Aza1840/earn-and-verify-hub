
<?php
// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: index.php?page=admin-login");
    exit;
}

// Get admin data
$adminId = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ? AND role = 'admin'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $adminId);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();

// Handle admin profile update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $name = clean_input($_POST['name']);
    $email = clean_input($_POST['email']);
    $phone = isset($_POST['phone']) ? clean_input($_POST['phone']) : '';
    
    // Update admin data
    $sql = "UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $name, $email, $phone, $adminId);
    
    if ($stmt->execute()) {
        $successMessage = "Profile updated successfully!";
        logAdminAction($adminId, "Update admin profile", "Admin profile updated");
    } else {
        $errorMessage = "Error updating profile: " . $conn->error;
    }
    
    // Handle profile picture upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $allowed = array('jpg', 'jpeg', 'png', 'gif');
        $filename = $_FILES['profile_picture']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        
        if (in_array(strtolower($ext), $allowed)) {
            $newFilename = 'admin_' . $adminId . '_' . time() . '.' . $ext;
            $destination = 'uploads/admin/' . $newFilename;
            
            if (!is_dir('uploads/admin/')) {
                mkdir('uploads/admin/', 0777, true);
            }
            
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $destination)) {
                // Update profile picture in database
                $sql = "UPDATE users SET profile_picture = ? WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("si", $destination, $adminId);
                $stmt->execute();
                
                $successMessage = "Profile and picture updated successfully!";
            } else {
                $errorMessage = "Error uploading profile picture.";
            }
        } else {
            $errorMessage = "Invalid file format. Allowed formats: JPG, JPEG, PNG, GIF.";
        }
    }
    
    // Refresh admin data
    $sql = "SELECT * FROM users WHERE id = ? AND role = 'admin'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $adminId);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();
}

// Handle password change
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['change_password'])) {
    $currentPassword = $_POST['current_password'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];
    
    // Verify current password
    if (password_verify($currentPassword, $admin['password'])) {
        // Check if passwords match
        if ($newPassword === $confirmPassword) {
            // Update password
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            
            $sql = "UPDATE users SET password = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $hashedPassword, $adminId);
            
            if ($stmt->execute()) {
                $passwordSuccess = "Password changed successfully!";
                logAdminAction($adminId, "Admin password changed", "Admin changed their password");
            } else {
                $passwordError = "Error changing password: " . $conn->error;
            }
        } else {
            $passwordError = "New passwords do not match.";
        }
    } else {
        $passwordError = "Current password is incorrect.";
    }
}

// Get recent activities
$sql = "SELECT * FROM admin_logs WHERE admin_id = ? ORDER BY created_at DESC LIMIT 10";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $adminId);
$stmt->execute();
$recentActivities = $stmt->get_result();
?>

<div class="row">
    <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar">
        <?php include 'pages/admin/sidebar.php'; ?>
    </div>
    <div class="col-md-9 col-lg-10">
        <div class="p-4">
            <div class="mb-4">
                <h1 class="h3 mb-0">Admin Profile</h1>
                <p class="text-muted">
                    Manage your account settings
                </p>
            </div>

            <div class="row">
                <div class="col-lg-4 mb-4">
                    <div class="card shadow">
                        <div class="card-body text-center">
                            <?php if (!empty($admin['profile_picture']) && file_exists($admin['profile_picture'])): ?>
                                <img src="<?php echo $admin['profile_picture']; ?>" alt="Admin Profile" class="rounded-circle img-thumbnail mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                            <?php else: ?>
                                <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center mb-3 mx-auto" style="width: 150px; height: 150px; font-size: 60px;">
                                    <?php echo strtoupper(substr($admin['name'], 0, 1)); ?>
                                </div>
                            <?php endif; ?>
                            
                            <h4 class="mb-0"><?php echo htmlspecialchars($admin['name']); ?></h4>
                            <p class="text-muted mb-2"><?php echo htmlspecialchars($admin['email']); ?></p>
                            <div class="mt-2">
                                <span class="badge bg-danger">Administrator</span>
                            </div>
                        </div>
                        <div class="card-footer bg-white">
                            <a href="logout.php?type=admin" class="btn btn-danger w-100">
                                <i class="fas fa-sign-out-alt me-1"></i> Logout
                            </a>
                        </div>
                    </div>
                    
                    <div class="card shadow mt-4">
                        <div class="card-header bg-white">
                            <h5 class="mb-0">Admin Details</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <div class="text-muted small">Last Login</div>
                                <div class="fw-bold">
                                    <?php 
                                    // Get last login time
                                    $sql = "SELECT created_at FROM admin_logs 
                                           WHERE admin_id = ? AND action LIKE '%login%' 
                                           ORDER BY created_at DESC LIMIT 1,1";
                                    $stmt = $conn->prepare($sql);
                                    $stmt->bind_param("i", $adminId);
                                    $stmt->execute();
                                    $result = $stmt->get_result();
                                    $lastLogin = $result->fetch_assoc();
                                    
                                    if ($lastLogin) {
                                        echo date('M d, Y g:i A', strtotime($lastLogin['created_at']));
                                    } else {
                                        echo 'No previous login';
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="mb-3">
                                <div class="text-muted small">Admin Since</div>
                                <div class="fw-bold">
                                    <?php echo date('M d, Y', strtotime($admin['created_at'])); ?>
                                </div>
                            </div>
                            <div>
                                <div class="text-muted small">Current IP</div>
                                <div class="fw-bold">
                                    <?php echo $_SERVER['REMOTE_ADDR']; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-8">
                    <?php if (isset($successMessage)): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo $successMessage; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($errorMessage)): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo $errorMessage; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    
                    <div class="card shadow mb-4">
                        <div class="card-header bg-white">
                            <h5 class="mb-0">Edit Profile</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="name" class="form-label">Full Name</label>
                                        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($admin['name']); ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="email" class="form-label">Email Address</label>
                                        <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($admin['email']); ?>" required>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="phone" class="form-label">Phone Number</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($admin['phone'] ?? ''); ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="profile_picture" class="form-label">Profile Picture</label>
                                    <input type="file" class="form-control" id="profile_picture" name="profile_picture">
                                </div>
                                
                                <button type="submit" name="update_profile" class="btn btn-primary">Update Profile</button>
                            </form>
                        </div>
                    </div>
                    
                    <div class="card shadow mb-4">
                        <div class="card-header bg-white">
                            <h5 class="mb-0">Change Password</h5>
                        </div>
                        <div class="card-body">
                            <?php if (isset($passwordSuccess)): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo $passwordSuccess; ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (isset($passwordError)): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <?php echo $passwordError; ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php endif; ?>
                            
                            <form method="POST" action="">
                                <div class="mb-3">
                                    <label for="current_password" class="form-label">Current Password</label>
                                    <input type="password" class="form-control" id="current_password" name="current_password" required>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="new_password" class="form-label">New Password</label>
                                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="confirm_password" class="form-label">Confirm New Password</label>
                                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                    </div>
                                </div>
                                
                                <button type="submit" name="change_password" class="btn btn-danger">Change Password</button>
                            </form>
                        </div>
                    </div>
                    
                    <div class="card shadow">
                        <div class="card-header bg-white">
                            <h5 class="mb-0">Recent Activities</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="list-group list-group-flush">
                                <?php if ($recentActivities->num_rows > 0): ?>
                                    <?php while ($activity = $recentActivities->fetch_assoc()): ?>
                                        <div class="list-group-item">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <?php 
                                                    if (stripos($activity['action'], 'login') !== false) {
                                                        echo '<span class="text-primary"><i class="fas fa-sign-in-alt me-1"></i> ' . htmlspecialchars($activity['action']) . '</span>';
                                                    } elseif (stripos($activity['action'], 'update') !== false || stripos($activity['action'], 'edit') !== false) {
                                                        echo '<span class="text-info"><i class="fas fa-edit me-1"></i> ' . htmlspecialchars($activity['action']) . '</span>';
                                                    } elseif (stripos($activity['action'], 'delete') !== false) {
                                                        echo '<span class="text-danger"><i class="fas fa-trash-alt me-1"></i> ' . htmlspecialchars($activity['action']) . '</span>';
                                                    } elseif (stripos($activity['action'], 'add') !== false || stripos($activity['action'], 'create') !== false) {
                                                        echo '<span class="text-success"><i class="fas fa-plus me-1"></i> ' . htmlspecialchars($activity['action']) . '</span>';
                                                    } else {
                                                        echo htmlspecialchars($activity['action']);
                                                    }
                                                    ?>
                                                    
                                                    <?php if (!empty($activity['details'])): ?>
                                                        <p class="text-muted small mb-0"><?php echo htmlspecialchars($activity['details']); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                                <small class="text-muted">
                                                    <?php echo date('M d, g:i A', strtotime($activity['created_at'])); ?>
                                                </small>
                                            </div>
                                        </div>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <div class="list-group-item text-center">No recent activities found.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="card-footer bg-white text-center">
                            <a href="index.php?page=admin&section=logs&filter=admin" class="btn btn-sm btn-outline-primary">View All Activities</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="sidebar bg-white h-100 border-end position-relative">
    <button id="toggleSidebar" class="btn btn-sm position-absolute top-50 end-0 translate-middle-y bg-white border rounded-end d-none d-md-block" style="transform: translateX(50%);">
        <i class="fas fa-chevron-left" id="sidebarIcon"></i>
    </button>
    <div class="sidebar-header p-3 border-bottom">
        <h5 class="mb-0 d-flex align-items-center">
            <span class="bg-dark text-white p-2 me-2 rounded">A</span>
            <span class="sidebar-title">Admin Panel</span>
        </h5>
        <p class="text-muted small mb-0 sidebar-title">Manage your platform</p>
    </div>

    <div class="sidebar-body p-0">
        <div class="px-3 py-2">
            <p class="small text-uppercase text-muted mb-2 mt-3 sidebar-title">Main</p>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link <?php echo empty($_GET['section']) ? 'active bg-light' : ''; ?>" href="index.php?page=admin">
                        <i class="fas fa-fw fa-th-large me-2"></i>
                        <span class="sidebar-link-text">Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $_GET['section'] === 'videos' ? 'active bg-light' : ''; ?>" href="index.php?page=admin&section=videos">
                        <i class="fas fa-fw fa-video me-2"></i>
                        <span class="sidebar-link-text">Videos</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $_GET['section'] === 'users' ? 'active bg-light' : ''; ?>" href="index.php?page=admin&section=users">
                        <i class="fas fa-fw fa-users me-2"></i>
                        <span class="sidebar-link-text">Manage Users</span>
                    </a>
                </li>
            </ul>
        </div>
        
        <div class="px-3 py-2">
            <p class="small text-uppercase text-muted mb-2 mt-3 sidebar-title">Communication</p>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link <?php echo $_GET['section'] === 'email' ? 'active bg-light' : ''; ?>" href="index.php?page=admin&section=email">
                        <i class="fas fa-fw fa-envelope me-2"></i>
                        <span class="sidebar-link-text">Email Services</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $_GET['section'] === 'email-config' ? 'active bg-light' : ''; ?>" href="index.php?page=admin&section=email-config">
                        <i class="fas fa-fw fa-cog me-2"></i>
                        <span class="sidebar-link-text">Email Configuration</span>
                    </a>
                </li>
            </ul>
        </div>
        
        <div class="px-3 py-2">
            <p class="small text-uppercase text-muted mb-2 mt-3 sidebar-title">Finance</p>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link <?php echo $_GET['section'] === 'kyc' ? 'active bg-light' : ''; ?>" href="index.php?page=admin&section=kyc">
                        <i class="fas fa-fw fa-id-card me-2"></i>
                        <span class="sidebar-link-text">KYC Applications</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $_GET['section'] === 'deposits' ? 'active bg-light' : ''; ?>" href="index.php?page=admin&section=deposits">
                        <i class="fas fa-fw fa-arrow-down me-2"></i>
                        <span class="sidebar-link-text">Manage Deposits</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $_GET['section'] === 'withdrawals' ? 'active bg-light' : ''; ?>" href="index.php?page=admin&section=withdrawals">
                        <i class="fas fa-fw fa-arrow-up me-2"></i>
                        <span class="sidebar-link-text">Manage Withdrawals</span>
                    </a>
                </li>
            </ul>
        </div>
        
        <div class="px-3 py-2">
            <p class="small text-uppercase text-muted mb-2 mt-3 sidebar-title">System</p>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link <?php echo $_GET['section'] === 'accounts' ? 'active bg-light' : ''; ?>" href="index.php?page=admin&section=accounts">
                        <i class="fas fa-fw fa-user-circle me-2"></i>
                        <span class="sidebar-link-text">Manage Accounts</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $_GET['section'] === 'tasks' ? 'active bg-light' : ''; ?>" href="index.php?page=admin&section=tasks">
                        <i class="fas fa-fw fa-tasks me-2"></i>
                        <span class="sidebar-link-text">Tasks</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $_GET['section'] === 'administrators' ? 'active bg-light' : ''; ?>" href="index.php?page=admin&section=administrators">
                        <i class="fas fa-fw fa-user-shield me-2"></i>
                        <span class="sidebar-link-text">Administrators</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $_GET['section'] === 'settings' ? 'active bg-light' : ''; ?>" href="index.php?page=admin&section=settings">
                        <i class="fas fa-fw fa-cogs me-2"></i>
                        <span class="sidebar-link-text">Settings</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $_GET['section'] === 'logs' ? 'active bg-light' : ''; ?>" href="index.php?page=admin&section=logs">
                        <i class="fas fa-fw fa-file-alt me-2"></i>
                        <span class="sidebar-link-text">System Logs</span>
                    </a>
                </li>
            </ul>
        </div>
        
        <div class="px-3 py-2">
            <p class="small text-uppercase text-muted mb-2 mt-3 sidebar-title">Account</p>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link <?php echo $_GET['section'] === 'profile' ? 'active bg-light' : ''; ?>" href="index.php?page=admin&section=profile">
                        <i class="fas fa-fw fa-user me-2"></i>
                        <span class="sidebar-link-text">Profile</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-danger" href="logout.php?type=admin">
                        <i class="fas fa-fw fa-sign-out-alt me-2"></i>
                        <span class="sidebar-link-text">Logout</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Check for saved state
    const sidebarCollapsed = localStorage.getItem('adminSidebarCollapsed') === 'true';
    const sidebar = document.querySelector('.admin-sidebar');
    const sidebarIcon = document.getElementById('sidebarIcon');
    const toggleButton = document.getElementById('toggleSidebar');
    
    // Set initial state
    if (sidebarCollapsed) {
        sidebar.classList.add('sidebar-collapsed');
        sidebarIcon.classList.remove('fa-chevron-left');
        sidebarIcon.classList.add('fa-chevron-right');
    }
    
    // Toggle sidebar collapse
    toggleButton.addEventListener('click', function() {
        sidebar.classList.toggle('sidebar-collapsed');
        
        if (sidebar.classList.contains('sidebar-collapsed')) {
            sidebarIcon.classList.remove('fa-chevron-left');
            sidebarIcon.classList.add('fa-chevron-right');
            localStorage.setItem('adminSidebarCollapsed', 'true');
        } else {
            sidebarIcon.classList.remove('fa-chevron-right');
            sidebarIcon.classList.add('fa-chevron-left');
            localStorage.setItem('adminSidebarCollapsed', 'false');
        }
    });
});
</script>

<style>
/* Sidebar toggle functionality */
.admin-sidebar {
    width: 16.67%; /* col-md-2 width */
    transition: width 0.3s ease;
}

.sidebar-collapsed {
    width: 70px !important;
}

.sidebar-collapsed .sidebar-title {
    display: none;
}

.sidebar-collapsed .sidebar-link-text {
    display: none;
}

.sidebar-collapsed .sidebar-header {
    text-align: center;
}

.sidebar-collapsed .sidebar-header .me-2 {
    margin-right: 0 !important;
}

/* Add some responsive adjustments */
@media (max-width: 767.98px) {
    #toggleSidebar {
        display: none !important;
    }
}
</style>

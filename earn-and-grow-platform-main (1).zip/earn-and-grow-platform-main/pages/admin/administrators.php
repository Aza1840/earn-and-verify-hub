
<?php
// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: index.php?page=admin-login");
    exit;
}

// Handle admin creation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_admin'])) {
    $name = clean_input($_POST['name']);
    $email = clean_input($_POST['email']);
    $password = $_POST['password']; // Don't clean password
    $confirmPassword = $_POST['confirm_password'];
    
    // Validate input
    if (empty($name) || empty($email) || empty($password)) {
        $errorMessage = "All fields are required.";
    } elseif ($password !== $confirmPassword) {
        $errorMessage = "Passwords do not match.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMessage = "Please enter a valid email address.";
    } elseif (emailExists($email)) {
        $errorMessage = "Email address already exists.";
    } else {
        // Create admin
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $role = 'admin';
        
        $sql = "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $name, $email, $hashedPassword, $role);
        
        if ($stmt->execute()) {
            $successMessage = "Administrator created successfully!";
            logAdminAction($_SESSION['user_id'], "Create admin", "Created new admin: {$email}");
        } else {
            $errorMessage = "Error creating administrator: " . $conn->error;
        }
    }
}

// Handle admin deletion
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_admin'])) {
    $adminId = intval($_POST['admin_id']);
    
    // Prevent deleting self
    if ($adminId == $_SESSION['user_id']) {
        $deleteError = "You cannot delete your own account.";
    } else {
        // Get admin info for logging
        $sql = "SELECT email FROM users WHERE id = ? AND role = 'admin'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $adminId);
        $stmt->execute();
        $result = $stmt->get_result();
        $adminInfo = $result->fetch_assoc();
        
        // Delete admin
        $sql = "DELETE FROM users WHERE id = ? AND role = 'admin'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $adminId);
        
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $deleteSuccess = "Administrator deleted successfully!";
            logAdminAction($_SESSION['user_id'], "Delete admin", "Deleted admin: {$adminInfo['email']}");
        } else {
            $deleteError = "Error deleting administrator.";
        }
    }
}

// Get all admins
$sql = "SELECT * FROM users WHERE role = 'admin' ORDER BY created_at DESC";
$admins = $conn->query($sql);
?>

<div class="row">
    <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar">
        <?php include 'pages/admin/sidebar.php'; ?>
    </div>
    <div class="col-md-9 col-lg-10">
        <div class="p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0">Administrators</h1>
                    <p class="text-muted">
                        Manage administrator accounts
                    </p>
                </div>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAdminModal">
                    <i class="fas fa-plus me-1"></i> Add Administrator
                </button>
            </div>

            <?php if (isset($deleteSuccess)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $deleteSuccess; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if (isset($deleteError)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $deleteError; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="card shadow">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Last Login</th>
                                    <th>Created On</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($admins->num_rows > 0): ?>
                                    <?php while ($admin = $admins->fetch_assoc()): ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <?php if (!empty($admin['profile_picture']) && file_exists($admin['profile_picture'])): ?>
                                                        <img src="<?php echo $admin['profile_picture']; ?>" alt="Admin" class="rounded-circle me-2" width="40" height="40" style="object-fit: cover;">
                                                    <?php else: ?>
                                                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 40px; height: 40px;">
                                                            <?php echo strtoupper(substr($admin['name'], 0, 1)); ?>
                                                        </div>
                                                    <?php endif; ?>
                                                    
                                                    <div>
                                                        <?php echo htmlspecialchars($admin['name']); ?>
                                                        <?php if ($admin['id'] == $_SESSION['user_id']): ?>
                                                            <span class="badge bg-info ms-1">You</span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?php echo htmlspecialchars($admin['email']); ?></td>
                                            <td>
                                                <?php 
                                                // Get last login time
                                                $sql = "SELECT created_at FROM admin_logs 
                                                       WHERE admin_id = ? AND action LIKE '%login%' 
                                                       ORDER BY created_at DESC LIMIT 1";
                                                $stmt = $conn->prepare($sql);
                                                $stmt->bind_param("i", $admin['id']);
                                                $stmt->execute();
                                                $result = $stmt->get_result();
                                                $lastLogin = $result->fetch_assoc();
                                                
                                                if ($lastLogin) {
                                                    echo date('M d, Y g:i A', strtotime($lastLogin['created_at']));
                                                } else {
                                                    echo '<span class="text-muted">Never</span>';
                                                }
                                                ?>
                                            </td>
                                            <td><?php echo date('M d, Y', strtotime($admin['created_at'])); ?></td>
                                            <td>
                                                <?php if ($admin['id'] != $_SESSION['user_id']): ?>
                                                    <button type="button" class="btn btn-sm btn-danger" 
                                                            data-bs-toggle="modal" 
                                                            data-bs-target="#deleteAdminModal" 
                                                            data-admin-id="<?php echo $admin['id']; ?>"
                                                            data-admin-name="<?php echo htmlspecialchars($admin['name']); ?>">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                <?php else: ?>
                                                    <a href="index.php?page=admin&section=profile" class="btn btn-sm btn-primary">
                                                        <i class="fas fa-user-edit"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center">No administrators found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Administrator Modal -->
<div class="modal fade" id="addAdminModal" tabindex="-1" aria-labelledby="addAdminModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addAdminModalLabel">Add Administrator</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php if (isset($successMessage)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $successMessage; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($errorMessage)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $errorMessage; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="" id="addAdminForm">
                    <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="addAdminForm" name="add_admin" class="btn btn-primary">Add Administrator</button>
            </div>
        </div>
    </div>
</div>

<!-- Delete Administrator Modal -->
<div class="modal fade" id="deleteAdminModal" tabindex="-1" aria-labelledby="deleteAdminModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteAdminModalLabel">Delete Administrator</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete administrator <strong id="adminToDelete"></strong>?</p>
                <p class="text-danger">This action cannot be undone.</p>
                
                <form method="POST" action="" id="deleteAdminForm">
                    <input type="hidden" id="admin_id" name="admin_id" value="">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" form="deleteAdminForm" name="delete_admin" class="btn btn-danger">Delete</button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle delete modal
    const deleteModal = document.getElementById('deleteAdminModal');
    if (deleteModal) {
        deleteModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const adminId = button.getAttribute('data-admin-id');
            const adminName = button.getAttribute('data-admin-name');
            
            document.getElementById('admin_id').value = adminId;
            document.getElementById('adminToDelete').textContent = adminName;
        });
    }
    
    // Show modal again if there was an error
    <?php if (isset($errorMessage) || isset($successMessage)): ?>
        const addModal = new bootstrap.Modal(document.getElementById('addAdminModal'));
        addModal.show();
    <?php endif; ?>
});
</script>

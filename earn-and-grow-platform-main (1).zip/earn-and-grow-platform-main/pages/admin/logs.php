
<?php
// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: index.php?page=admin-login");
    exit;
}

// Pagination
$page = isset($_GET['p']) ? intval($_GET['p']) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Filter
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$searchTerm = isset($_GET['search']) ? clean_input($_GET['search']) : '';

// Build query based on filter
$whereClause = "";
$params = [];
$types = "";

if ($filter === 'login') {
    $whereClause = " WHERE action LIKE ?";
    $params[] = "%login%";
    $types .= "s";
} elseif ($filter === 'update') {
    $whereClause = " WHERE action LIKE ?";
    $params[] = "%update%";
    $types .= "s";
} elseif ($filter === 'delete') {
    $whereClause = " WHERE action LIKE ?";
    $params[] = "%delete%";
    $types .= "s";
}

if (!empty($searchTerm)) {
    $whereClause = empty($whereClause) ? " WHERE " : $whereClause . " AND ";
    $whereClause .= "(action LIKE ? OR details LIKE ?)";
    $params[] = "%$searchTerm%";
    $params[] = "%$searchTerm%";
    $types .= "ss";
}

// Count total logs
$countSql = "SELECT COUNT(*) as total FROM admin_logs" . $whereClause;
$stmt = $conn->prepare($countSql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$totalLogs = $stmt->get_result()->fetch_assoc()['total'];
$totalPages = ceil($totalLogs / $limit);

// Get logs
$sql = "SELECT al.*, u.name, u.email FROM admin_logs al 
        LEFT JOIN users u ON al.admin_id = u.id" . $whereClause . 
        " ORDER BY al.created_at DESC LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$types .= "ii";
$params[] = $limit;
$params[] = $offset;
$stmt->bind_param($types, ...$params);
$stmt->execute();
$logs = $stmt->get_result();
?>

<div class="row">
    <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar">
        <?php include 'pages/admin/sidebar.php'; ?>
    </div>
    <div class="col-md-9 col-lg-10">
        <div class="p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0">System Logs</h1>
                    <p class="text-muted">
                        View all system activities
                    </p>
                </div>
                <a href="#" class="btn btn-outline-primary" onclick="exportLogs()">
                    <i class="fas fa-download me-1"></i> Export Logs
                </a>
            </div>

            <div class="card shadow mb-4">
                <div class="card-header bg-white py-3">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <div class="btn-group" role="group">
                                <a href="index.php?page=admin&section=logs" class="btn <?php echo $filter === 'all' ? 'btn-primary' : 'btn-outline-primary'; ?>">All</a>
                                <a href="index.php?page=admin&section=logs&filter=login" class="btn <?php echo $filter === 'login' ? 'btn-primary' : 'btn-outline-primary'; ?>">Logins</a>
                                <a href="index.php?page=admin&section=logs&filter=update" class="btn <?php echo $filter === 'update' ? 'btn-primary' : 'btn-outline-primary'; ?>">Updates</a>
                                <a href="index.php?page=admin&section=logs&filter=delete" class="btn <?php echo $filter === 'delete' ? 'btn-primary' : 'btn-outline-primary'; ?>">Deletions</a>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <form action="" method="GET" class="d-flex">
                                <input type="hidden" name="page" value="admin">
                                <input type="hidden" name="section" value="logs">
                                <input type="hidden" name="filter" value="<?php echo $filter; ?>">
                                <input type="text" name="search" class="form-control me-2" placeholder="Search logs..." value="<?php echo htmlspecialchars($searchTerm); ?>">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Admin</th>
                                    <th>Action</th>
                                    <th>Details</th>
                                    <th>IP Address</th>
                                    <th>Date/Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($logs->num_rows > 0): ?>
                                    <?php while ($log = $logs->fetch_assoc()): ?>
                                        <tr>
                                            <td>
                                                <?php if ($log['name']): ?>
                                                    <?php echo htmlspecialchars($log['name']); ?>
                                                    <br>
                                                    <small class="text-muted"><?php echo htmlspecialchars($log['email']); ?></small>
                                                <?php else: ?>
                                                    <span class="text-muted">Admin ID: <?php echo $log['admin_id']; ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php 
                                                if (stripos($log['action'], 'login') !== false) {
                                                    echo '<span class="text-primary"><i class="fas fa-sign-in-alt me-1"></i> ' . htmlspecialchars($log['action']) . '</span>';
                                                } elseif (stripos($log['action'], 'update') !== false || stripos($log['action'], 'edit') !== false) {
                                                    echo '<span class="text-info"><i class="fas fa-edit me-1"></i> ' . htmlspecialchars($log['action']) . '</span>';
                                                } elseif (stripos($log['action'], 'delete') !== false) {
                                                    echo '<span class="text-danger"><i class="fas fa-trash-alt me-1"></i> ' . htmlspecialchars($log['action']) . '</span>';
                                                } elseif (stripos($log['action'], 'add') !== false || stripos($log['action'], 'create') !== false) {
                                                    echo '<span class="text-success"><i class="fas fa-plus me-1"></i> ' . htmlspecialchars($log['action']) . '</span>';
                                                } else {
                                                    echo htmlspecialchars($log['action']);
                                                }
                                                ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($log['details']); ?></td>
                                            <td><?php echo htmlspecialchars($log['ip_address']); ?></td>
                                            <td><?php echo date('M d, Y H:i:s', strtotime($log['created_at'])); ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center">No logs found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <?php if ($totalPages > 1): ?>
                        <nav aria-label="Logs pagination">
                            <ul class="pagination justify-content-center mt-4">
                                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="index.php?page=admin&section=logs&filter=<?php echo $filter; ?>&search=<?php echo urlencode($searchTerm); ?>&p=<?php echo $page-1; ?>">
                                        Previous
                                    </a>
                                </li>
                                
                                <?php for ($i = max(1, $page - 3); $i <= min($page + 3, $totalPages); $i++): ?>
                                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="index.php?page=admin&section=logs&filter=<?php echo $filter; ?>&search=<?php echo urlencode($searchTerm); ?>&p=<?php echo $i; ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>
                                
                                <li class="page-item <?php echo $page >= $totalPages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="index.php?page=admin&section=logs&filter=<?php echo $filter; ?>&search=<?php echo urlencode($searchTerm); ?>&p=<?php echo $page+1; ?>">
                                        Next
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function exportLogs() {
    // Create a form to submit the export request
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = 'actions/admin/export_logs.php';
    
    // Add current filter
    const filterInput = document.createElement('input');
    filterInput.type = 'hidden';
    filterInput.name = 'filter';
    filterInput.value = '<?php echo $filter; ?>';
    form.appendChild(filterInput);
    
    // Add search term if any
    const searchInput = document.createElement('input');
    searchInput.type = 'hidden';
    searchInput.name = 'search';
    searchInput.value = '<?php echo $searchTerm; ?>';
    form.appendChild(searchInput);
    
    // Submit the form
    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);
}
</script>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-5">
            <div class="card shadow border-0 rounded-lg mt-5">
                <div class="card-header bg-dark text-white text-center">
                    <h3 class="font-weight-bold my-4">Admin Login</h3>
                </div>
                <div class="card-body">
                    <?php
                    // Process login form
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        // Get form data
                        $email = clean_input($_POST["email"]);
                        $password = $_POST["password"];
                        
                        // Validate form
                        $errors = array();
                        
                        if (empty($email)) {
                            $errors[] = "Email is required";
                        }
                        
                        if (empty($password)) {
                            $errors[] = "Password is required";
                        }
                        
                        // If no errors, proceed with login
                        if (empty($errors)) {
                            // Check admin credentials
                            $sql = "SELECT id, username, email, password, role FROM users WHERE email = ? AND role = 'admin'";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("s", $email);
                            $stmt->execute();
                            $result = $stmt->get_result();
                            
                            if ($result->num_rows == 1) {
                                $user = $result->fetch_assoc();
                                
                                // Verify password
                                if (password_verify($password, $user["password"])) {
                                    // Password is correct, start a new session
                                    session_start();
                                    
                                    // Store data in session variables
                                    $_SESSION["user_id"] = $user["id"];
                                    $_SESSION["username"] = $user["username"];
                                    $_SESSION["email"] = $user["email"];
                                    $_SESSION["user_role"] = $user["role"];
                                    
                                    // Log admin login
                                    $activity = "Admin login";
                                    $sql = "INSERT INTO activities (user_id, activity_type, description, created_at) 
                                            VALUES (?, 'login', ?, NOW())";
                                    $stmt = $conn->prepare($sql);
                                    $description = "Admin logged in from IP: " . $_SERVER['REMOTE_ADDR'];
                                    $stmt->bind_param("is", $user["id"], $description);
                                    $stmt->execute();
                                    
                                    // Redirect to admin dashboard
                                    header("Location: index.php?page=admin");
                                    exit;
                                } else {
                                    $errors[] = "Invalid email or password";
                                }
                            } else {
                                $errors[] = "Invalid email or password";
                            }
                        }
                        
                        // Display errors if any
                        if (!empty($errors)) {
                            echo '<div class="alert alert-danger">';
                            foreach ($errors as $error) {
                                echo $error . '<br>';
                            }
                            echo '</div>';
                        }
                    }
                    
                    // Display session messages if any
                    if (isset($_SESSION['message'])) {
                        echo '<div class="alert alert-info">' . $_SESSION['message'] . '</div>';
                        unset($_SESSION['message']);
                    }
                    ?>
                    <form method="POST" action="index.php?page=admin-login">
                        <div class="mb-3">
                            <label for="email" class="form-label">Admin Email</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                <input class="form-control" id="email" name="email" type="email" placeholder="Enter admin email" required />
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                <input class="form-control" id="password" name="password" type="password" placeholder="Enter password" required />
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" id="remember" name="remember" type="checkbox" />
                                <label class="form-check-label" for="remember">Remember me</label>
                            </div>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-dark btn-lg">Admin Login</button>
                        </div>
                    </form>
                </div>
                <div class="card-footer text-center py-3">
                    <div class="small"><a href="index.php?page=login">Return to User Login</a></div>
                </div>
            </div>
            <div class="text-center mt-3 text-muted">
                <small>Admin access only. Unauthorized access attempts will be logged.</small>
            </div>
        </div>
    </div>
</div>

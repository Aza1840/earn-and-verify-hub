
<?php
// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: index.php?page=admin-login");
    exit;
}

// Get settings
$settings = getSiteSettings();

// Handle sending test email
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['send_test'])) {
    $recipientEmail = clean_input($_POST['test_email']);
    
    // Basic email validation
    if (!filter_var($recipientEmail, FILTER_VALIDATE_EMAIL)) {
        $errorMessage = "Please enter a valid email address.";
    } else {
        // Send test email
        $subject = "Test Email from " . ($settings['site_name'] ?? 'Our Platform');
        $message = "This is a test email from " . ($settings['site_name'] ?? 'Our Platform') . ". If you received this email, your email configuration is working correctly.";
        $headers = "From: " . ($settings['contact_email'] ?? 'no-reply@example.com') . "\r\n";
        $headers .= "Reply-To: " . ($settings['contact_email'] ?? 'no-reply@example.com') . "\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        
        if (mail($recipientEmail, $subject, $message, $headers)) {
            $successMessage = "Test email sent successfully!";
            logAdminAction($_SESSION['user_id'], "Send test email", "Test email sent to " . $recipientEmail);
        } else {
            $errorMessage = "Failed to send test email. Please check your email server configuration.";
        }
    }
}

// Handle sending mass email
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['send_mass'])) {
    $emailSubject = clean_input($_POST['email_subject']);
    $emailContent = $_POST['email_content']; // Don't clean HTML content
    $recipientGroup = clean_input($_POST['recipient_group']);
    
    if (empty($emailSubject)) {
        $massErrorMessage = "Email subject cannot be empty.";
    } elseif (empty($emailContent)) {
        $massErrorMessage = "Email content cannot be empty.";
    } else {
        // Get recipients based on group
        $recipientQuery = "SELECT id, email, name FROM users WHERE 1=1";
        if ($recipientGroup === 'standard') {
            $recipientQuery .= " AND is_premium = 0";
        } elseif ($recipientGroup === 'premium') {
            $recipientQuery .= " AND is_premium = 1";
        } elseif ($recipientGroup === 'inactive') {
            $recipientQuery .= " AND last_login < DATE_SUB(NOW(), INTERVAL 30 DAY)";
        }
        
        $recipients = $conn->query($recipientQuery);
        $sentCount = 0;
        $failedCount = 0;
        
        if ($recipients->num_rows > 0) {
            // Create email record
            $sql = "INSERT INTO mass_emails (subject, content, recipient_group, sent_by) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssi", $emailSubject, $emailContent, $recipientGroup, $_SESSION['user_id']);
            $stmt->execute();
            $emailId = $stmt->insert_id;
            
            // Send emails to each recipient
            while ($recipient = $recipients->fetch_assoc()) {
                // Personalize message
                $personalizedMessage = str_replace('[NAME]', $recipient['name'], $emailContent);
                
                // Set headers
                $headers = "From: " . ($settings['contact_email'] ?? 'no-reply@example.com') . "\r\n";
                $headers .= "Reply-To: " . ($settings['contact_email'] ?? 'no-reply@example.com') . "\r\n";
                $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                
                // Send email
                if (mail($recipient['email'], $emailSubject, $personalizedMessage, $headers)) {
                    $sentCount++;
                    
                    // Log recipient
                    $sql = "INSERT INTO email_recipients (email_id, user_id, status) VALUES (?, ?, 'sent')";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ii", $emailId, $recipient['id']);
                    $stmt->execute();
                } else {
                    $failedCount++;
                    
                    // Log failed recipient
                    $sql = "INSERT INTO email_recipients (email_id, user_id, status) VALUES (?, ?, 'failed')";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ii", $emailId, $recipient['id']);
                    $stmt->execute();
                }
            }
            
            if ($sentCount > 0) {
                $massSuccessMessage = "Mass email sent to {$sentCount} recipients." . ($failedCount > 0 ? " {$failedCount} failed." : "");
                logAdminAction($_SESSION['user_id'], "Send mass email", "Email sent to {$sentCount} recipients. Subject: {$emailSubject}");
            } else {
                $massErrorMessage = "Failed to send any emails. Please check your email server configuration.";
            }
        } else {
            $massErrorMessage = "No recipients found for the selected group.";
        }
    }
}

// Get recent mass emails
$recentEmails = $conn->query("SELECT me.*, u.name as sent_by_name, 
                             (SELECT COUNT(*) FROM email_recipients WHERE email_id = me.id AND status = 'sent') as sent_count,
                             (SELECT COUNT(*) FROM email_recipients WHERE email_id = me.id AND status = 'failed') as failed_count
                             FROM mass_emails me 
                             LEFT JOIN users u ON me.sent_by = u.id 
                             ORDER BY me.created_at DESC LIMIT 10");
?>

<div class="row">
    <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar">
        <?php include 'pages/admin/sidebar.php'; ?>
    </div>
    <div class="col-md-9 col-lg-10">
        <div class="p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="h3 mb-0">Email Services</h1>
                <a href="index.php?page=admin&section=email-config" class="btn btn-outline-primary">
                    <i class="fas fa-cog me-1"></i> Email Configuration
                </a>
            </div>
            
            <!-- Test Email Card -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 bg-white">
                    <h6 class="m-0 font-weight-bold text-primary">Send Test Email</h6>
                </div>
                <div class="card-body">
                    <?php if (isset($successMessage)): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo $successMessage; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($errorMessage)): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo $errorMessage; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="test_email" class="form-label">Recipient Email</label>
                            <input type="email" class="form-control" id="test_email" name="test_email" required>
                            <div class="form-text">Send a test email to verify your email configuration is working.</div>
                        </div>
                        <button type="submit" name="send_test" class="btn btn-primary">Send Test Email</button>
                    </form>
                </div>
            </div>
            
            <!-- Mass Email Card -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 bg-white">
                    <h6 class="m-0 font-weight-bold text-primary">Send Mass Email</h6>
                </div>
                <div class="card-body">
                    <?php if (isset($massSuccessMessage)): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo $massSuccessMessage; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($massErrorMessage)): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo $massErrorMessage; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="recipient_group" class="form-label">Recipient Group</label>
                            <select class="form-select" id="recipient_group" name="recipient_group" required>
                                <option value="all">All Users</option>
                                <option value="standard">Standard Users</option>
                                <option value="premium">Premium Users</option>
                                <option value="inactive">Inactive Users (30+ days)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="email_subject" class="form-label">Email Subject</label>
                            <input type="text" class="form-control" id="email_subject" name="email_subject" required>
                        </div>
                        <div class="mb-3">
                            <label for="email_content" class="form-label">Email Content</label>
                            <textarea class="form-control" id="email_content" name="email_content" rows="10" required></textarea>
                            <div class="form-text">Use [NAME] to include the recipient's name.</div>
                        </div>
                        <button type="submit" name="send_mass" class="btn btn-primary">Send Mass Email</button>
                    </form>
                </div>
            </div>
            
            <!-- Recent Emails Card -->
            <div class="card shadow">
                <div class="card-header py-3 bg-white">
                    <h6 class="m-0 font-weight-bold text-primary">Recent Mass Emails</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Subject</th>
                                    <th>Recipient Group</th>
                                    <th>Sent By</th>
                                    <th>Delivery</th>
                                    <th>Date Sent</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($recentEmails->num_rows > 0): ?>
                                    <?php while ($email = $recentEmails->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($email['subject']); ?></td>
                                            <td>
                                                <?php 
                                                if ($email['recipient_group'] === 'all') {
                                                    echo 'All Users';
                                                } elseif ($email['recipient_group'] === 'standard') {
                                                    echo 'Standard Users';
                                                } elseif ($email['recipient_group'] === 'premium') {
                                                    echo 'Premium Users';
                                                } elseif ($email['recipient_group'] === 'inactive') {
                                                    echo 'Inactive Users';
                                                } else {
                                                    echo htmlspecialchars($email['recipient_group']);
                                                }
                                                ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($email['sent_by_name']); ?></td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="me-2">
                                                        <span class="badge bg-success"><?php echo $email['sent_count']; ?> sent</span>
                                                        <?php if ($email['failed_count'] > 0): ?>
                                                            <span class="badge bg-danger"><?php echo $email['failed_count']; ?> failed</span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?php echo date('M d, Y H:i', strtotime($email['created_at'])); ?></td>
                                            <td>
                                                <a href="index.php?page=admin&section=email-view&id=<?php echo $email['id']; ?>" class="btn btn-sm btn-info">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center">No mass emails have been sent yet.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize rich text editor for email content
    if (typeof ClassicEditor !== 'undefined') {
        ClassicEditor
            .create(document.querySelector('#email_content'))
            .catch(error => {
                console.error(error);
            });
    }
});
</script>

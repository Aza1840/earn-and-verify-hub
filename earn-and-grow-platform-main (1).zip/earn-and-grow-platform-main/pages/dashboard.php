
<?php
// Get user data
$userId = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Get user balance
$balance = getUserBalance($userId);
$tasksCompleted = getUserTaskCount($userId);
$pendingDeposits = getPendingDeposits($userId);
$pendingWithdrawals = getPendingWithdrawals($userId);
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mb-0">Rewards Dashboard</h1>
        <div class="user-avatar">
            <img src="assets/img/avatar-placeholder.png" alt="User Avatar" class="rounded-circle" width="50">
        </div>
    </div>
    
    <!-- Balance Card -->
    <div class="card mb-4 bg-light">
        <div class="card-body">
            <div class="row align-items-center">
                <div class="col">
                    <h2 class="display-4 mb-0">$<?php echo number_format($balance, 2); ?></h2>
                    <p class="text-muted mb-0">Account Balance</p>
                    <p class="text-success"><i class="fas fa-arrow-up me-1"></i> Available for withdrawal</p>
                </div>
                <div class="col-auto">
                    <div class="bg-primary bg-opacity-10 p-3 rounded-circle">
                        <i class="fas fa-wallet text-primary fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <!-- Tasks Completed Card -->
        <div class="col-md-4 mb-4">
            <div class="card h-100 bg-info bg-opacity-10">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <h2 class="display-4 mb-0"><?php echo $tasksCompleted; ?></h2>
                            <p class="text-muted mb-0">Tasks Completed</p>
                            <p class="text-info">Videos and other activities</p>
                        </div>
                        <div class="col-auto">
                            <div class="bg-info bg-opacity-10 p-3 rounded-circle">
                                <i class="fas fa-check-circle text-info fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Pending Deposits Card -->
        <div class="col-md-4 mb-4">
            <div class="card h-100 bg-warning bg-opacity-10">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <h2 class="display-4 mb-0"><?php echo $pendingDeposits; ?></h2>
                            <p class="text-muted mb-0">Pending Deposits</p>
                            <p class="text-warning">Awaiting approval</p>
                        </div>
                        <div class="col-auto">
                            <div class="bg-warning bg-opacity-10 p-3 rounded-circle">
                                <i class="fas fa-clock text-warning fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Pending Withdrawals Card -->
        <div class="col-md-4 mb-4">
            <div class="card h-100 bg-danger bg-opacity-10">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col">
                            <h2 class="display-4 mb-0"><?php echo $pendingWithdrawals; ?></h2>
                            <p class="text-muted mb-0">Pending Withdrawals</p>
                            <p class="text-danger">Processing requests</p>
                        </div>
                        <div class="col-auto">
                            <div class="bg-danger bg-opacity-10 p-3 rounded-circle">
                                <i class="fas fa-hourglass-half text-danger fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Quick Actions -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card h-100 bg-primary bg-opacity-10">
                <div class="card-body">
                    <h4 class="card-title text-primary">Quick Actions</h4>
                    <div class="row">
                        <div class="col-6 mb-3">
                            <a href="index.php?page=dashboard-videos" class="btn btn-outline-primary w-100 h-100 d-flex flex-column align-items-center justify-content-center p-3">
                                <i class="fas fa-play-circle fa-2x mb-2"></i>
                                <span>Watch Videos</span>
                            </a>
                        </div>
                        <div class="col-6 mb-3">
                            <a href="index.php?page=dashboard-wallet" class="btn btn-outline-primary w-100 h-100 d-flex flex-column align-items-center justify-content-center p-3">
                                <i class="fas fa-wallet fa-2x mb-2"></i>
                                <span>My Wallet</span>
                            </a>
                        </div>
                        <div class="col-6 mb-3">
                            <a href="index.php?page=dashboard-withdraw" class="btn btn-outline-primary w-100 h-100 d-flex flex-column align-items-center justify-content-center p-3">
                                <i class="fas fa-arrow-up fa-2x mb-2"></i>
                                <span>Withdraw</span>
                            </a>
                        </div>
                        <div class="col-6 mb-3">
                            <a href="index.php?page=dashboard-referrals" class="btn btn-outline-primary w-100 h-100 d-flex flex-column align-items-center justify-content-center p-3">
                                <i class="fas fa-users fa-2x mb-2"></i>
                                <span>Referrals</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0">Your Referral Link</h5>
                </div>
                <div class="card-body">
                    <p class="text-muted">Share this link with friends and earn rewards for each new sign-up!</p>
                    
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" value="<?php echo 'https://' . $_SERVER['HTTP_HOST'] . '/index.php?page=register&ref=' . $user['referral_code']; ?>" id="referralLink" readonly>
                        <button class="btn btn-outline-primary" type="button" onclick="copyReferralLink()">
                            <i class="fas fa-copy"></i>
                        </button>
                    </div>
                    
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="text-muted">
                            <i class="fas fa-users me-1"></i> 
                            <?php 
                            $sql = "SELECT COUNT(*) as total FROM users WHERE referred_by = ?";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("i", $userId);
                            $stmt->execute();
                            $result = $stmt->get_result();
                            $referrals = $result->fetch_assoc()['total'];
                            echo $referrals . ' referrals';
                            ?>
                        </span>
                        <a href="index.php?page=dashboard-referrals" class="btn btn-sm btn-outline-primary">View Details</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Latest Tasks -->
    <div class="card mb-4">
        <div class="card-header bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Latest Available Tasks</h5>
                <a href="index.php?page=tasks" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
            <?php
            // Get latest tasks
            $sql = "SELECT * FROM tasks ORDER BY created_at DESC LIMIT 3";
            $latestTasks = $conn->query($sql);

            if ($latestTasks->num_rows > 0) {
                while ($task = $latestTasks->fetch_assoc()) {
                    ?>
                    <div class="col-md-4 mb-3">
                        <div class="card h-100 task-card">
                            <div class="task-thumbnail">
                                <img src="<?php echo $task['thumbnail']; ?>" alt="<?php echo $task['title']; ?>" class="card-img-top">
                                <div class="task-reward badge bg-success">
                                    <?php echo $task['reward']; ?> credits
                                    <?php if ($user['is_premium']): ?>
                                        <span class="ms-1"><i class="fas fa-crown" data-bs-toggle="tooltip" title="2x for premium users"></i></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $task['title']; ?></h5>
                                <p class="card-text small text-muted"><?php echo substr($task['description'], 0, 60); ?>...</p>
                            </div>
                            <div class="card-footer bg-white d-flex justify-content-between align-items-center">
                                <small class="text-muted">
                                    <i class="fas fa-clock me-1"></i> 
                                    <?php echo $task['type'] === 'video' ? $task['duration'] . ' mins' : 'Reading'; ?>
                                </small>
                                <a href="index.php?page=task&id=<?php echo $task['id']; ?>" class="btn btn-sm btn-primary">
                                    Start Task
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo '<div class="col-12"><div class="alert alert-info">No tasks available at the moment.</div></div>';
            }
            ?>
            </div>
        </div>
    </div>
</div>

<!-- Mobile Sidebar Menu (Shows on small screens) -->
<div class="modal fade" id="sidebarModal" tabindex="-1" aria-labelledby="sidebarModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen-sm-down">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="sidebarModalLabel">Menu</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div class="list-group list-group-flush">
                    <a href="index.php?page=dashboard" class="list-group-item list-group-item-action active">
                        <i class="fas fa-home me-2"></i> Dashboard
                    </a>
                    <a href="index.php?page=dashboard-videos" class="list-group-item list-group-item-action">
                        <i class="fas fa-play-circle me-2"></i> Videos
                    </a>
                    <a href="index.php?page=dashboard-news" class="list-group-item list-group-item-action">
                        <i class="fas fa-newspaper me-2"></i> News
                    </a>
                    <a href="index.php?page=dashboard-referrals" class="list-group-item list-group-item-action">
                        <i class="fas fa-users me-2"></i> Referrals
                    </a>
                    <a href="index.php?page=dashboard-wallet" class="list-group-item list-group-item-action">
                        <i class="fas fa-wallet me-2"></i> Wallet
                    </a>
                    <a href="index.php?page=dashboard-deposit" class="list-group-item list-group-item-action">
                        <i class="fas fa-arrow-down me-2"></i> Deposit
                    </a>
                    <a href="index.php?page=dashboard-withdraw" class="list-group-item list-group-item-action">
                        <i class="fas fa-arrow-up me-2"></i> Withdraw
                    </a>
                    <a href="index.php?page=dashboard-convert" class="list-group-item list-group-item-action">
                        <i class="fas fa-exchange-alt me-2"></i> Convert
                    </a>
                    <a href="index.php?page=dashboard-kyc" class="list-group-item list-group-item-action">
                        <i class="fas fa-id-card me-2"></i> KYC
                    </a>
                    <a href="index.php?page=dashboard-leaderboard" class="list-group-item list-group-item-action">
                        <i class="fas fa-trophy me-2"></i> Leaderboard
                    </a>
                </div>
                
                <div class="p-3 mt-4 border-top">
                    <h6 class="text-uppercase text-muted small">Status</h6>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Account Type</span>
                        <span class="badge bg-warning"><?php echo $user['is_premium'] ? 'Premium' : 'Standard'; ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Pending Deposits</span>
                        <span class="text-warning"><?php echo $pendingDeposits; ?> deposits</span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Pending Withdrawals</span>
                        <span class="text-danger"><?php echo $pendingWithdrawals; ?> withdrawals</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function copyReferralLink() {
    var copyText = document.getElementById("referralLink");
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    document.execCommand("copy");
    
    alert("Referral link copied to clipboard!");
}

document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
</script>


<div class="row justify-content-center">
    <div class="col-lg-5">
        <div class="card shadow-lg border-0 rounded-lg mt-5">
            <div class="card-header">
                <h3 class="text-center font-weight-bold my-4">Forgot Password</h3>
            </div>
            <div class="card-body">
                <?php
                // Process forgot password form
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    // Get form data
                    $email = clean_input($_POST["email"]);
                    
                    // Validate form
                    $errors = array();
                    
                    if (empty($email)) {
                        $errors[] = "Email is required";
                    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $errors[] = "Invalid email format";
                    }
                    
                    // If no errors, proceed with password reset
                    if (empty($errors)) {
                        // Check if email exists
                        $sql = "SELECT id, username FROM users WHERE email = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("s", $email);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        
                        if ($result->num_rows == 1) {
                            // Email exists, generate reset token
                            $user = $result->fetch_assoc();
                            $token = bin2hex(random_bytes(32));
                            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
                            
                            // Save token in database
                            $sql = "INSERT INTO password_resets (user_id, email, token, expires_at, created_at) 
                                    VALUES (?, ?, ?, ?, NOW())";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("isss", $user['id'], $email, $token, $expires);
                            $stmt->execute();
                            
                            // Send password reset email
                            $resetUrl = "http://" . $_SERVER['HTTP_HOST'] . "/index.php?page=reset-password&token=" . $token;
                            $subject = "Password Reset Request";
                            $message = "Dear " . $user['username'] . ",\n\n";
                            $message .= "You have requested to reset your password. Please click the link below to reset your password:\n\n";
                            $message .= $resetUrl . "\n\n";
                            $message .= "This link will expire in 1 hour.\n\n";
                            $message .= "If you did not request a password reset, please ignore this email or contact support if you have concerns.\n\n";
                            $message .= "Best regards,\nThe " . getSiteSettings()['site_name'] . " Team";
                            $headers = "From: no-reply@" . $_SERVER['HTTP_HOST'];
                            
                            // Attempt to send email
                            if (mail($email, $subject, $message, $headers)) {
                                $_SESSION['message'] = "A password reset link has been sent to your email address.";
                                header("Location: index.php?page=login");
                                exit;
                            } else {
                                $errors[] = "Failed to send password reset email. Please try again later.";
                            }
                        } else {
                            // Email not found, but we don't want to reveal this
                            $_SESSION['message'] = "If your email address exists in our database, you will receive a password recovery link at your email address.";
                            header("Location: index.php?page=login");
                            exit;
                        }
                    }
                    
                    // Display errors if any
                    if (!empty($errors)) {
                        echo '<div class="alert alert-danger">';
                        foreach ($errors as $error) {
                            echo $error . '<br>';
                        }
                        echo '</div>';
                    }
                }
                ?>
                <p class="text-muted mb-4">Enter your email address and we will send you a link to reset your password.</p>
                <form method="POST" action="index.php?page=forgot-password">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                            <input class="form-control" id="email" name="email" type="email" placeholder="Enter email address" required />
                        </div>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg">Reset Password</button>
                    </div>
                </form>
            </div>
            <div class="card-footer text-center py-3">
                <div class="small"><a href="index.php?page=login">Return to login</a></div>
            </div>
        </div>
    </div>
</div>


<?php
// Get user data
$userId = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Get user wallets
$sql = "SELECT * FROM user_wallets WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$wallets = $stmt->get_result();

// Get user balance
$balance = getUserBalance($userId);
$tasksCompleted = getUserTaskCount($userId);
$totalWithdrawals = 0;

$sql = "SELECT SUM(amount) as total FROM withdrawals WHERE user_id = ? AND status = 'approved'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $totalWithdrawals = $row['total'] ?? 0;
}

// Get premium balance (if premium user)
$premiumBalance = 0;
if ($user['is_premium']) {
    $premiumBalance = $balance; // This would be additional earnings from premium status
}
?>

<div class="row">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>My Wallet</h1>
            <div class="dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" id="walletActionsDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-wallet me-2"></i> Wallet Actions
                </button>
                <ul class="dropdown-menu" aria-labelledby="walletActionsDropdown">
                    <li><a class="dropdown-item" href="index.php?page=wallet"><i class="fas fa-wallet me-2"></i> My Wallets</a></li>
                    <li><a class="dropdown-item" href="index.php?page=withdraw"><i class="fas fa-arrow-up me-2"></i> Withdraw</a></li>
                    <li><a class="dropdown-item" href="index.php?page=deposit"><i class="fas fa-arrow-down me-2"></i> Deposit</a></li>
                    <li><a class="dropdown-item" href="index.php?page=convert"><i class="fas fa-exchange-alt me-2"></i> Convert</a></li>
                    <li><a class="dropdown-item" href="index.php?page=history"><i class="fas fa-history me-2"></i> History</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Balance Cards -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card stat-card balance h-100">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Available Balance</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $balance; ?> credits</div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-wallet fa-2x text-primary card-icon"></i>
                    </div>
                </div>
                <p class="text-muted small mb-0 mt-2">Updated just now</p>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card stat-card tasks h-100">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Tasks Performed</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $tasksCompleted; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-tasks fa-2x text-success card-icon"></i>
                    </div>
                </div>
                <p class="text-muted small mb-0 mt-2">Completed tasks</p>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card stat-card withdrawals h-100">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Total Withdrawals</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $totalWithdrawals; ?> credits</div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-arrow-up fa-2x text-danger card-icon"></i>
                    </div>
                </div>
                <p class="text-muted small mb-0 mt-2">All time</p>
            </div>
        </div>
    </div>

    <?php if ($user['is_premium']): ?>
    <div class="col-md-3">
        <div class="card stat-card premium h-100">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Premium Balance</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $premiumBalance; ?> bonus credits</div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-crown fa-2x text-warning card-icon"></i>
                    </div>
                </div>
                <p class="text-muted small mb-0 mt-2">Premium earnings</p>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="col-md-3">
        <div class="card h-100">
            <div class="card-body text-center">
                <i class="fas fa-crown text-warning fa-3x mb-3"></i>
                <h5>Upgrade to Premium</h5>
                <p class="small text-muted">Get 2x rewards on all tasks</p>
                <a href="index.php?page=upgrade" class="btn btn-sm btn-warning">Upgrade Now</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Cryptocurrency Wallets -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">My Cryptocurrency Wallets</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <?php 
            // Define available cryptocurrencies
            $cryptocurrencies = [
                'bitcoin' => ['name' => 'Bitcoin', 'symbol' => 'BTC', 'icon' => 'fab fa-bitcoin'],
                'ethereum' => ['name' => 'Ethereum', 'symbol' => 'ETH', 'icon' => 'fab fa-ethereum'],
                'usdt' => ['name' => 'Tether', 'symbol' => 'USDT', 'icon' => 'fas fa-dollar-sign'],
                'solana' => ['name' => 'Solana', 'symbol' => 'SOL', 'icon' => 'fas fa-sun'],
                'ada' => ['name' => 'Cardano', 'symbol' => 'ADA', 'icon' => 'fas fa-atom'],
                'avax' => ['name' => 'Avalanche', 'symbol' => 'AVAX', 'icon' => 'fas fa-mountain'],
                'doge' => ['name' => 'Dogecoin', 'symbol' => 'DOGE', 'icon' => 'fas fa-dog'],
                'ton' => ['name' => 'Toncoin', 'symbol' => 'TON', 'icon' => 'fas fa-paper-plane']
            ];
            
            // Create array to store user's wallet addresses
            $userWallets = [];
            while ($wallet = $wallets->fetch_assoc()) {
                $userWallets[$wallet['crypto_type']] = $wallet['wallet_address'];
            }
            
            // Display wallets
            foreach ($cryptocurrencies as $crypto => $details) {
                $address = isset($userWallets[$crypto]) ? $userWallets[$crypto] : '';
            ?>
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3">
                                <div class="bg-primary bg-opacity-10 p-2 rounded me-3">
                                    <i class="<?php echo $details['icon']; ?> fa-2x text-primary"></i>
                                </div>
                                <div>
                                    <h5 class="mb-0"><?php echo $details['name']; ?> (<?php echo $details['symbol']; ?>)</h5>
                                </div>
                            </div>
                            
                            <?php if (!empty($address)): ?>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" value="<?php echo $address; ?>" readonly>
                                    <button class="btn btn-outline-secondary" type="button" onclick="copyToClipboard('<?php echo $address; ?>')">
                                        <i class="fas fa-copy"></i>
                                    </button>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editWalletModal" data-crypto="<?php echo $crypto; ?>" data-address="<?php echo $address; ?>">
                                        <i class="fas fa-edit me-1"></i> Edit
                                    </button>
                                    <a href="index.php?page=withdraw&crypto=<?php echo $crypto; ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-arrow-up me-1"></i> Withdraw
                                    </a>
                                </div>
                            <?php else: ?>
                                <p class="text-muted mb-3">No wallet address added yet.</p>
                                <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#editWalletModal" data-crypto="<?php echo $crypto; ?>" data-address="">
                                    <i class="fas fa-plus me-1"></i> Add <?php echo $details['name']; ?> Wallet
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>

<!-- Edit Wallet Modal -->
<div class="modal fade" id="editWalletModal" tabindex="-1" aria-labelledby="editWalletModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="actions/save_wallet.php" method="post">
                <div class="modal-header">
                    <h5 class="modal-title" id="editWalletModalLabel">Edit Wallet Address</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="crypto_type" id="crypto_type">
                    <div class="mb-3">
                        <label for="wallet_address" class="form-label">Wallet Address</label>
                        <input type="text" class="form-control" id="wallet_address" name="wallet_address" required>
                        <div class="form-text">Enter your wallet address for withdrawals.</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Function to copy wallet address to clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        alert('Wallet address copied to clipboard');
    }, function(err) {
        console.error('Could not copy text: ', err);
    });
}

// Set wallet data in modal when opened
document.addEventListener('DOMContentLoaded', function() {
    const editWalletModal = document.getElementById('editWalletModal');
    if (editWalletModal) {
        editWalletModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            const crypto = button.getAttribute('data-crypto');
            const address = button.getAttribute('data-address');
            
            const cryptoTypeInput = editWalletModal.querySelector('#crypto_type');
            const walletAddressInput = editWalletModal.querySelector('#wallet_address');
            
            cryptoTypeInput.value = crypto;
            walletAddressInput.value = address;
            
            const modalTitle = editWalletModal.querySelector('.modal-title');
            if (address) {
                modalTitle.textContent = 'Edit Wallet Address';
            } else {
                modalTitle.textContent = 'Add New Wallet Address';
            }
        });
    }
});
</script>

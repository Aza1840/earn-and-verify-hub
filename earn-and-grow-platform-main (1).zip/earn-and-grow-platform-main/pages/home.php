
<div class="row">
    <div class="col-lg-6">
        <div class="p-5">
            <h1 class="display-4 fw-bold mb-4">Complete Tasks, <span class="text-primary">Earn Rewards</span></h1>
            <p class="lead mb-4">Watch videos, read news, complete simple tasks, and earn rewards that you can withdraw as cryptocurrency.</p>
            <div class="d-flex flex-column flex-sm-row gap-3">
                <?php if (!isLoggedIn()): ?>
                    <a href="index.php?page=register" class="btn btn-primary btn-lg">
                        Create Account <i class="fas fa-arrow-right ms-2"></i>
                    </a>
                    <a href="index.php?page=login" class="btn btn-outline-secondary btn-lg">Sign In</a>
                <?php else: ?>
                    <a href="index.php?page=dashboard" class="btn btn-primary btn-lg">
                        Go to Dashboard <i class="fas fa-arrow-right ms-2"></i>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card shadow-sm border p-4">
            <div class="d-flex justify-content-between mb-4">
                <div>
                    <h3 class="fw-bold">Your Earnings</h3>
                    <p class="text-muted">Complete tasks to earn more</p>
                </div>
                <div class="bg-primary bg-opacity-10 rounded-circle p-3">
                    <i class="fas fa-wallet text-primary fa-2x"></i>
                </div>
            </div>
            <div class="mb-4">
                <div class="p-3 rounded bg-light mb-3 d-flex justify-content-between align-items-center">
                    <div>
                        <p class="fw-bold mb-1">Watch Video Tasks</p>
                        <p class="small text-muted mb-0">10-15 credits per task</p>
                    </div>
                    <i class="fas fa-play text-primary"></i>
                </div>
                <div class="p-3 rounded bg-light mb-3 d-flex justify-content-between align-items-center">
                    <div>
                        <p class="fw-bold mb-1">Read News Articles</p>
                        <p class="small text-muted mb-0">5-8 credits per article</p>
                    </div>
                    <i class="fas fa-newspaper text-primary"></i>
                </div>
                <div class="p-3 rounded bg-light mb-3 d-flex justify-content-between align-items-center">
                    <div>
                        <p class="fw-bold mb-1">Refer Friends</p>
                        <p class="small text-muted mb-0">20 credits per referral</p>
                    </div>
                    <i class="fas fa-users text-primary"></i>
                </div>
            </div>
        </div>
        <div class="position-absolute end-0 bottom-0 bg-warning text-white rounded px-3 py-2 shadow">
            <div class="d-flex align-items-center">
                <div class="bg-white bg-opacity-25 rounded-circle p-1 me-2">
                    <i class="fas fa-check-circle"></i>
                </div>
                <p class="fw-bold small mb-0">2x for Premium Users</p>
            </div>
        </div>
    </div>
</div>

<section class="py-5 bg-light mt-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fs-1 fw-bold mb-3">How It Works</h2>
            <p class="lead text-muted mx-auto" style="max-width: 600px;">
                Earn rewards by completing simple tasks on our platform and withdraw to your cryptocurrency wallet.
            </p>
        </div>
        
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card h-100 border shadow-sm">
                    <div class="card-body">
                        <div class="bg-primary bg-opacity-10 rounded-circle p-3 d-inline-block mb-3">
                            <i class="fas fa-play text-primary fa-2x"></i>
                        </div>
                        <h3 class="fs-4 fw-bold mb-2">Watch Videos</h3>
                        <p class="text-muted">
                            Watch educational videos about cryptocurrency, finance, and other topics to earn rewards.
                        </p>
                        <a href="index.php?page=videos" class="btn btn-link ps-0">
                            Browse Videos <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-4">
                <div class="card h-100 border shadow-sm">
                    <div class="card-body">
                        <div class="bg-primary bg-opacity-10 rounded-circle p-3 d-inline-block mb-3">
                            <i class="fas fa-newspaper text-primary fa-2x"></i>
                        </div>
                        <h3 class="fs-4 fw-bold mb-2">Read News</h3>
                        <p class="text-muted">
                            Stay informed with the latest news articles while earning rewards for reading.
                        </p>
                        <a href="index.php?page=news" class="btn btn-link ps-0">
                            Browse News <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-4">
                <div class="card h-100 border shadow-sm">
                    <div class="card-body">
                        <div class="bg-primary bg-opacity-10 rounded-circle p-3 d-inline-block mb-3">
                            <i class="fas fa-wallet text-primary fa-2x"></i>
                        </div>
                        <h3 class="fs-4 fw-bold mb-2">Get Paid</h3>
                        <p class="text-muted">
                            Withdraw your earnings to your preferred cryptocurrency wallet once you reach the minimum threshold.
                        </p>
                        <a href="index.php?page=wallet" class="btn btn-link ps-0">
                            Learn More <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="bg-gradient-to-r text-white rounded-3 p-5" style="background: linear-gradient(to right, #f6c23e, #e0a800);">
            <div class="row align-items-center">
                <div class="col-lg-8 mb-4 mb-lg-0">
                    <h2 class="fs-1 fw-bold mb-3">Upgrade to Premium</h2>
                    <p class="mb-4">
                        Premium users earn 2x rewards on all completed tasks! Upgrade your account to maximize your earnings.
                    </p>
                    <ul class="list-unstyled mb-4">
                        <li class="mb-2"><i class="fas fa-check-circle me-2"></i> 2x multiplier on all task rewards</li>
                        <li class="mb-2"><i class="fas fa-check-circle me-2"></i> Priority withdrawal processing</li>
                        <li class="mb-2"><i class="fas fa-check-circle me-2"></i> Access to exclusive premium tasks</li>
                    </ul>
                    <a href="index.php?page=upgrade" class="btn btn-light text-warning fw-bold">Upgrade Now</a>
                </div>
                <div class="col-lg-4">
                    <div class="bg-white bg-opacity-20 backdrop-filter rounded-3 p-4 border border-white border-opacity-25 text-center shadow">
                        <h3 class="fs-3 fw-bold mb-2">2x</h3>
                        <p class="small mb-3">Reward Multiplier</p>
                        <div class="fs-1 fw-bold mb-2">
                            <span class="text-decoration-line-through text-white text-opacity-60 me-2 fs-5">1x</span>
                            2x
                        </div>
                        <p class="small text-white text-opacity-75">
                            All earnings are doubled for premium users
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fs-1 fw-bold mb-3">Ready to Start Earning?</h2>
            <p class="lead text-muted mx-auto mb-4" style="max-width: 700px;">
                Join our platform today and start completing tasks to earn rewards that you can withdraw to your cryptocurrency wallet.
            </p>
            <div class="d-flex flex-column flex-sm-row gap-3 justify-content-center">
                <?php if (!isLoggedIn()): ?>
                    <a href="index.php?page=register" class="btn btn-primary btn-lg">
                        Create Account <i class="fas fa-arrow-right ms-2"></i>
                    </a>
                    <a href="index.php?page=login" class="btn btn-outline-secondary btn-lg">Sign In</a>
                <?php else: ?>
                    <a href="index.php?page=dashboard" class="btn btn-primary btn-lg">
                        Go to Dashboard <i class="fas fa-arrow-right ms-2"></i>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

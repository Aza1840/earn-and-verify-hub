
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-5">
            <div class="card shadow-lg border-0 rounded-lg mt-5">
                <div class="card-header bg-white text-center py-4">
                    <h3 class="font-weight-bold my-2">User Login</h3>
                    <p class="text-muted mb-0">Sign in to access your account</p>
                </div>
                <div class="card-body">
                    <?php
                    // Process login form
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        // Get form data
                        $email = clean_input($_POST["email"]);
                        $password = $_POST["password"];
                        
                        // Validate form
                        $errors = array();
                        
                        if (empty($email)) {
                            $errors[] = "Email is required";
                        }
                        
                        if (empty($password)) {
                            $errors[] = "Password is required";
                        }
                        
                        // If no errors, proceed with login
                        if (empty($errors)) {
                            // Check user credentials, exclude admin accounts
                            $sql = "SELECT id, username, email, password, role, is_premium FROM users WHERE email = ? AND role != 'admin'";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("s", $email);
                            $stmt->execute();
                            $result = $stmt->get_result();
                            
                            if ($result->num_rows == 1) {
                                $user = $result->fetch_assoc();
                                
                                // Verify password
                                if (password_verify($password, $user["password"])) {
                                    // Password is correct, start a new session
                                    session_start();
                                    
                                    // Store data in session variables
                                    $_SESSION["user_id"] = $user["id"];
                                    $_SESSION["username"] = $user["username"];
                                    $_SESSION["email"] = $user["email"];
                                    $_SESSION["user_role"] = $user["role"];
                                    $_SESSION["is_premium"] = $user["is_premium"];
                                    
                                    // Log activity
                                    $sql = "INSERT INTO activities (user_id, activity_type, description, created_at) 
                                            VALUES (?, 'login', ?, NOW())";
                                    $stmt = $conn->prepare($sql);
                                    $description = "User logged in from IP: " . $_SERVER['REMOTE_ADDR'];
                                    $stmt->bind_param("is", $user["id"], $description);
                                    $stmt->execute();
                                    
                                    // Redirect to user dashboard
                                    header("Location: index.php?page=dashboard");
                                    exit;
                                } else {
                                    $errors[] = "Invalid email or password";
                                }
                            } else {
                                $errors[] = "Invalid email or password";
                            }
                        }
                        
                        // Display errors if any
                        if (!empty($errors)) {
                            echo '<div class="alert alert-danger">';
                            foreach ($errors as $error) {
                                echo $error . '<br>';
                            }
                            echo '</div>';
                        }
                    }

                    // Display session messages if any
                    if (isset($_SESSION['message'])) {
                        echo '<div class="alert alert-info">' . $_SESSION['message'] . '</div>';
                        unset($_SESSION['message']);
                    }
                    ?>
                    <form method="POST" action="index.php?page=login">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                <input class="form-control" id="email" name="email" type="email" placeholder="Enter your email" required />
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                <input class="form-control" id="password" name="password" type="password" placeholder="Enter your password" required />
                            </div>
                        </div>
                        <div class="d-flex justify-content-between mb-3">
                            <div class="form-check">
                                <input class="form-check-input" id="remember" name="remember" type="checkbox" />
                                <label class="form-check-label" for="remember">Remember me</label>
                            </div>
                            <a href="index.php?page=forgot-password" class="text-primary">Forgot password?</a>
                        </div>
                        <div class="d-grid mb-3">
                            <button type="submit" class="btn btn-primary btn-lg">Login</button>
                        </div>
                    </form>
                    
                    <div class="mt-4 mb-2 text-center">
                        <div class="separator">
                            <span class="separator-text">or</span>
                        </div>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <a href="index.php?page=admin-login" class="btn btn-outline-secondary">
                            <i class="fas fa-user-shield me-2"></i>Administrator Login
                        </a>
                    </div>
                </div>
                <div class="card-footer bg-light text-center py-3">
                    <div class="small">Don't have an account? <a href="index.php?page=register" class="text-primary fw-bold">Sign up!</a></div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.separator {
    display: flex;
    align-items: center;
    text-align: center;
    margin: 10px 0;
}

.separator::before,
.separator::after {
    content: '';
    flex: 1;
    border-bottom: 1px solid #ddd;
}

.separator-text {
    padding: 0 10px;
    color: #888;
}
</style>

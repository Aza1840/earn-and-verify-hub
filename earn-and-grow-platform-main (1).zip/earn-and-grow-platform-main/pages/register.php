
<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow-lg border-0 rounded-lg mt-5">
            <div class="card-header">
                <h3 class="text-center font-weight-bold my-4">Create Account</h3>
            </div>
            <div class="card-body">
                <?php
                // Process registration form
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    // Get form data
                    $username = clean_input($_POST["username"]);
                    $email = clean_input($_POST["email"]);
                    $password = $_POST["password"];
                    $confirmPassword = $_POST["confirm_password"];
                    $referralCode = isset($_POST["referral_code"]) ? clean_input($_POST["referral_code"]) : null;
                    
                    // Validate form
                    $errors = array();
                    
                    if (empty($username)) {
                        $errors[] = "Username is required";
                    } elseif (!preg_match("/^[a-zA-Z0-9_]+$/", $username)) {
                        $errors[] = "Username can only contain letters, numbers, and underscores";
                    }
                    
                    if (empty($email)) {
                        $errors[] = "Email is required";
                    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $errors[] = "Invalid email format";
                    }
                    
                    if (empty($password)) {
                        $errors[] = "Password is required";
                    } elseif (strlen($password) < 6) {
                        $errors[] = "Password must be at least 6 characters";
                    }
                    
                    if ($password != $confirmPassword) {
                        $errors[] = "Passwords do not match";
                    }
                    
                    // Check if username already exists
                    $sql = "SELECT id FROM users WHERE username = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("s", $username);
                    $stmt->execute();
                    $stmt->store_result();
                    if ($stmt->num_rows > 0) {
                        $errors[] = "Username already exists";
                    }
                    
                    // Check if email already exists
                    $sql = "SELECT id FROM users WHERE email = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("s", $email);
                    $stmt->execute();
                    $stmt->store_result();
                    if ($stmt->num_rows > 0) {
                        $errors[] = "Email already exists";
                    }
                    
                    // Check referral code if provided
                    $referrerId = null;
                    if (!empty($referralCode)) {
                        $sql = "SELECT id FROM users WHERE referral_code = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("s", $referralCode);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        if ($result->num_rows === 1) {
                            $row = $result->fetch_assoc();
                            $referrerId = $row['id'];
                        } else {
                            $errors[] = "Invalid referral code";
                        }
                    }
                    
                    // If no errors, register user
                    if (empty($errors)) {
                        // Hash password
                        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                        
                        // Generate unique referral code
                        $newReferralCode = substr(md5(uniqid(rand(), true)), 0, 8);
                        
                        // Insert user into database
                        $sql = "INSERT INTO users (username, email, password, referral_code, referred_by, role, is_premium, created_at) VALUES (?, ?, ?, ?, ?, 'user', 0, NOW())";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("ssssi", $username, $email, $hashedPassword, $newReferralCode, $referrerId);
                        
                        if ($stmt->execute()) {
                            $userId = $stmt->insert_id;
                            
                            // Add referral reward if referred by someone
                            if ($referrerId) {
                                $rewardAmount = 20; // 20 credits for referral
                                
                                // Add reward to referrer's balance
                                $sql = "UPDATE users SET balance = balance + ? WHERE id = ?";
                                $stmt = $conn->prepare($sql);
                                $stmt->bind_param("di", $rewardAmount, $referrerId);
                                $stmt->execute();
                                
                                // Record the referral reward
                                $sql = "INSERT INTO transactions (user_id, amount, type, description, status, created_at) VALUES (?, ?, 'referral', ?, 'completed', NOW())";
                                $stmt = $conn->prepare($sql);
                                $description = "Referral reward for referring " . $username;
                                $stmt->bind_param("ids", $referrerId, $rewardAmount, $description);
                                $stmt->execute();
                            }
                            
                            // Registration successful, redirect to login
                            $_SESSION['message'] = "Registration successful. You can now login.";
                            header("Location: index.php?page=login");
                            exit;
                        } else {
                            $errors[] = "Registration failed. Please try again later.";
                        }
                    }
                    
                    // Display errors if any
                    if (!empty($errors)) {
                        echo '<div class="alert alert-danger">';
                        foreach ($errors as $error) {
                            echo $error . '<br>';
                        }
                        echo '</div>';
                    }
                }
                ?>
                <form method="POST" action="index.php?page=register">
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input class="form-control" id="username" name="username" type="text" placeholder="Enter username" required />
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input class="form-control" id="email" name="email" type="email" placeholder="Enter email address" required />
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="mb-3 mb-md-0">
                                <label for="password" class="form-label">Password</label>
                                <input class="form-control" id="password" name="password" type="password" placeholder="Create a password" required />
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div>
                                <label for="confirm_password" class="form-label">Confirm Password</label>
                                <input class="form-control" id="confirm_password" name="confirm_password" type="password" placeholder="Confirm password" required />
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="referral_code" class="form-label">Referral Code (optional)</label>
                        <input class="form-control" id="referral_code" name="referral_code" type="text" placeholder="Enter referral code if you have one" />
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" id="terms" name="terms" type="checkbox" required />
                            <label class="form-check-label" for="terms">I agree to the terms and conditions</label>
                        </div>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg">Register</button>
                    </div>
                </form>
            </div>
            <div class="card-footer text-center py-3">
                <div class="small"><a href="index.php?page=login">Have an account? Go to login</a></div>
            </div>
        </div>
    </div>
</div>

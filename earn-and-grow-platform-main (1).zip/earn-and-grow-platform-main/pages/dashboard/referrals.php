
<?php
// Get user data
$userId = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Check if user has a referral code
if (!$user['referral_code']) {
    // Generate a new referral code
    $referralCode = generateReferralCode();
    $sql = "UPDATE users SET referral_code = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $referralCode, $userId);
    $stmt->execute();
    $user['referral_code'] = $referralCode;
}

// Get referral statistics
$sql = "SELECT COUNT(*) as total FROM users WHERE referred_by = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$totalReferrals = $stmt->get_result()->fetch_assoc()['total'] ?? 0;

// Get active referrals (users who completed at least one task)
$sql = "SELECT COUNT(DISTINCT u.id) as active 
        FROM users u 
        JOIN completed_tasks ct ON u.id = ct.user_id 
        WHERE u.referred_by = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$activeReferrals = $stmt->get_result()->fetch_assoc()['active'] ?? 0;

// Get total earnings from referrals
$sql = "SELECT SUM(amount) as total FROM transactions 
        WHERE user_id = ? AND type = 'referral' AND status = 'completed'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$referralEarnings = $stmt->get_result()->fetch_assoc()['total'] ?? 0;

// Get last 5 referrals
$sql = "SELECT u.*, COUNT(ct.id) as tasks_completed 
        FROM users u 
        LEFT JOIN completed_tasks ct ON u.id = ct.user_id 
        WHERE u.referred_by = ? 
        GROUP BY u.id 
        ORDER BY u.created_at DESC 
        LIMIT 5";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$recentReferrals = $stmt->get_result();
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mb-0">Referrals</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="index.php?page=dashboard">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Referrals</li>
            </ol>
        </nav>
    </div>

    <div class="row">
        <div class="col-lg-4 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Your Referral Link</h5>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" value="<?php echo $_SERVER['HTTP_HOST']; ?>/?ref=<?php echo $user['referral_code']; ?>" id="referralLink" readonly>
                        <button class="btn btn-primary" type="button" onclick="copyReferralLink()">Copy</button>
                    </div>
                    <p class="card-text text-muted small">Share this link with your friends and earn rewards when they join and complete tasks!</p>
                    
                    <div class="mt-4">
                        <h5>Share via</h5>
                        <div class="d-flex gap-2 mt-2">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode('https://' . $_SERVER['HTTP_HOST'] . '/?ref=' . $user['referral_code']); ?>" target="_blank" class="btn btn-sm btn-primary">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="https://twitter.com/intent/tweet?text=<?php echo urlencode('Join me on this amazing platform and earn rewards! Use my referral link:'); ?>&url=<?php echo urlencode('https://' . $_SERVER['HTTP_HOST'] . '/?ref=' . $user['referral_code']); ?>" target="_blank" class="btn btn-sm btn-info">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a href="https://wa.me/?text=<?php echo urlencode('Join me on this amazing platform and earn rewards! Use my referral link: https://' . $_SERVER['HTTP_HOST'] . '/?ref=' . $user['referral_code']); ?>" target="_blank" class="btn btn-sm btn-success">
                                <i class="fab fa-whatsapp"></i>
                            </a>
                            <a href="https://telegram.me/share/url?url=<?php echo urlencode('https://' . $_SERVER['HTTP_HOST'] . '/?ref=' . $user['referral_code']); ?>&text=<?php echo urlencode('Join me on this amazing platform and earn rewards! Use my referral link:'); ?>" target="_blank" class="btn btn-sm btn-info">
                                <i class="fab fa-telegram"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-8 mb-4">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card bg-primary text-white h-100">
                        <div class="card-body">
                            <h5 class="card-title">Total Referrals</h5>
                            <h2 class="mb-0"><?php echo $totalReferrals; ?></h2>
                            <p class="text-light mb-0"><?php echo $activeReferrals; ?> active users</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card bg-success text-white h-100">
                        <div class="card-body">
                            <h5 class="card-title">Earnings</h5>
                            <h2 class="mb-0"><?php echo $referralEarnings; ?> credits</h2>
                            <p class="text-light mb-0">From referral rewards</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card bg-info text-white h-100">
                        <div class="card-body">
                            <h5 class="card-title">Referral Bonus</h5>
                            <?php
                            // Get referral bonus from settings
                            $settings = getSiteSettings();
                            $referralBonus = isset($settings['referral_bonus']) ? $settings['referral_bonus'] : 20;
                            ?>
                            <h2 class="mb-0"><?php echo $referralBonus; ?> credits</h2>
                            <p class="text-light mb-0">Per active referral</p>
                        </div>
                    </div>
                </div>
            </div>
        
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Recent Referrals</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Joined</th>
                                    <th>Tasks</th>
                                    <th>Status</th>
                                    <th>Earnings</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($recentReferrals->num_rows > 0) {
                                    while ($referral = $recentReferrals->fetch_assoc()) {
                                        // Calculate earnings from this referral
                                        $sql = "SELECT SUM(amount) as earnings FROM transactions 
                                                WHERE user_id = ? AND type = 'referral' AND status = 'completed'
                                                AND description LIKE ?";
                                        $stmt = $conn->prepare($sql);
                                        $desc = "%referral from user {$referral['id']}%";
                                        $stmt->bind_param("is", $userId, $desc);
                                        $stmt->execute();
                                        $earnings = $stmt->get_result()->fetch_assoc()['earnings'] ?? 0;
                                        ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="avatar-sm me-2 bg-light rounded-circle text-center" style="width: 32px; height: 32px; line-height: 32px;">
                                                        <?php if ($referral['profile_picture']): ?>
                                                            <img src="<?php echo $referral['profile_picture']; ?>" alt="Avatar" class="rounded-circle" style="width: 32px; height: 32px;">
                                                        <?php else: ?>
                                                            <span class="text-primary"><?php echo substr($referral['username'], 0, 1); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div>
                                                        <?php echo $referral['username']; ?>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?php echo date('M j, Y', strtotime($referral['created_at'])); ?></td>
                                            <td><?php echo $referral['tasks_completed']; ?></td>
                                            <td>
                                                <?php if ($referral['tasks_completed'] > 0): ?>
                                                    <span class="badge bg-success">Active</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">Inactive</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo $earnings; ?> credits</td>
                                        </tr>
                                        <?php
                                    }
                                } else {
                                    echo '<tr><td colspan="5" class="text-center">No referrals yet. Share your referral link to start earning!</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="card mt-4">
        <div class="card-header">
            <h5 class="mb-0">How It Works</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="text-center">
                        <div class="bg-light rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" style="width: 80px; height: 80px;">
                            <i class="fas fa-share-alt fa-2x text-primary"></i>
                        </div>
                        <h5>1. Share Your Link</h5>
                        <p class="text-muted">Share your unique referral link with friends, family, or on social media.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="text-center">
                        <div class="bg-light rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" style="width: 80px; height: 80px;">
                            <i class="fas fa-user-plus fa-2x text-primary"></i>
                        </div>
                        <h5>2. Friends Sign Up</h5>
                        <p class="text-muted">When someone uses your link to sign up, they become your referral.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="text-center">
                        <div class="bg-light rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" style="width: 80px; height: 80px;">
                            <i class="fas fa-coins fa-2x text-primary"></i>
                        </div>
                        <h5>3. Earn Rewards</h5>
                        <p class="text-muted">Earn credits for each active referral and a percentage of their earnings.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function copyReferralLink() {
    var copyText = document.getElementById("referralLink");
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    document.execCommand("copy");
    
    // Show alert
    alert("Referral link copied to clipboard!");
}
</script>

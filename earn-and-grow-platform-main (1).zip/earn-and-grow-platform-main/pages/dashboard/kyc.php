
<?php
// Get user data
$userId = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Check if user has a KYC application
$sql = "SELECT * FROM kyc_applications WHERE user_id = ? ORDER BY created_at DESC LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$kycApplication = $stmt->get_result()->fetch_assoc();

// Get KYC requirements from settings
$settings = getSiteSettings();
$kycRequirements = isset($settings['kyc_requirements']) ? json_decode($settings['kyc_requirements'], true) : [
    'id_card' => true,
    'passport' => true,
    'driver_license' => true,
    'selfie_with_id' => true
];

$kycInstructions = isset($settings['kyc_instructions']) ? $settings['kyc_instructions'] : 'Please submit clear photos or scans of your identification documents. Make sure all text is legible and photos are well-lit.';
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mb-0">KYC Verification</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="index.php?page=dashboard">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">KYC Verification</li>
            </ol>
        </nav>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <?php if (!$kycApplication): ?>
                <!-- No application submitted yet -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">KYC Verification</h5>
                        <p class="card-text">Complete the KYC verification process to gain full access to our platform features, including withdrawals.</p>
                        
                        <div class="alert alert-info">
                            <h6><i class="fas fa-info-circle me-2"></i> Instructions</h6>
                            <p class="mb-0"><?php echo $kycInstructions; ?></p>
                        </div>
                        
                        <form action="process_kyc.php" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
                            <div class="mb-3">
                                <label for="documentType" class="form-label">Document Type</label>
                                <select class="form-select" id="documentType" name="document_type" required>
                                    <option value="">Select document type</option>
                                    <?php if ($kycRequirements['id_card']): ?>
                                    <option value="id_card">ID Card</option>
                                    <?php endif; ?>
                                    
                                    <?php if ($kycRequirements['passport']): ?>
                                    <option value="passport">Passport</option>
                                    <?php endif; ?>
                                    
                                    <?php if ($kycRequirements['driver_license']): ?>
                                    <option value="driver_license">Driver's License</option>
                                    <?php endif; ?>
                                    
                                    <option value="other">Other Government-issued ID</option>
                                </select>
                                <div class="form-text">Choose the type of identification document you will submit</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="idNumber" class="form-label">ID Number</label>
                                <input type="text" class="form-control" id="idNumber" name="id_number" required>
                                <div class="form-text">Enter the document number as it appears on your ID</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="documentFront" class="form-label">Document Front Side</label>
                                <input type="file" class="form-control" id="documentFront" name="document_front" accept="image/*,.pdf" required>
                                <div class="form-text">Upload a clear photo or scan of the front side of your document</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="documentBack" class="form-label">Document Back Side</label>
                                <input type="file" class="form-control" id="documentBack" name="document_back" accept="image/*,.pdf">
                                <div class="form-text">Upload a clear photo or scan of the back side of your document (not required for passports)</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="selfieWithId" class="form-label">Selfie with ID</label>
                                <input type="file" class="form-control" id="selfieWithId" name="selfie_with_id" accept="image/*" required>
                                <div class="form-text">Upload a photo of yourself holding your ID document</div>
                            </div>
                            
                            <div class="mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="kycConfirm" required>
                                    <label class="form-check-label" for="kycConfirm">
                                        I confirm that all information provided is accurate and the documents are authentic. I understand that providing false information may result in account termination.
                                    </label>
                                </div>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Submit for Verification</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php elseif ($kycApplication['status'] === 'pending'): ?>
                <!-- Application pending -->
                <div class="card mb-4">
                    <div class="card-body text-center py-5">
                        <div class="mb-4">
                            <i class="fas fa-clock fa-5x text-warning"></i>
                        </div>
                        <h3>Verification in Progress</h3>
                        <p class="mb-4">Your KYC application is currently being reviewed by our team. This typically takes 1-2 business days.</p>
                        <div class="d-flex justify-content-center">
                            <div class="alert alert-warning">
                                <p class="mb-0">Submitted on: <?php echo date('F j, Y', strtotime($kycApplication['created_at'])); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php elseif ($kycApplication['status'] === 'approved'): ?>
                <!-- Application approved -->
                <div class="card mb-4">
                    <div class="card-body text-center py-5">
                        <div class="mb-4">
                            <i class="fas fa-check-circle fa-5x text-success"></i>
                        </div>
                        <h3>Verification Successful</h3>
                        <p class="mb-4">Your identity has been verified. You now have full access to all platform features, including withdrawals.</p>
                        <div class="d-flex justify-content-center">
                            <div class="alert alert-success">
                                <p class="mb-0">Verified on: <?php echo date('F j, Y', strtotime($kycApplication['updated_at'])); ?></p>
                            </div>
                        </div>
                        <a href="index.php?page=dashboard-withdraw" class="btn btn-primary">Go to Withdrawals</a>
                    </div>
                </div>
            <?php elseif ($kycApplication['status'] === 'rejected'): ?>
                <!-- Application rejected -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="text-center mb-4">
                            <i class="fas fa-times-circle fa-5x text-danger"></i>
                            <h3 class="mt-3">Verification Failed</h3>
                            <p>Your KYC verification was not approved. Please see the reason below and resubmit.</p>
                        </div>
                        
                        <div class="alert alert-danger mb-4">
                            <h6 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i> Reason for Rejection</h6>
                            <p class="mb-0"><?php echo $kycApplication['rejection_reason']; ?></p>
                        </div>
                        
                        <form action="process_kyc.php" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
                            <div class="mb-3">
                                <label for="documentType" class="form-label">Document Type</label>
                                <select class="form-select" id="documentType" name="document_type" required>
                                    <option value="">Select document type</option>
                                    <?php if ($kycRequirements['id_card']): ?>
                                    <option value="id_card" <?php echo $kycApplication['document_type'] === 'id_card' ? 'selected' : ''; ?>>ID Card</option>
                                    <?php endif; ?>
                                    
                                    <?php if ($kycRequirements['passport']): ?>
                                    <option value="passport" <?php echo $kycApplication['document_type'] === 'passport' ? 'selected' : ''; ?>>Passport</option>
                                    <?php endif; ?>
                                    
                                    <?php if ($kycRequirements['driver_license']): ?>
                                    <option value="driver_license" <?php echo $kycApplication['document_type'] === 'driver_license' ? 'selected' : ''; ?>>Driver's License</option>
                                    <?php endif; ?>
                                    
                                    <option value="other" <?php echo $kycApplication['document_type'] === 'other' ? 'selected' : ''; ?>>Other Government-issued ID</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label for="idNumber" class="form-label">ID Number</label>
                                <input type="text" class="form-control" id="idNumber" name="id_number" value="<?php echo $kycApplication['id_number']; ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="documentFront" class="form-label">Document Front Side</label>
                                <input type="file" class="form-control" id="documentFront" name="document_front" accept="image/*,.pdf" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="documentBack" class="form-label">Document Back Side</label>
                                <input type="file" class="form-control" id="documentBack" name="document_back" accept="image/*,.pdf">
                            </div>
                            
                            <div class="mb-3">
                                <label for="selfieWithId" class="form-label">Selfie with ID</label>
                                <input type="file" class="form-control" id="selfieWithId" name="selfie_with_id" accept="image/*" required>
                            </div>
                            
                            <div class="mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="kycConfirm" required>
                                    <label class="form-check-label" for="kycConfirm">
                                        I confirm that all information provided is accurate and the documents are authentic. I understand that providing false information may result in account termination.
                                    </label>
                                </div>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Resubmit for Verification</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Side Panel -->
        <div class="col-lg-4">
            <!-- KYC Status Card -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">KYC Status</h5>
                </div>
                <div class="card-body">
                    <?php if (!$kycApplication): ?>
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-light rounded-circle p-3 me-3">
                                <i class="fas fa-exclamation-circle text-warning"></i>
                            </div>
                            <div>
                                <h6 class="mb-0">Not Submitted</h6>
                                <p class="text-muted mb-0">KYC verification required</p>
                            </div>
                        </div>
                    <?php elseif ($kycApplication['status'] === 'pending'): ?>
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-light rounded-circle p-3 me-3">
                                <i class="fas fa-clock text-warning"></i>
                            </div>
                            <div>
                                <h6 class="mb-0">Pending Review</h6>
                                <p class="text-muted mb-0">Submitted on <?php echo date('M j, Y', strtotime($kycApplication['created_at'])); ?></p>
                            </div>
                        </div>
                    <?php elseif ($kycApplication['status'] === 'approved'): ?>
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-light rounded-circle p-3 me-3">
                                <i class="fas fa-check-circle text-success"></i>
                            </div>
                            <div>
                                <h6 class="mb-0">Verified</h6>
                                <p class="text-muted mb-0">Approved on <?php echo date('M j, Y', strtotime($kycApplication['updated_at'])); ?></p>
                            </div>
                        </div>
                    <?php elseif ($kycApplication['status'] === 'rejected'): ?>
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-light rounded-circle p-3 me-3">
                                <i class="fas fa-times-circle text-danger"></i>
                            </div>
                            <div>
                                <h6 class="mb-0">Verification Failed</h6>
                                <p class="text-muted mb-0">Rejected on <?php echo date('M j, Y', strtotime($kycApplication['updated_at'])); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="progress">
                        <?php
                        $progressPercentage = 0;
                        $progressClass = '';
                        
                        if (!$kycApplication) {
                            $progressPercentage = 0;
                            $progressClass = 'bg-warning';
                        } elseif ($kycApplication['status'] === 'pending') {
                            $progressPercentage = 50;
                            $progressClass = 'bg-warning';
                        } elseif ($kycApplication['status'] === 'approved') {
                            $progressPercentage = 100;
                            $progressClass = 'bg-success';
                        } elseif ($kycApplication['status'] === 'rejected') {
                            $progressPercentage = 30;
                            $progressClass = 'bg-danger';
                        }
                        ?>
                        <div class="progress-bar <?php echo $progressClass; ?>" role="progressbar" style="width: <?php echo $progressPercentage; ?>%" aria-valuenow="<?php echo $progressPercentage; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>
            </div>
            
            <!-- Why KYC Card -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Why KYC?</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex mb-3">
                        <div class="me-3">
                            <i class="fas fa-shield-alt fa-2x text-primary"></i>
                        </div>
                        <div>
                            <h6>Security</h6>
                            <p class="text-muted small mb-0">KYC helps us protect your account and prevent unauthorized access.</p>
                        </div>
                    </div>
                    <div class="d-flex mb-3">
                        <div class="me-3">
                            <i class="fas fa-balance-scale fa-2x text-primary"></i>
                        </div>
                        <div>
                            <h6>Compliance</h6>
                            <p class="text-muted small mb-0">We are required to verify the identity of our users as per regulatory requirements.</p>
                        </div>
                    </div>
                    <div class="d-flex">
                        <div class="me-3">
                            <i class="fas fa-lock fa-2x text-primary"></i>
                        </div>
                        <div>
                            <h6>Fraud Prevention</h6>
                            <p class="text-muted small mb-0">KYC helps us prevent fraud and protect our community of legitimate users.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Requirements Card -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Requirements</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex align-items-center">
                            <i class="fas fa-id-card text-primary me-3"></i>
                            <div>
                                <h6 class="mb-0">Valid Government ID</h6>
                                <p class="text-muted small mb-0">Passport, ID card, or driver's license</p>
                            </div>
                        </li>
                        <li class="list-group-item d-flex align-items-center">
                            <i class="fas fa-camera text-primary me-3"></i>
                            <div>
                                <h6 class="mb-0">Clear Photos</h6>
                                <p class="text-muted small mb-0">All text must be legible and clearly visible</p>
                            </div>
                        </li>
                        <li class="list-group-item d-flex align-items-center">
                            <i class="fas fa-user text-primary me-3"></i>
                            <div>
                                <h6 class="mb-0">Selfie with ID</h6>
                                <p class="text-muted small mb-0">A photo of yourself holding your ID</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Form validation
(function () {
    'use strict'
    
    // Fetch all forms to which we want to apply custom validation
    var forms = document.querySelectorAll('.needs-validation')
    
    // Loop over them and prevent submission
    Array.from(forms).forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            
            form.classList.add('was-validated')
        }, false)
    })
})()

// Show/hide document back based on document type
const documentType = document.getElementById('documentType');
const documentBack = document.getElementById('documentBack');
const documentBackFormText = documentBack ? documentBack.nextElementSibling : null;

if (documentType && documentBack) {
    documentType.addEventListener('change', function() {
        if (this.value === 'passport') {
            documentBack.removeAttribute('required');
            documentBack.parentElement.classList.add('text-muted');
            if (documentBackFormText) {
                documentBackFormText.textContent = 'Not required for passports';
            }
        } else {
            documentBack.setAttribute('required', '');
            documentBack.parentElement.classList.remove('text-muted');
            if (documentBackFormText) {
                documentBackFormText.textContent = 'Upload a clear photo or scan of the back side of your document';
            }
        }
    });
}
</script>

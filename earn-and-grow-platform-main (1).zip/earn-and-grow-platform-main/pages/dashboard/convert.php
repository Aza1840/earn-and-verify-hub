
<?php
// Get user data
$userId = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Get supported cryptocurrencies with exchange rates
// In a real application, these rates would be fetched from an API
$cryptocurrencies = [
    [
        'name' => 'Bitcoin',
        'code' => 'BTC',
        'type' => 'bitcoin',
        'icon' => 'fab fa-bitcoin',
        'rate' => 35000.00,  // Credits per 1 BTC
    ],
    [
        'name' => 'Ethereum',
        'code' => 'ETH',
        'type' => 'ethereum',
        'icon' => 'fab fa-ethereum',
        'rate' => 2500.00,   // Credits per 1 ETH
    ],
    [
        'name' => 'Tether',
        'code' => 'USDT',
        'type' => 'usdt',
        'icon' => 'fas fa-dollar-sign',
        'rate' => 1.00,      // Credits per 1 USDT
    ],
    [
        'name' => 'Solana',
        'code' => 'SOL',
        'type' => 'solana',
        'icon' => 'fas fa-sun',
        'rate' => 60.00,     // Credits per 1 SOL
    ],
    [
        'name' => 'Cardano',
        'code' => 'ADA',
        'type' => 'ada',
        'icon' => 'fas fa-globe',
        'rate' => 0.50,      // Credits per 1 ADA
    ],
];

// Get recent conversions
$sql = "SELECT * FROM transactions 
        WHERE user_id = ? AND type = 'conversion' 
        ORDER BY created_at DESC LIMIT 10";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$recentConversions = $stmt->get_result();
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mb-0">Convert</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="index.php?page=dashboard">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Convert</li>
            </ol>
        </nav>
    </div>

    <div class="row">
        <!-- Conversion Calculator -->
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Currency Converter</h5>
                </div>
                <div class="card-body">
                    <form action="process_conversion.php" method="post" id="conversionForm" class="needs-validation" novalidate>
                        <div class="row mb-4">
                            <!-- From Currency -->
                            <div class="col-md-5">
                                <label class="form-label">From</label>
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control" id="fromAmount" name="fromAmount" min="0.00000001" step="0.00000001" required>
                                    <select class="form-select" id="fromCurrency" name="fromCurrency" style="max-width: 150px;" required>
                                        <option value="credits" selected>Credits</option>
                                        <?php foreach($cryptocurrencies as $crypto): ?>
                                        <option value="<?php echo $crypto['type']; ?>" data-rate="<?php echo $crypto['rate']; ?>"><?php echo $crypto['code']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <small class="text-muted">Available: <span id="availableBalance"><?php echo number_format($user['balance'], 2); ?></span> Credits</small>
                            </div>

                            <!-- Swap Button -->
                            <div class="col-md-2 d-flex align-items-center justify-content-center">
                                <button type="button" class="btn btn-outline-secondary" id="swapButton">
                                    <i class="fas fa-exchange-alt"></i>
                                </button>
                            </div>

                            <!-- To Currency -->
                            <div class="col-md-5">
                                <label class="form-label">To</label>
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control" id="toAmount" readonly>
                                    <select class="form-select" id="toCurrency" name="toCurrency" style="max-width: 150px;" required>
                                        <?php foreach($cryptocurrencies as $crypto): ?>
                                        <option value="<?php echo $crypto['type']; ?>" data-rate="<?php echo $crypto['rate']; ?>"><?php echo $crypto['code']; ?></option>
                                        <?php endforeach; ?>
                                        <option value="credits">Credits</option>
                                    </select>
                                </div>
                                <small class="text-muted">Exchange rate: <span id="exchangeRate">1 Credit = 0.001 BTC</span></small>
                            </div>
                        </div>

                        <div class="card bg-light mb-4">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3 mb-md-0 border-end">
                                        <div class="text-center">
                                            <h6 class="mb-1">You're converting</h6>
                                            <h4 class="mb-0" id="summaryFrom">0 Credits</h4>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="text-center">
                                            <h6 class="mb-1">You'll receive</h6>
                                            <h4 class="mb-0" id="summaryTo">0 BTC</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="alert alert-info">
                            <div class="d-flex">
                                <div class="me-3">
                                    <i class="fas fa-info-circle fa-2x"></i>
                                </div>
                                <div>
                                    <h6>Exchange Rates</h6>
                                    <p class="mb-0">Rates are updated every 5 minutes from major exchanges. All conversions are instant and non-reversible.</p>
                                </div>
                            </div>
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg" id="convertButton" disabled>Convert Now</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Live Cryptocurrency Prices</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Currency</th>
                                    <th>Symbol</th>
                                    <th>Price</th>
                                    <th>24h Change</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($cryptocurrencies as $crypto): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <i class="<?php echo $crypto['icon']; ?> me-2"></i>
                                            <?php echo $crypto['name']; ?>
                                        </div>
                                    </td>
                                    <td><?php echo $crypto['code']; ?></td>
                                    <td><?php echo number_format($crypto['rate'], 2); ?> Credits</td>
                                    <td>
                                        <?php
                                        // Generate random 24h change for demo
                                        $change = mt_rand(-500, 500) / 100;
                                        $changeClass = $change >= 0 ? 'text-success' : 'text-danger';
                                        $changeIcon = $change >= 0 ? 'fa-caret-up' : 'fa-caret-down';
                                        ?>
                                        <span class="<?php echo $changeClass; ?>">
                                            <i class="fas <?php echo $changeIcon; ?> me-1"></i>
                                            <?php echo number_format(abs($change), 2); ?>%
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Side Panel -->
        <div class="col-lg-4">
            <!-- Balance Card -->
            <div class="card bg-primary text-white mb-4">
                <div class="card-body">
                    <h5 class="card-title text-white">Your Balance</h5>
                    <h2 class="display-5 mb-0"><?php echo number_format($user['balance'], 2); ?></h2>
                    <p class="mb-0">Credits</p>
                </div>
            </div>
            
            <!-- Recent Conversions -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Recent Conversions</h5>
                </div>
                <div class="list-group list-group-flush">
                    <?php
                    if ($recentConversions->num_rows > 0) {
                        while ($conversion = $recentConversions->fetch_assoc()) {
                            // Parse description to extract from/to currency details
                            $description = $conversion['description'] ?? '';
                            preg_match('/Converted ([\d\.]+) ([\w]+) to ([\d\.]+) ([\w]+)/', $description, $matches);
                            
                            $fromAmount = $matches[1] ?? $conversion['amount'];
                            $fromCurrency = $matches[2] ?? 'credits';
                            $toAmount = $matches[3] ?? '';
                            $toCurrency = $matches[4] ?? '';
                            
                            $statusClass = '';
                            $statusIcon = '';
                            
                            switch ($conversion['status']) {
                                case 'completed':
                                    $statusClass = 'text-success';
                                    $statusIcon = 'fas fa-check-circle';
                                    break;
                                case 'pending':
                                    $statusClass = 'text-warning';
                                    $statusIcon = 'fas fa-clock';
                                    break;
                                case 'failed':
                                    $statusClass = 'text-danger';
                                    $statusIcon = 'fas fa-times-circle';
                                    break;
                            }
                            ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="d-block">
                                            <?php echo number_format($fromAmount, strlen($fromCurrency) <= 3 ? 8 : 2); ?> <?php echo strtoupper($fromCurrency); ?>
                                            <i class="fas fa-arrow-right mx-1"></i>
                                            <?php if ($toAmount && $toCurrency): ?>
                                                <?php echo number_format($toAmount, strlen($toCurrency) <= 3 ? 8 : 2); ?> <?php echo strtoupper($toCurrency); ?>
                                            <?php endif; ?>
                                        </span>
                                        <small class="text-muted"><?php echo date('M j, Y H:i', strtotime($conversion['created_at'])); ?></small>
                                    </div>
                                    <span class="<?php echo $statusClass; ?>">
                                        <i class="<?php echo $statusIcon; ?>"></i>
                                    </span>
                                </div>
                            </div>
                            <?php
                        }
                    } else {
                        echo '<div class="list-group-item text-center py-4">No conversions yet</div>';
                    }
                    ?>
                </div>
            </div>
            
            <!-- Info Card -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Conversion Information</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h6><i class="fas fa-bolt me-2"></i> Instant Conversions</h6>
                        <p class="small text-muted mb-0">All currency conversions are processed instantly with no waiting time.</p>
                    </div>
                    <div class="mb-3">
                        <h6><i class="fas fa-percentage me-2"></i> Competitive Rates</h6>
                        <p class="small text-muted mb-0">We offer competitive exchange rates sourced from major cryptocurrency exchanges.</p>
                    </div>
                    <div>
                        <h6><i class="fas fa-info-circle me-2"></i> No Hidden Fees</h6>
                        <p class="small text-muted mb-0">
                            <?php if ($user['is_premium']): ?>
                                As a Premium member, you enjoy zero conversion fees!
                            <?php else: ?>
                                A small fee of 1% is applied to all conversions. Upgrade to Premium for fee-free conversions.
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const fromAmount = document.getElementById('fromAmount');
    const fromCurrency = document.getElementById('fromCurrency');
    const toAmount = document.getElementById('toAmount');
    const toCurrency = document.getElementById('toCurrency');
    const exchangeRate = document.getElementById('exchangeRate');
    const summaryFrom = document.getElementById('summaryFrom');
    const summaryTo = document.getElementById('summaryTo');
    const convertButton = document.getElementById('convertButton');
    const availableBalance = document.getElementById('availableBalance');
    const swapButton = document.getElementById('swapButton');
    const conversionForm = document.getElementById('conversionForm');
    
    const userBalance = <?php echo $user['balance']; ?>;
    
    // Function to update exchange rate display
    function updateExchangeRate() {
        const from = fromCurrency.value;
        const to = toCurrency.value;
        
        let fromRate = 1;
        let toRate = 1;
        
        if (from !== 'credits') {
            const fromOption = fromCurrency.options[fromCurrency.selectedIndex];
            fromRate = parseFloat(fromOption.dataset.rate);
        }
        
        if (to !== 'credits') {
            const toOption = toCurrency.options[toCurrency.selectedIndex];
            toRate = parseFloat(toOption.dataset.rate);
        }
        
        // Calculate and display the exchange rate
        if (from === 'credits' && to !== 'credits') {
            // Credits to crypto
            const rate = 1 / toRate;
            exchangeRate.textContent = `1 Credit = ${rate.toFixed(8)} ${to.toUpperCase()}`;
        } else if (from !== 'credits' && to === 'credits') {
            // Crypto to credits
            exchangeRate.textContent = `1 ${from.toUpperCase()} = ${fromRate.toFixed(2)} Credits`;
        } else if (from !== 'credits' && to !== 'credits') {
            // Crypto to crypto
            const rate = fromRate / toRate;
            exchangeRate.textContent = `1 ${from.toUpperCase()} = ${rate.toFixed(8)} ${to.toUpperCase()}`;
        }
    }
    
    // Function to calculate conversion
    function calculateConversion() {
        const from = fromCurrency.value;
        const to = toCurrency.value;
        const amount = parseFloat(fromAmount.value) || 0;
        
        let fromRate = 1;
        let toRate = 1;
        
        if (from !== 'credits') {
            const fromOption = fromCurrency.options[fromCurrency.selectedIndex];
            fromRate = parseFloat(fromOption.dataset.rate);
        }
        
        if (to !== 'credits') {
            const toOption = toCurrency.options[toCurrency.selectedIndex];
            toRate = parseFloat(toOption.dataset.rate);
        }
        
        // Calculate the converted amount
        let result;
        
        if (from === 'credits' && to !== 'credits') {
            // Credits to crypto
            result = amount / toRate;
        } else if (from !== 'credits' && to === 'credits') {
            // Crypto to credits
            result = amount * fromRate;
        } else if (from !== 'credits' && to !== 'credits') {
            // Crypto to crypto
            result = amount * (fromRate / toRate);
        } else {
            // Credits to credits
            result = amount;
        }
        
        // Update the to amount field
        toAmount.value = result.toFixed(8);
        
        // Update summary
        summaryFrom.textContent = `${amount.toFixed(from === 'credits' ? 2 : 8)} ${from.toUpperCase()}`;
        summaryTo.textContent = `${result.toFixed(to === 'credits' ? 2 : 8)} ${to.toUpperCase()}`;
        
        // Enable/disable convert button based on validation
        validateForm();
    }
    
    // Function to validate form
    function validateForm() {
        const amount = parseFloat(fromAmount.value) || 0;
        const from = fromCurrency.value;
        const to = toCurrency.value;
        
        // Check if currencies are the same
        if (from === to) {
            convertButton.disabled = true;
            return;
        }
        
        // Check if amount is positive
        if (amount <= 0) {
            convertButton.disabled = true;
            return;
        }
        
        // Check if user has sufficient balance when converting from credits
        if (from === 'credits' && amount > userBalance) {
            convertButton.disabled = true;
            return;
        }
        
        // All validations passed
        convertButton.disabled = false;
    }
    
    // Function to swap currencies
    function swapCurrencies() {
        const tempCurrency = fromCurrency.value;
        fromCurrency.value = toCurrency.value;
        toCurrency.value = tempCurrency;
        
        // Update available balance display
        if (fromCurrency.value === 'credits') {
            availableBalance.textContent = userBalance.toFixed(2);
        } else {
            availableBalance.textContent = '0.00000000'; // Placeholder for crypto balances
        }
        
        updateExchangeRate();
        calculateConversion();
    }
    
    // Event listeners
    fromAmount.addEventListener('input', calculateConversion);
    fromCurrency.addEventListener('change', function() {
        // Update available balance display
        if (this.value === 'credits') {
            availableBalance.textContent = userBalance.toFixed(2);
        } else {
            availableBalance.textContent = '0.00000000'; // Placeholder for crypto balances
        }
        
        updateExchangeRate();
        calculateConversion();
    });
    
    toCurrency.addEventListener('change', function() {
        updateExchangeRate();
        calculateConversion();
    });
    
    swapButton.addEventListener('click', swapCurrencies);
    
    conversionForm.addEventListener('submit', function(event) {
        if (convertButton.disabled) {
            event.preventDefault();
            return;
        }
        
        // Add the calculated to amount to the form
        const hiddenToAmount = document.createElement('input');
        hiddenToAmount.type = 'hidden';
        hiddenToAmount.name = 'toAmount';
        hiddenToAmount.value = toAmount.value;
        this.appendChild(hiddenToAmount);
    });
    
    // Initialize the form
    updateExchangeRate();
    calculateConversion();
});
</script>

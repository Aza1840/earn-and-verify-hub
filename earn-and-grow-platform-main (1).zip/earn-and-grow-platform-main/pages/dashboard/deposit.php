
<?php
// Get user data
$userId = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Get supported cryptocurrencies from settings
$settings = getSiteSettings();
$supportedCryptos = [
    [
        'name' => 'Bitcoin',
        'code' => 'BTC',
        'type' => 'bitcoin',
        'icon' => 'fab fa-bitcoin',
        'address' => $settings['bitcoin_address'] ?? '',
        'min_deposit' => $settings['min_deposit_btc'] ?? 0.001
    ],
    [
        'name' => 'Ethereum',
        'code' => 'ETH',
        'type' => 'ethereum',
        'icon' => 'fab fa-ethereum',
        'address' => $settings['ethereum_address'] ?? '',
        'min_deposit' => $settings['min_deposit_eth'] ?? 0.01
    ],
    [
        'name' => 'Tether',
        'code' => 'USDT',
        'type' => 'usdt',
        'icon' => 'fas fa-dollar-sign',
        'address' => $settings['usdt_address'] ?? '',
        'min_deposit' => $settings['min_deposit_usdt'] ?? 10
    ],
];

// Get recent deposits
$sql = "SELECT * FROM deposits WHERE user_id = ? ORDER BY created_at DESC LIMIT 10";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$recentDeposits = $stmt->get_result();
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mb-0">Deposit</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="index.php?page=dashboard">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Deposit</li>
            </ol>
        </nav>
    </div>

    <div class="row">
        <!-- Deposit Form -->
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title mb-4">Make a Deposit</h5>
                    
                    <ul class="nav nav-pills mb-4" id="depositTabs" role="tablist">
                        <?php foreach($supportedCryptos as $index => $crypto): ?>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link <?php echo $index === 0 ? 'active' : ''; ?>" 
                                    id="<?php echo $crypto['type']; ?>-tab" 
                                    data-bs-toggle="pill" 
                                    data-bs-target="#<?php echo $crypto['type']; ?>-pane" 
                                    type="button" 
                                    role="tab" 
                                    aria-controls="<?php echo $crypto['type']; ?>-pane" 
                                    aria-selected="<?php echo $index === 0 ? 'true' : 'false'; ?>">
                                <i class="<?php echo $crypto['icon']; ?> me-2"></i> <?php echo $crypto['name']; ?> (<?php echo $crypto['code']; ?>)
                            </button>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    
                    <div class="tab-content" id="depositTabsContent">
                        <?php foreach($supportedCryptos as $index => $crypto): ?>
                        <div class="tab-pane fade <?php echo $index === 0 ? 'show active' : ''; ?>" 
                             id="<?php echo $crypto['type']; ?>-pane" 
                             role="tabpanel" 
                             aria-labelledby="<?php echo $crypto['type']; ?>-tab" 
                             tabindex="0">
                            
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="alert alert-info">
                                        <p class="mb-2"><i class="fas fa-info-circle me-2"></i> How to deposit <?php echo $crypto['name']; ?>:</p>
                                        <ol class="mb-0">
                                            <li>Send <?php echo $crypto['code']; ?> to the address below</li>
                                            <li>Enter the transaction ID</li>
                                            <li>Submit the deposit form</li>
                                            <li>Funds will be credited after confirmation</li>
                                        </ol>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Deposit Address</label>
                                        <div class="input-group mb-3">
                                            <input type="text" class="form-control" value="<?php echo $crypto['address']; ?>" id="<?php echo $crypto['type']; ?>Address" readonly>
                                            <button class="btn btn-outline-secondary" type="button" onclick="copyToClipboard('<?php echo $crypto['address']; ?>', '<?php echo $crypto['type']; ?>Address')">Copy</button>
                                        </div>
                                        <div class="bg-light p-2 text-center mb-3">
                                            <?php
                                            // In a real scenario, you'd generate QR code for the address
                                            echo '<img src="assets/img/qr-placeholder.png" alt="QR Code" style="max-width: 150px;" class="img-fluid">';
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <form action="process_deposit.php" method="post" class="needs-validation" novalidate>
                                        <input type="hidden" name="crypto_type" value="<?php echo $crypto['type']; ?>">
                                        
                                        <div class="mb-3">
                                            <label for="<?php echo $crypto['type']; ?>Amount" class="form-label">Amount (<?php echo $crypto['code']; ?>)</label>
                                            <input type="number" class="form-control" id="<?php echo $crypto['type']; ?>Amount" name="amount" step="0.00000001" min="<?php echo $crypto['min_deposit']; ?>" required>
                                            <div class="form-text">Minimum deposit: <?php echo $crypto['min_deposit']; ?> <?php echo $crypto['code']; ?></div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label for="<?php echo $crypto['type']; ?>TxHash" class="form-label">Transaction Hash/ID</label>
                                            <input type="text" class="form-control" id="<?php echo $crypto['type']; ?>TxHash" name="transaction_hash" required>
                                            <div class="form-text">Enter the transaction ID from your wallet</div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="<?php echo $crypto['type']; ?>Confirm" required>
                                                <label class="form-check-label" for="<?php echo $crypto['type']; ?>Confirm">
                                                    I confirm that I have sent the funds to the correct address
                                                </label>
                                            </div>
                                        </div>
                                        
                                        <div class="d-grid">
                                            <button type="submit" class="btn btn-primary">Submit Deposit</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Recent Deposits and Info -->
        <div class="col-lg-4">
            <!-- Balance Card -->
            <div class="card bg-primary text-white mb-4">
                <div class="card-body">
                    <h5 class="card-title text-white">Your Balance</h5>
                    <h2 class="display-5 mb-0"><?php echo number_format($user['balance'], 2); ?></h2>
                    <p class="mb-0">Credits</p>
                </div>
            </div>
            
            <!-- Recent Deposits -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Recent Deposits</h5>
                </div>
                <div class="list-group list-group-flush">
                    <?php
                    if ($recentDeposits->num_rows > 0) {
                        while ($deposit = $recentDeposits->fetch_assoc()) {
                            $statusClass = '';
                            $statusIcon = '';
                            
                            switch ($deposit['status']) {
                                case 'approved':
                                    $statusClass = 'text-success';
                                    $statusIcon = 'fas fa-check-circle';
                                    break;
                                case 'pending':
                                    $statusClass = 'text-warning';
                                    $statusIcon = 'fas fa-clock';
                                    break;
                                case 'rejected':
                                    $statusClass = 'text-danger';
                                    $statusIcon = 'fas fa-times-circle';
                                    break;
                            }
                            ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="d-block"><?php echo number_format($deposit['amount'], 8); ?> <?php echo strtoupper($deposit['crypto_type']); ?></span>
                                        <small class="text-muted"><?php echo date('M j, Y H:i', strtotime($deposit['created_at'])); ?></small>
                                    </div>
                                    <span class="<?php echo $statusClass; ?>">
                                        <i class="<?php echo $statusIcon; ?> me-1"></i> <?php echo ucfirst($deposit['status']); ?>
                                    </span>
                                </div>
                            </div>
                            <?php
                        }
                    } else {
                        echo '<div class="list-group-item text-center py-4">No deposits yet</div>';
                    }
                    ?>
                </div>
            </div>
            
            <!-- Info Card -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Important Information</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h6><i class="fas fa-shield-alt me-2"></i> Security</h6>
                        <p class="small text-muted mb-0">Always verify the deposit address before sending funds. We never change our deposit addresses.</p>
                    </div>
                    <div class="mb-3">
                        <h6><i class="fas fa-clock me-2"></i> Processing Time</h6>
                        <p class="small text-muted mb-0">Deposits are typically credited after 3 network confirmations, which can take 10-60 minutes depending on network congestion.</p>
                    </div>
                    <div>
                        <h6><i class="fas fa-info-circle me-2"></i> Minimum Deposit</h6>
                        <p class="small text-muted mb-0">Please note the minimum deposit amounts for each cryptocurrency to ensure successful processing.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function copyToClipboard(text, elementId) {
    var copyText = document.getElementById(elementId);
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    document.execCommand("copy");
    
    // Show alert
    alert("Copied to clipboard: " + text);
}

// Form validation
(function () {
    'use strict'
    
    // Fetch all forms to which we want to apply custom validation
    var forms = document.querySelectorAll('.needs-validation')
    
    // Loop over them and prevent submission
    Array.from(forms).forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            
            form.classList.add('was-validated')
        }, false)
    })
})()
</script>

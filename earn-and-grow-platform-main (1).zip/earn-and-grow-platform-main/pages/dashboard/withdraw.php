
<?php
// Get user data
$userId = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Get settings
$settings = getSiteSettings();
$minWithdrawal = isset($settings['minimum_withdrawal']) ? $settings['minimum_withdrawal'] : 50;

// Get user wallets
$sql = "SELECT * FROM user_wallets WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$wallets = $stmt->get_result();

// Get user's KYC status
$sql = "SELECT * FROM kyc_applications WHERE user_id = ? ORDER BY created_at DESC LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$kycStatus = $stmt->get_result()->fetch_assoc();

// Get recent withdrawals
$sql = "SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC LIMIT 10";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$recentWithdrawals = $stmt->get_result();
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mb-0">Withdraw</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="index.php?page=dashboard">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Withdraw</li>
            </ol>
        </nav>
    </div>

    <div class="row">
        <!-- Withdraw Form -->
        <div class="col-lg-8">
            <?php if ($kycStatus && $kycStatus['status'] === 'approved'): ?>
                <?php if($user['balance'] >= $minWithdrawal): ?>
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Request Withdrawal</h5>
                        </div>
                        <div class="card-body">
                            <form action="process_withdrawal.php" method="post" class="needs-validation" novalidate>
                                <div class="mb-3">
                                    <label for="withdrawAmount" class="form-label">Amount (Credits)</label>
                                    <div class="input-group">
                                        <input type="number" class="form-control" id="withdrawAmount" name="amount" min="<?php echo $minWithdrawal; ?>" max="<?php echo $user['balance']; ?>" step="0.01" required>
                                        <span class="input-group-text">Credits</span>
                                    </div>
                                    <div class="form-text">
                                        Available balance: <?php echo number_format($user['balance'], 2); ?> Credits | 
                                        Minimum withdrawal: <?php echo $minWithdrawal; ?> Credits
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="withdrawCurrency" class="form-label">Withdrawal Method</label>
                                    <select class="form-select" id="withdrawCurrency" name="crypto_type" required>
                                        <option value="">Select withdrawal method</option>
                                        <?php
                                        if ($wallets->num_rows > 0) {
                                            while ($wallet = $wallets->fetch_assoc()) {
                                                echo '<option value="' . $wallet['crypto_type'] . '" data-address="' . $wallet['wallet_address'] . '">' . ucfirst($wallet['crypto_type']) . '</option>';
                                            }
                                        } else {
                                            echo '<option value="" disabled>No wallet addresses added</option>';
                                        }
                                        ?>
                                    </select>
                                    <div class="form-text">
                                        <a href="index.php?page=dashboard-wallet">Add a wallet address</a> if your preferred method is not listed.
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="walletAddress" class="form-label">Wallet Address</label>
                                    <input type="text" class="form-control" id="walletAddress" name="wallet_address" readonly required>
                                    <div class="form-text">This address will be used for your withdrawal.</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="withdrawNote" class="form-label">Note (Optional)</label>
                                    <textarea class="form-control" id="withdrawNote" name="note" rows="2"></textarea>
                                </div>
                                
                                <div class="mb-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="withdrawConfirm" required>
                                        <label class="form-check-label" for="withdrawConfirm">
                                            I confirm that all information is correct and I understand that incorrect wallet addresses may result in loss of funds.
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">Request Withdrawal</button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning">
                        <h5><i class="fas fa-exclamation-triangle me-2"></i> Insufficient Balance</h5>
                        <p class="mb-0">Your current balance (<?php echo number_format($user['balance'], 2); ?> Credits) is below the minimum withdrawal amount of <?php echo $minWithdrawal; ?> Credits. Complete more tasks to earn credits.</p>
                    </div>
                    <div class="d-grid gap-2 col-md-6 mx-auto">
                        <a href="index.php?page=dashboard-videos" class="btn btn-primary">View Video Tasks</a>
                        <a href="index.php?page=dashboard-news" class="btn btn-outline-primary">View News Tasks</a>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="alert alert-warning">
                    <h5><i class="fas fa-exclamation-triangle me-2"></i> KYC Verification Required</h5>
                    <p>To withdraw funds, you need to complete the KYC verification process. This helps us ensure security and prevent fraud.</p>
                    <?php if (!$kycStatus): ?>
                        <a href="index.php?page=dashboard-kyc" class="btn btn-primary mt-2">Complete KYC Verification</a>
                    <?php elseif ($kycStatus['status'] === 'pending'): ?>
                        <p class="mb-0 mt-2">Your KYC application is currently pending review. Please wait for approval.</p>
                    <?php elseif ($kycStatus['status'] === 'rejected'): ?>
                        <p class="mb-2">Your KYC verification was rejected for the following reason:</p>
                        <p class="alert alert-danger"><?php echo $kycStatus['rejection_reason']; ?></p>
                        <a href="index.php?page=dashboard-kyc" class="btn btn-primary">Resubmit KYC</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Withdrawal Process</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 mb-4 mb-md-0 text-center">
                            <div class="bg-light rounded-circle d-flex justify-content-center align-items-center mx-auto mb-3" style="width: 80px; height: 80px;">
                                <i class="fas fa-file-alt fa-2x text-primary"></i>
                            </div>
                            <h6>1. Submit Request</h6>
                            <p class="text-muted small">Fill the withdrawal form with your details</p>
                        </div>
                        <div class="col-md-3 mb-4 mb-md-0 text-center">
                            <div class="bg-light rounded-circle d-flex justify-content-center align-items-center mx-auto mb-3" style="width: 80px; height: 80px;">
                                <i class="fas fa-clock fa-2x text-primary"></i>
                            </div>
                            <h6>2. Processing</h6>
                            <p class="text-muted small">We review your withdrawal request</p>
                        </div>
                        <div class="col-md-3 mb-4 mb-md-0 text-center">
                            <div class="bg-light rounded-circle d-flex justify-content-center align-items-center mx-auto mb-3" style="width: 80px; height: 80px;">
                                <i class="fas fa-check-circle fa-2x text-primary"></i>
                            </div>
                            <h6>3. Approval</h6>
                            <p class="text-muted small">Request approved and payment initiated</p>
                        </div>
                        <div class="col-md-3 text-center">
                            <div class="bg-light rounded-circle d-flex justify-content-center align-items-center mx-auto mb-3" style="width: 80px; height: 80px;">
                                <i class="fas fa-wallet fa-2x text-primary"></i>
                            </div>
                            <h6>4. Received</h6>
                            <p class="text-muted small">Funds sent to your wallet</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Side Panel -->
        <div class="col-lg-4">
            <!-- Balance Card -->
            <div class="card bg-primary text-white mb-4">
                <div class="card-body">
                    <h5 class="card-title text-white">Available Balance</h5>
                    <h2 class="display-5 mb-0"><?php echo number_format($user['balance'], 2); ?></h2>
                    <p class="mb-0">Credits</p>
                </div>
            </div>
            
            <!-- Recent Withdrawals -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Recent Withdrawals</h5>
                </div>
                <div class="list-group list-group-flush">
                    <?php
                    if ($recentWithdrawals->num_rows > 0) {
                        while ($withdrawal = $recentWithdrawals->fetch_assoc()) {
                            $statusClass = '';
                            $statusIcon = '';
                            
                            switch ($withdrawal['status']) {
                                case 'approved':
                                    $statusClass = 'text-success';
                                    $statusIcon = 'fas fa-check-circle';
                                    break;
                                case 'pending':
                                    $statusClass = 'text-warning';
                                    $statusIcon = 'fas fa-clock';
                                    break;
                                case 'rejected':
                                    $statusClass = 'text-danger';
                                    $statusIcon = 'fas fa-times-circle';
                                    break;
                            }
                            ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="d-block"><?php echo number_format($withdrawal['amount'], 2); ?> Credits</span>
                                        <small class="text-muted"><?php echo date('M j, Y H:i', strtotime($withdrawal['created_at'])); ?></small>
                                    </div>
                                    <span class="<?php echo $statusClass; ?>">
                                        <i class="<?php echo $statusIcon; ?> me-1"></i> <?php echo ucfirst($withdrawal['status']); ?>
                                    </span>
                                </div>
                                <div class="small text-muted mt-1">
                                    To: <?php echo strtoupper($withdrawal['crypto_type']); ?>
                                </div>
                            </div>
                            <?php
                        }
                    } else {
                        echo '<div class="list-group-item text-center py-4">No withdrawals yet</div>';
                    }
                    ?>
                </div>
            </div>
            
            <!-- Info Card -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Important Information</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h6><i class="fas fa-clock me-2"></i> Processing Time</h6>
                        <p class="small text-muted mb-0">Withdrawals are typically processed within 24 hours during business days.</p>
                    </div>
                    <div class="mb-3">
                        <h6><i class="fas fa-shield-alt me-2"></i> Security</h6>
                        <p class="small text-muted mb-0">Withdrawal requests are subject to security checks. Additional verification may be required for large amounts.</p>
                    </div>
                    <div>
                        <h6><i class="fas fa-info-circle me-2"></i> Fees</h6>
                        <p class="small text-muted mb-0">
                            <?php if ($user['is_premium']): ?>
                                As a Premium member, you enjoy zero withdrawal fees!
                            <?php else: ?>
                                A small network fee may apply depending on the withdrawal method.
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Update wallet address when currency changes
document.getElementById('withdrawCurrency').addEventListener('change', function() {
    var selectedOption = this.options[this.selectedIndex];
    var walletAddress = selectedOption.getAttribute('data-address');
    document.getElementById('walletAddress').value = walletAddress || '';
});

// Form validation
(function () {
    'use strict'
    
    // Fetch all forms to which we want to apply custom validation
    var forms = document.querySelectorAll('.needs-validation')
    
    // Loop over them and prevent submission
    Array.from(forms).forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }
            
            form.classList.add('was-validated')
        }, false)
    })
})()
</script>

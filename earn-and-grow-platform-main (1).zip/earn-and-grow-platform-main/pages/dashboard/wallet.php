
<?php
// Get user data
$userId = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Get user wallets
$sql = "SELECT * FROM user_wallets WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$wallets = $stmt->get_result();

// Get recent transactions
$sql = "SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 10";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$transactions = $stmt->get_result();

// Get pending transactions
$sql = "SELECT * FROM transactions WHERE user_id = ? AND status = 'pending' ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$pendingTransactions = $stmt->get_result();

// Get pending withdrawals
$sql = "SELECT * FROM withdrawals WHERE user_id = ? AND status = 'pending' ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$pendingWithdrawals = $stmt->get_result();

// Get pending deposits
$sql = "SELECT * FROM deposits WHERE user_id = ? AND status = 'pending' ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$pendingDeposits = $stmt->get_result();
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mb-0">Wallet</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="index.php?page=dashboard">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Wallet</li>
            </ol>
        </nav>
    </div>

    <div class="row">
        <!-- Balance Cards -->
        <div class="col-lg-8">
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="card bg-primary text-white h-100">
                        <div class="card-body d-flex align-items-center">
                            <div>
                                <h6 class="text-white-50 mb-0">Available Balance</h6>
                                <h2 class="display-5 fw-bold mb-0"><?php echo number_format($user['balance'], 2); ?></h2>
                                <p class="mb-0">Credits</p>
                            </div>
                            <div class="ms-auto">
                                <i class="fas fa-coins fa-3x text-white-50"></i>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent border-0 p-3">
                            <div class="row g-2">
                                <div class="col-6">
                                    <a href="index.php?page=dashboard-withdraw" class="btn btn-light w-100">
                                        <i class="fas fa-arrow-up me-1"></i> Withdraw
                                    </a>
                                </div>
                                <div class="col-6">
                                    <a href="index.php?page=dashboard-convert" class="btn btn-light w-100">
                                        <i class="fas fa-exchange-alt me-1"></i> Convert
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card bg-success text-white h-100">
                        <div class="card-body d-flex align-items-center">
                            <div>
                                <h6 class="text-white-50 mb-0">Pending Balance</h6>
                                <h2 class="display-5 fw-bold mb-0">
                                    <?php 
                                    // Calculate pending credits from various sources
                                    $pendingCredits = 0;
                                    
                                    // Pending from transactions
                                    $sql = "SELECT SUM(amount) as total FROM transactions WHERE user_id = ? AND status = 'pending'";
                                    $stmt = $conn->prepare($sql);
                                    $stmt->bind_param("i", $userId);
                                    $stmt->execute();
                                    $pendingCredits += $stmt->get_result()->fetch_assoc()['total'] ?? 0;
                                    
                                    echo number_format($pendingCredits, 2); 
                                    ?>
                                </h2>
                                <p class="mb-0">Credits</p>
                            </div>
                            <div class="ms-auto">
                                <i class="fas fa-clock fa-3x text-white-50"></i>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent border-0 p-3">
                            <div class="row g-2">
                                <div class="col">
                                    <a href="index.php?page=dashboard-deposit" class="btn btn-light w-100">
                                        <i class="fas fa-arrow-down me-1"></i> Deposit
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Crypto Wallets -->
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Your Crypto Wallets</h5>
                    <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addWalletModal">
                        <i class="fas fa-plus me-1"></i> Add Wallet
                    </button>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Cryptocurrency</th>
                                    <th>Wallet Address</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($wallets->num_rows > 0) {
                                    while ($wallet = $wallets->fetch_assoc()) {
                                        $cryptoName = ucfirst($wallet['crypto_type']);
                                        $icon = "fab fa-bitcoin"; // Default icon
                                        
                                        // Set proper icon based on crypto type
                                        switch ($wallet['crypto_type']) {
                                            case 'ethereum':
                                                $icon = "fab fa-ethereum";
                                                break;
                                            case 'litecoin':
                                                $icon = "fab fa-litecoin-sign";
                                                break;
                                            case 'bitcoin-cash':
                                                $icon = "fas fa-coins";
                                                break;
                                            case 'dogecoin':
                                                $icon = "fas fa-coins";
                                                break;
                                        }
                                        ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="me-2">
                                                        <i class="<?php echo $icon; ?>"></i>
                                                    </div>
                                                    <div>
                                                        <p class="mb-0"><?php echo $cryptoName; ?></p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="text-truncate" style="max-width: 200px;">
                                                        <?php echo $wallet['wallet_address']; ?>
                                                    </div>
                                                    <button class="btn btn-sm text-primary ms-2" onclick="copyToClipboard('<?php echo $wallet['wallet_address']; ?>')">
                                                        <i class="fas fa-copy"></i>
                                                    </button>
                                                </div>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-primary me-1" data-bs-toggle="modal" data-bs-target="#editWalletModal" 
                                                        data-wallet-id="<?php echo $wallet['id']; ?>"
                                                        data-wallet-type="<?php echo $wallet['crypto_type']; ?>"
                                                        data-wallet-address="<?php echo $wallet['wallet_address']; ?>">
                                                    Edit
                                                </button>
                                                <button class="btn btn-sm btn-outline-danger" onclick="deleteWallet(<?php echo $wallet['id']; ?>)">
                                                    Delete
                                                </button>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                } else {
                                    echo '<tr><td colspan="3" class="text-center py-3">No wallet addresses added yet. Add a wallet address to withdraw funds.</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Recent Transactions -->
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Transactions</h5>
                    <a href="index.php?page=history" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th>Amount</th>
                                    <th>Description</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($transactions->num_rows > 0) {
                                    while ($transaction = $transactions->fetch_assoc()) {
                                        $icon = "";
                                        $badgeClass = "";
                                        
                                        switch ($transaction['type']) {
                                            case 'task':
                                            case 'reward':
                                                $icon = "fas fa-check-circle";
                                                break;
                                            case 'deposit':
                                                $icon = "fas fa-arrow-down";
                                                break;
                                            case 'withdrawal':
                                                $icon = "fas fa-arrow-up";
                                                break;
                                            case 'referral':
                                                $icon = "fas fa-user-plus";
                                                break;
                                            case 'premium':
                                                $icon = "fas fa-star";
                                                break;
                                            default:
                                                $icon = "fas fa-exchange-alt";
                                                break;
                                        }
                                        
                                        switch ($transaction['status']) {
                                            case 'completed':
                                                $badgeClass = "bg-success";
                                                break;
                                            case 'pending':
                                                $badgeClass = "bg-warning";
                                                break;
                                            case 'failed':
                                                $badgeClass = "bg-danger";
                                                break;
                                            default:
                                                $badgeClass = "bg-secondary";
                                                break;
                                        }
                                        ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="me-2">
                                                        <i class="<?php echo $icon; ?>"></i>
                                                    </div>
                                                    <div>
                                                        <?php echo ucfirst($transaction['type']); ?>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?php echo number_format($transaction['amount'], 2); ?> credits</td>
                                            <td><?php echo $transaction['description'] ?? '-'; ?></td>
                                            <td><?php echo date('M j, Y H:i', strtotime($transaction['created_at'])); ?></td>
                                            <td><span class="badge <?php echo $badgeClass; ?>"><?php echo ucfirst($transaction['status']); ?></span></td>
                                        </tr>
                                        <?php
                                    }
                                } else {
                                    echo '<tr><td colspan="5" class="text-center py-3">No transactions found.</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Side Panel -->
        <div class="col-lg-4">
            <!-- Pending Transactions -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Pending Transactions</h5>
                </div>
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush">
                        <?php
                        $hasPending = false;
                        
                        // Check pending withdrawals
                        if ($pendingWithdrawals->num_rows > 0) {
                            $hasPending = true;
                            while ($withdrawal = $pendingWithdrawals->fetch_assoc()) {
                                ?>
                                <li class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <p class="mb-0 text-primary"><i class="fas fa-arrow-up me-2"></i> Withdrawal</p>
                                            <p class="text-muted mb-0 small"><?php echo date('M j, Y H:i', strtotime($withdrawal['created_at'])); ?></p>
                                        </div>
                                        <div class="text-end">
                                            <p class="mb-0"><?php echo number_format($withdrawal['amount'], 2); ?> <?php echo strtoupper($withdrawal['crypto_type']); ?></p>
                                            <span class="badge bg-warning">Pending</span>
                                        </div>
                                    </div>
                                </li>
                                <?php
                            }
                        }
                        
                        // Check pending deposits
                        if ($pendingDeposits->num_rows > 0) {
                            $hasPending = true;
                            while ($deposit = $pendingDeposits->fetch_assoc()) {
                                ?>
                                <li class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <p class="mb-0 text-success"><i class="fas fa-arrow-down me-2"></i> Deposit</p>
                                            <p class="text-muted mb-0 small"><?php echo date('M j, Y H:i', strtotime($deposit['created_at'])); ?></p>
                                        </div>
                                        <div class="text-end">
                                            <p class="mb-0"><?php echo number_format($deposit['amount'], 2); ?> <?php echo strtoupper($deposit['crypto_type']); ?></p>
                                            <span class="badge bg-warning">Pending</span>
                                        </div>
                                    </div>
                                </li>
                                <?php
                            }
                        }
                        
                        // Check other pending transactions
                        if ($pendingTransactions->num_rows > 0) {
                            $hasPending = true;
                            while ($transaction = $pendingTransactions->fetch_assoc()) {
                                // Skip if it's already covered by withdrawals or deposits
                                if ($transaction['type'] == 'withdrawal' || $transaction['type'] == 'deposit') {
                                    continue;
                                }
                                ?>
                                <li class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <p class="mb-0 text-info"><i class="fas fa-exchange-alt me-2"></i> <?php echo ucfirst($transaction['type']); ?></p>
                                            <p class="text-muted mb-0 small"><?php echo date('M j, Y H:i', strtotime($transaction['created_at'])); ?></p>
                                        </div>
                                        <div class="text-end">
                                            <p class="mb-0"><?php echo number_format($transaction['amount'], 2); ?> credits</p>
                                            <span class="badge bg-warning">Pending</span>
                                        </div>
                                    </div>
                                </li>
                                <?php
                            }
                        }
                        
                        if (!$hasPending) {
                            echo '<li class="list-group-item text-center py-4">No pending transactions</li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="index.php?page=dashboard-deposit" class="btn btn-primary">
                            <i class="fas fa-arrow-down me-2"></i> Deposit Funds
                        </a>
                        <a href="index.php?page=dashboard-withdraw" class="btn btn-outline-primary">
                            <i class="fas fa-arrow-up me-2"></i> Withdraw Funds
                        </a>
                        <a href="index.php?page=dashboard-convert" class="btn btn-outline-success">
                            <i class="fas fa-exchange-alt me-2"></i> Convert Currency
                        </a>
                        <a href="index.php?page=history" class="btn btn-outline-secondary">
                            <i class="fas fa-history me-2"></i> Transaction History
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Upgrade to Premium -->
            <?php if (!$user['is_premium']): ?>
            <div class="card bg-gradient-primary text-white">
                <div class="card-body">
                    <h5 class="text-white mb-3">Upgrade to Premium</h5>
                    <p>Get 2x rewards on all tasks and exclusive benefits!</p>
                    <ul class="mb-4">
                        <li>Double rewards on all tasks</li>
                        <li>Priority support</li>
                        <li>Early access to new features</li>
                        <li>No withdrawal fees</li>
                    </ul>
                    <a href="index.php?page=upgrade" class="btn btn-light">Upgrade Now</a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Add Wallet Modal -->
<div class="modal fade" id="addWalletModal" tabindex="-1" aria-labelledby="addWalletModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addWalletModalLabel">Add Wallet Address</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="process_wallet.php" method="post">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    <div class="mb-3">
                        <label for="cryptoType" class="form-label">Cryptocurrency</label>
                        <select class="form-select" id="cryptoType" name="crypto_type" required>
                            <option value="">Select cryptocurrency</option>
                            <option value="bitcoin">Bitcoin (BTC)</option>
                            <option value="ethereum">Ethereum (ETH)</option>
                            <option value="usdt">Tether (USDT)</option>
                            <option value="litecoin">Litecoin (LTC)</option>
                            <option value="bitcoin-cash">Bitcoin Cash (BCH)</option>
                            <option value="dogecoin">Dogecoin (DOGE)</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="walletAddress" class="form-label">Wallet Address</label>
                        <input type="text" class="form-control" id="walletAddress" name="wallet_address" required>
                        <div class="form-text">Please double-check your wallet address before saving.</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Address</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Wallet Modal -->
<div class="modal fade" id="editWalletModal" tabindex="-1" aria-labelledby="editWalletModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editWalletModalLabel">Edit Wallet Address</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="process_wallet.php" method="post">
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="wallet_id" id="editWalletId">
                    <div class="mb-3">
                        <label for="editCryptoType" class="form-label">Cryptocurrency</label>
                        <select class="form-select" id="editCryptoType" name="crypto_type" required>
                            <option value="bitcoin">Bitcoin (BTC)</option>
                            <option value="ethereum">Ethereum (ETH)</option>
                            <option value="usdt">Tether (USDT)</option>
                            <option value="litecoin">Litecoin (LTC)</option>
                            <option value="bitcoin-cash">Bitcoin Cash (BCH)</option>
                            <option value="dogecoin">Dogecoin (DOGE)</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="editWalletAddress" class="form-label">Wallet Address</label>
                        <input type="text" class="form-control" id="editWalletAddress" name="wallet_address" required>
                        <div class="form-text">Please double-check your wallet address before saving.</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Address</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Copy wallet address to clipboard
function copyToClipboard(text) {
    var textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
    alert('Wallet address copied to clipboard!');
}

// Delete wallet confirmation
function deleteWallet(walletId) {
    if (confirm('Are you sure you want to delete this wallet address?')) {
        window.location.href = 'process_wallet.php?action=delete&wallet_id=' + walletId;
    }
}

// Edit wallet modal
document.getElementById('editWalletModal').addEventListener('show.bs.modal', function (event) {
    var button = event.relatedTarget;
    var walletId = button.getAttribute('data-wallet-id');
    var walletType = button.getAttribute('data-wallet-type');
    var walletAddress = button.getAttribute('data-wallet-address');
    
    document.getElementById('editWalletId').value = walletId;
    document.getElementById('editCryptoType').value = walletType;
    document.getElementById('editWalletAddress').value = walletAddress;
});
</script>

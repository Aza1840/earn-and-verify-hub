
<?php
// Get user data
$userId = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Get available video tasks
$sql = "SELECT * FROM tasks WHERE type = 'video' ORDER BY created_at DESC";
$videos = $conn->query($sql);
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mb-0">Videos</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="index.php?page=dashboard">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Videos</li>
            </ol>
        </nav>
    </div>
    
    <div class="row mb-4">
        <div class="col-md-8">
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>
                Watch videos to earn rewards. The longer the video, the more credits you earn!
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h4 class="mb-0">Total Earned</h4>
                            <?php
                            $sql = "SELECT SUM(amount) as total FROM transactions WHERE user_id = ? AND type = 'reward' AND status = 'completed'";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("i", $userId);
                            $stmt->execute();
                            $totalEarned = $stmt->get_result()->fetch_assoc()['total'] ?? 0;
                            ?>
                            <h2 class="mb-0"><?php echo $totalEarned; ?> credits</h2>
                        </div>
                        <div>
                            <i class="fas fa-coins fa-3x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <?php
        if ($videos->num_rows > 0) {
            while ($video = $videos->fetch_assoc()) {
                // Check if user already completed this task
                $sql = "SELECT id FROM completed_tasks WHERE user_id = ? AND task_id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ii", $userId, $video['id']);
                $stmt->execute();
                $completed = $stmt->get_result()->num_rows > 0;
                ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 video-card">
                        <div class="video-thumbnail position-relative">
                            <img src="<?php echo $video['thumbnail']; ?>" alt="<?php echo $video['title']; ?>" class="card-img-top">
                            <div class="video-duration badge bg-dark position-absolute bottom-0 end-0 m-2">
                                <?php echo $video['duration']; ?> mins
                            </div>
                            <?php if ($completed): ?>
                            <div class="completed-badge position-absolute top-0 end-0 m-2">
                                <span class="badge bg-success"><i class="fas fa-check-circle me-1"></i> Completed</span>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $video['title']; ?></h5>
                            <p class="card-text small text-muted"><?php echo substr($video['description'], 0, 100); ?>...</p>
                            
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <span class="badge bg-success p-2">
                                    <i class="fas fa-coins me-1"></i> 
                                    <?php 
                                    $reward = $video['reward'];
                                    if ($user['is_premium']) {
                                        $reward *= 2;
                                        echo "$reward credits (2x Premium)";
                                    } else {
                                        echo "$reward credits";
                                    }
                                    ?>
                                </span>
                                
                                <?php if ($completed): ?>
                                <button class="btn btn-secondary" disabled>
                                    <i class="fas fa-check me-1"></i> Completed
                                </button>
                                <?php else: ?>
                                <a href="index.php?page=task&id=<?php echo $video['id']; ?>" class="btn btn-primary">
                                    <i class="fas fa-play-circle me-1"></i> Watch Now
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            echo '<div class="col-12"><div class="alert alert-info">No videos available at the moment. Please check back later!</div></div>';
        }
        ?>
    </div>
</div>

<!-- Mobile Sidebar Menu -->
<div class="modal fade" id="sidebarModal" tabindex="-1" aria-labelledby="sidebarModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen-sm-down">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="sidebarModalLabel">Menu</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div class="list-group list-group-flush">
                    <a href="index.php?page=dashboard" class="list-group-item list-group-item-action">
                        <i class="fas fa-home me-2"></i> Dashboard
                    </a>
                    <a href="index.php?page=dashboard-videos" class="list-group-item list-group-item-action active">
                        <i class="fas fa-play-circle me-2"></i> Videos
                    </a>
                    <a href="index.php?page=dashboard-news" class="list-group-item list-group-item-action">
                        <i class="fas fa-newspaper me-2"></i> News
                    </a>
                    <a href="index.php?page=dashboard-referrals" class="list-group-item list-group-item-action">
                        <i class="fas fa-users me-2"></i> Referrals
                    </a>
                    <a href="index.php?page=dashboard-wallet" class="list-group-item list-group-item-action">
                        <i class="fas fa-wallet me-2"></i> Wallet
                    </a>
                    <a href="index.php?page=dashboard-deposit" class="list-group-item list-group-item-action">
                        <i class="fas fa-arrow-down me-2"></i> Deposit
                    </a>
                    <a href="index.php?page=dashboard-withdraw" class="list-group-item list-group-item-action">
                        <i class="fas fa-arrow-up me-2"></i> Withdraw
                    </a>
                    <a href="index.php?page=dashboard-convert" class="list-group-item list-group-item-action">
                        <i class="fas fa-exchange-alt me-2"></i> Convert
                    </a>
                    <a href="index.php?page=dashboard-kyc" class="list-group-item list-group-item-action">
                        <i class="fas fa-id-card me-2"></i> KYC
                    </a>
                    <a href="index.php?page=dashboard-leaderboard" class="list-group-item list-group-item-action">
                        <i class="fas fa-trophy me-2"></i> Leaderboard
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.video-card .video-thumbnail {
    position: relative;
    overflow: hidden;
}

.video-card .video-thumbnail img {
    transition: transform 0.3s ease;
    height: 180px;
    object-fit: cover;
}

.video-card:hover .video-thumbnail img {
    transform: scale(1.05);
}
</style>

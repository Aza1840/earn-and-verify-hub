
<?php
session_start();
require_once 'config/db.php';
require_once 'includes/functions.php';

$type = isset($_GET['type']) ? $_GET['type'] : '';

// Log the logout action
if (isset($_SESSION['user_id'])) {
    if ($type === 'admin' && $_SESSION['user_role'] === 'admin') {
        logAdminAction($_SESSION['user_id'], "Admin logout", "Admin logged out from IP: " . $_SERVER['REMOTE_ADDR']);
    } else {
        logUserActivity($_SESSION['user_id'], "User logout", "User logged out from IP: " . $_SERVER['REMOTE_ADDR']);
    }
}

// Clear all session variables
$_SESSION = array();

// Destroy the session
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
session_destroy();

// Redirect based on logout type
if ($type === 'admin') {
    header("Location: index.php?page=admin-login&logout=success");
} else {
    header("Location: index.php?page=login&logout=success");
}
exit;
?>

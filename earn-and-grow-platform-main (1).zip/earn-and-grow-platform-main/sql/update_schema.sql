
-- Add profile fields to users table
ALTER TABLE users
    ADD COLUMN profile_picture VARCHAR(255) NULL AFTER password,
    ADD COLUMN phone VARCHAR(50) NULL AFTER profile_picture,
    ADD COLUMN country VARCHAR(100) NULL AFTER phone,
    ADD COLUMN premium INT(1) DEFAULT 0 AFTER country,
    ADD COLUMN premium_expires DATETIME NULL AFTER premium,
    ADD COLUMN kyc_status ENUM('not_submitted', 'pending', 'approved', 'rejected') DEFAULT 'not_submitted' AFTER premium_expires,
    ADD COLUMN referral_code VARCHAR(20) NULL AFTER kyc_status,
    ADD COLUMN referred_by INT NULL AFTER referral_code;

-- Create admin logs table
CREATE TABLE IF NOT EXISTS admin_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NOT NULL,
    action VARCHAR(255) NOT NULL,
    details TEXT NULL,
    ip_address VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create user activity logs
CREATE TABLE IF NOT EXISTS user_activities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    activity VARCHAR(255) NOT NULL,
    details TEXT NULL,
    ip_address VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create email management tables
CREATE TABLE IF NOT EXISTS mass_emails (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subject VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    recipient_group VARCHAR(50) NOT NULL DEFAULT 'all',
    sent_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sent_by) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS email_recipients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email_id INT NOT NULL,
    user_id INT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (email_id) REFERENCES mass_emails(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create KYC table
CREATE TABLE IF NOT EXISTS kyc_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    id_type ENUM('passport', 'drivers_license', 'national_id') NOT NULL,
    id_front VARCHAR(255) NOT NULL,
    id_back VARCHAR(255) NULL,
    selfie VARCHAR(255) NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    notes TEXT NULL,
    reviewed_by INT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reviewed_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Create wallet tables
CREATE TABLE IF NOT EXISTS wallets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    currency VARCHAR(10) NOT NULL,
    balance DECIMAL(18,8) DEFAULT 0,
    address VARCHAR(100) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY (user_id, currency)
);

-- Create transactions table
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('deposit', 'withdrawal', 'reward', 'referral', 'conversion', 'transfer') NOT NULL,
    amount DECIMAL(18,8) NOT NULL,
    currency VARCHAR(10) NOT NULL,
    fee DECIMAL(18,8) DEFAULT 0,
    status ENUM('pending', 'completed', 'failed', 'cancelled') NOT NULL,
    tx_hash VARCHAR(255) NULL,
    reference VARCHAR(100) NULL,
    description TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create referrals table
CREATE TABLE IF NOT EXISTS referrals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    referrer_id INT NOT NULL,
    referred_id INT NOT NULL,
    status ENUM('pending', 'completed', 'rejected') DEFAULT 'pending',
    reward DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (referrer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (referred_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create tasks table
CREATE TABLE IF NOT EXISTS tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT NULL,
    type ENUM('video', 'news', 'survey', 'offer', 'other') NOT NULL,
    url VARCHAR(255) NULL,
    thumbnail VARCHAR(255) NULL,
    duration INT NULL COMMENT 'Duration in seconds',
    reward DECIMAL(10,2) NOT NULL,
    premium_reward DECIMAL(10,2) NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    added_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (added_by) REFERENCES users(id) ON DELETE CASCADE
);

-- Create task completions table
CREATE TABLE IF NOT EXISTS task_completions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    task_id INT NOT NULL,
    reward DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reviewed_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);

-- Create news articles table
CREATE TABLE IF NOT EXISTS news (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    image VARCHAR(255) NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    posted_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (posted_by) REFERENCES users(id)
);

-- Create cryptocurrency settings table
CREATE TABLE IF NOT EXISTS cryptocurrencies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    symbol VARCHAR(10) NOT NULL,
    name VARCHAR(50) NOT NULL,
    min_deposit DECIMAL(18,8) NOT NULL,
    min_withdrawal DECIMAL(18,8) NOT NULL,
    withdrawal_fee DECIMAL(18,8) DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    deposit_enabled BOOLEAN DEFAULT true,
    withdrawal_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Add settings table if not exists
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    value TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default settings if not exist
INSERT IGNORE INTO settings (name, value) VALUES
('site_name', 'Rewards Platform'),
('site_description', 'Earn rewards by completing tasks'),
('contact_email', 'contact@example.com'),
('site_logo', 'assets/img/logo.png'),
('task_reward_multiplier', '1.0'),
('premium_multiplier', '2.0'),
('min_withdrawal', '5'),
('referral_bonus', '20'),
('maintenance_mode', '0'),
('premium_cost', '50'),
('premium_duration_days', '30'),
('email_verification_required', '1'),
('kyc_required_for_withdrawal', '1'),
('max_profile_image_size', '2'), -- in MB
('allowed_profile_image_types', 'jpg,jpeg,png');

-- Insert default cryptocurrencies
INSERT IGNORE INTO cryptocurrencies (symbol, name, min_deposit, min_withdrawal, withdrawal_fee) VALUES
('BTC', 'Bitcoin', 0.0005, 0.001, 0.0001),
('ETH', 'Ethereum', 0.01, 0.01, 0.001),
('USDT', 'Tether', 10, 20, 1),
('BNB', 'Binance Coin', 0.05, 0.1, 0.005),
('DOGE', 'Dogecoin', 50, 100, 1);

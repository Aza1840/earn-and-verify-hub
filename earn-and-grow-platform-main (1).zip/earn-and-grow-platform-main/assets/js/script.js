
// Wait for the document to be ready
document.addEventListener('DOMContentLoaded', function() {
    // Enable tooltips everywhere
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Enable popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl)
    });
    
    // Mobile sidebar toggle for admin pages
    const adminSidebarToggle = document.getElementById('admin-sidebar-toggle');
    const adminSidebar = document.querySelector('.admin-sidebar');
    
    if (adminSidebarToggle && adminSidebar) {
        adminSidebarToggle.addEventListener('click', function() {
            adminSidebar.classList.toggle('show');
        });
    }
    
    // Copy referral link functionality
    const copyReferralBtn = document.getElementById('copyReferralBtn');
    if (copyReferralBtn) {
        copyReferralBtn.addEventListener('click', function() {
            const referralLink = document.getElementById('referralLink');
            if (referralLink) {
                navigator.clipboard.writeText(referralLink.value)
                    .then(() => {
                        // Create a bootstrap toast notification
                        const toastEl = document.createElement('div');
                        toastEl.className = 'toast position-fixed bottom-0 end-0 m-3';
                        toastEl.setAttribute('role', 'alert');
                        toastEl.setAttribute('aria-live', 'assertive');
                        toastEl.setAttribute('aria-atomic', 'true');
                        toastEl.innerHTML = `
                            <div class="toast-header">
                                <strong class="me-auto"><i class="fas fa-check-circle text-success me-2"></i>Success</strong>
                                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                            </div>
                            <div class="toast-body">
                                Referral link copied to clipboard!
                            </div>
                        `;
                        document.body.appendChild(toastEl);
                        const toast = new bootstrap.Toast(toastEl);
                        toast.show();
                        
                        // Remove toast from DOM after it's hidden
                        toastEl.addEventListener('hidden.bs.toast', function() {
                            document.body.removeChild(toastEl);
                        });
                    })
                    .catch(err => {
                        console.error('Failed to copy text: ', err);
                    });
            }
        });
    }
    
    // Form validation for withdrawal forms
    const withdrawalForm = document.getElementById('withdrawalForm');
    if (withdrawalForm) {
        withdrawalForm.addEventListener('submit', function(event) {
            const amount = parseFloat(document.getElementById('amount').value);
            const balance = parseFloat(document.getElementById('balance').dataset.balance);
            
            if (amount > balance) {
                event.preventDefault();
                
                // Show validation error
                const errorMsg = document.createElement('div');
                errorMsg.className = 'alert alert-danger mt-3';
                errorMsg.textContent = 'Withdrawal amount cannot exceed your available balance.';
                
                // Remove any existing error messages
                const existingError = document.querySelector('.alert-danger');
                if (existingError) {
                    existingError.remove();
                }
                
                withdrawalForm.prepend(errorMsg);
            }
        });
    }
    
    // Task completion timer
    const taskTimer = document.getElementById('taskTimer');
    if (taskTimer) {
        let seconds = parseInt(taskTimer.dataset.seconds || 30);
        const taskId = taskTimer.dataset.taskId;
        const completeBtn = document.getElementById('completeTaskBtn');
        
        const timerInterval = setInterval(function() {
            seconds--;
            taskTimer.textContent = seconds;
            
            if (seconds <= 0) {
                clearInterval(timerInterval);
                if (completeBtn) {
                    completeBtn.disabled = false;
                    completeBtn.innerHTML = '<i class="fas fa-check me-2"></i>Complete Task';
                }
            }
        }, 1000);
    }
});

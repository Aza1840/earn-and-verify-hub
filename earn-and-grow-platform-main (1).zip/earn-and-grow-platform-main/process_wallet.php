
<?php
session_start();
require_once 'config/db.php';
require_once 'includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['message'] = "Please login to continue.";
    $_SESSION['message_type'] = "danger";
    header("Location: index.php?page=login");
    exit;
}

$userId = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = clean_input($_POST['action']);
    
    if ($action === 'add' || $action === 'edit') {
        $cryptoType = clean_input($_POST['crypto_type']);
        $walletAddress = clean_input($_POST['wallet_address']);
        
        // Validate inputs
        if (empty($cryptoType) || empty($walletAddress)) {
            $_SESSION['message'] = "Please fill all required fields.";
            $_SESSION['message_type'] = "danger";
            header("Location: index.php?page=dashboard-wallet");
            exit;
        }
        
        // Basic wallet address validation
        $validWallet = false;
        switch ($cryptoType) {
            case 'bitcoin':
                // Basic Bitcoin address validation
                $validWallet = preg_match('/^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}$/', $walletAddress);
                break;
            case 'ethereum':
            case 'usdt':
                // Basic ETH/ERC20 address validation
                $validWallet = preg_match('/^0x[a-fA-F0-9]{40}$/', $walletAddress);
                break;
            case 'litecoin':
                // Basic Litecoin address validation
                $validWallet = preg_match('/^[LM3][a-km-zA-HJ-NP-Z1-9]{26,33}$/', $walletAddress);
                break;
            case 'bitcoin-cash':
                // Simplified Bitcoin Cash address validation
                $validWallet = preg_match('/^[qp][a-z0-9]{41}$|^[13][a-km-zA-HJ-NP-Z1-9]{33}$/', $walletAddress);
                break;
            case 'dogecoin':
                // Basic Dogecoin address validation
                $validWallet = preg_match('/^D{1}[5-9A-HJ-NP-U]{1}[1-9A-HJ-NP-Za-km-z]{32}$/', $walletAddress);
                break;
            default:
                // Default validation: at least 25 chars, no special chars except specific ones
                $validWallet = preg_match('/^[a-zA-Z0-9\-\_\+]{25,}$/', $walletAddress);
        }
        
        if (!$validWallet) {
            $_SESSION['message'] = "Invalid wallet address format for " . ucfirst($cryptoType) . ".";
            $_SESSION['message_type'] = "danger";
            header("Location: index.php?page=dashboard-wallet");
            exit;
        }
        
        if ($action === 'add') {
            // Check if user already has this crypto type
            $sql = "SELECT id FROM user_wallets WHERE user_id = ? AND crypto_type = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("is", $userId, $cryptoType);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                // Update existing wallet
                $sql = "UPDATE user_wallets SET wallet_address = ?, updated_at = NOW() WHERE user_id = ? AND crypto_type = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sis", $walletAddress, $userId, $cryptoType);
                
                if ($stmt->execute()) {
                    $_SESSION['message'] = ucfirst($cryptoType) . " wallet address updated successfully.";
                    $_SESSION['message_type'] = "success";
                    
                    // Log activity
                    logUserActivity($userId, "wallet_update", "Updated " . ucfirst($cryptoType) . " wallet address");
                } else {
                    $_SESSION['message'] = "Error updating wallet address.";
                    $_SESSION['message_type'] = "danger";
                }
            } else {
                // Add new wallet
                $sql = "INSERT INTO user_wallets (user_id, crypto_type, wallet_address, created_at) VALUES (?, ?, ?, NOW())";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("iss", $userId, $cryptoType, $walletAddress);
                
                if ($stmt->execute()) {
                    $_SESSION['message'] = ucfirst($cryptoType) . " wallet address added successfully.";
                    $_SESSION['message_type'] = "success";
                    
                    // Log activity
                    logUserActivity($userId, "wallet_add", "Added " . ucfirst($cryptoType) . " wallet address");
                } else {
                    $_SESSION['message'] = "Error adding wallet address.";
                    $_SESSION['message_type'] = "danger";
                }
            }
        } else if ($action === 'edit') {
            $walletId = intval($_POST['wallet_id']);
            
            // Verify that wallet belongs to user
            $sql = "SELECT id FROM user_wallets WHERE id = ? AND user_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ii", $walletId, $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                // Update wallet
                $sql = "UPDATE user_wallets SET crypto_type = ?, wallet_address = ?, updated_at = NOW() WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssi", $cryptoType, $walletAddress, $walletId);
                
                if ($stmt->execute()) {
                    $_SESSION['message'] = "Wallet address updated successfully.";
                    $_SESSION['message_type'] = "success";
                    
                    // Log activity
                    logUserActivity($userId, "wallet_update", "Updated " . ucfirst($cryptoType) . " wallet address");
                } else {
                    $_SESSION['message'] = "Error updating wallet address.";
                    $_SESSION['message_type'] = "danger";
                }
            } else {
                $_SESSION['message'] = "Invalid wallet ID.";
                $_SESSION['message_type'] = "danger";
            }
        }
    }
    
    header("Location: index.php?page=dashboard-wallet");
    exit;
} else if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['wallet_id'])) {
    $walletId = intval($_GET['wallet_id']);
    
    // Verify that wallet belongs to user
    $sql = "SELECT id, crypto_type FROM user_wallets WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $walletId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $wallet = $result->fetch_assoc();
        
        // Delete wallet
        $sql = "DELETE FROM user_wallets WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $walletId);
        
        if ($stmt->execute()) {
            $_SESSION['message'] = "Wallet address deleted successfully.";
            $_SESSION['message_type'] = "success";
            
            // Log activity
            logUserActivity($userId, "wallet_delete", "Deleted " . ucfirst($wallet['crypto_type']) . " wallet address");
        } else {
            $_SESSION['message'] = "Error deleting wallet address.";
            $_SESSION['message_type'] = "danger";
        }
    } else {
        $_SESSION['message'] = "Invalid wallet ID.";
        $_SESSION['message_type'] = "danger";
    }
    
    header("Location: index.php?page=dashboard-wallet");
    exit;
} else {
    // Invalid request
    header("Location: index.php?page=dashboard");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getSiteSettings()['site_name'] ?? 'Rewards Platform'; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
    
    <?php
    // Load either light or dark theme based on user preference or time of day
    $theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : 'light';
    if ($theme === 'dark') {
        echo '<link href="assets/css/dark.css" rel="stylesheet">';
    } else {
        echo '<link href="assets/css/light.css" rel="stylesheet">';
    }
    ?>
    
    <!-- DataTables CSS (if needed) -->
    <link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- DataTables JS (if needed) -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    
    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <header class="header">
        <?php
        // Check if user is in admin panel
        $isAdmin = isset($_GET['page']) && ($_GET['page'] === 'admin' || $_GET['page'] === 'admin-login');
        ?>
        
        <nav class="navbar navbar-expand-lg <?php echo (isset($_SESSION['user_id']) || $isAdmin) ? 'navbar-light bg-white shadow-sm' : 'navbar-dark bg-primary'; ?>">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <?php 
                    $siteLogo = getSiteSettings()['site_logo'] ?? 'assets/img/logo.png';
                    $siteName = getSiteSettings()['site_name'] ?? 'Rewards Platform';
                    ?>
                    <img src="<?php echo $siteLogo; ?>" alt="<?php echo $siteName; ?>" height="40" class="d-inline-block align-top me-2">
                    <span class="fs-4"><?php echo $siteName; ?></span>
                    <?php if ($isAdmin): ?>
                        <span class="badge bg-dark ms-2">Admin</span>
                    <?php endif; ?>
                </a>
                
                <?php if (isset($_SESSION['user_id'])): ?>
                    <!-- If on dashboard, show mobile menu button -->
                    <?php if ($_GET['page'] === 'dashboard' || strpos($_GET['page'], 'dashboard-') === 0): ?>
                        <button class="navbar-toggler d-md-none" type="button" data-bs-toggle="modal" data-bs-target="#sidebarModal">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                    <?php elseif ($isAdmin): ?>
                        <button class="navbar-toggler" type="button" data-bs-toggle="modal" data-bs-target="#adminSidebarModal">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                    <?php else: ?>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                    <?php endif; ?>
                <?php else: ?>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                <?php endif; ?>
                
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <?php if (!isset($_SESSION['user_id'])): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $page === 'home' ? 'active' : ''; ?>" href="index.php">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $page === 'about' ? 'active' : ''; ?>" href="index.php?page=about">About</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $page === 'contact' ? 'active' : ''; ?>" href="index.php?page=contact">Contact</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $page === 'leaderboard' ? 'active' : ''; ?>" href="index.php?page=leaderboard">Leaderboard</a>
                            </li>
                        <?php elseif (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin' && $isAdmin): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="index.php?page=admin">Admin Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="index.php?page=dashboard">User Dashboard</a>
                            </li>
                        <?php elseif (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin' && !$isAdmin): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="index.php?page=admin">Go to Admin Panel</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $page === 'dashboard' ? 'active' : ''; ?>" href="index.php?page=dashboard">Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $page === 'dashboard-videos' ? 'active' : ''; ?>" href="index.php?page=dashboard-videos">Videos</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $page === 'dashboard-wallet' ? 'active' : ''; ?>" href="index.php?page=dashboard-wallet">Wallet</a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $page === 'dashboard' ? 'active' : ''; ?>" href="index.php?page=dashboard">Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $page === 'dashboard-videos' ? 'active' : ''; ?>" href="index.php?page=dashboard-videos">Videos</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $page === 'dashboard-wallet' ? 'active' : ''; ?>" href="index.php?page=dashboard-wallet">Wallet</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $page === 'dashboard-referrals' ? 'active' : ''; ?>" href="index.php?page=dashboard-referrals">Referrals</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                    
                    <ul class="navbar-nav">
                        <?php if (isset($_SESSION['user_id'])): ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                    <img src="assets/img/avatar-placeholder.png" alt="User Avatar" class="rounded-circle me-1" width="30">
                                    <?php echo $_SESSION['username']; ?>
                                    <?php if ($_SESSION['user_role'] === 'admin'): ?>
                                        <span class="badge bg-danger ms-1">Admin</span>
                                    <?php endif; ?>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <li><a class="dropdown-item" href="index.php?page=profile"><i class="fas fa-user me-2"></i> Profile</a></li>
                                    <li><a class="dropdown-item" href="index.php?page=settings"><i class="fas fa-cog me-2"></i> Settings</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                                            <a class="dropdown-item text-danger" href="logout.php?type=admin"><i class="fas fa-sign-out-alt me-2"></i> Admin Logout</a>
                                        <?php else: ?>
                                            <a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a>
                                        <?php endif; ?>
                                    </li>
                                </ul>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $page === 'login' ? 'active' : ''; ?>" href="index.php?page=login">Login</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $page === 'register' ? 'active' : ''; ?>" href="index.php?page=register">Register</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    
    <main class="main-content">
        <?php if (isset($_SESSION['user_id']) && $_SESSION['user_role'] === 'admin' && $page === 'admin'): ?>
            <!-- No container for admin pages as they have their own layout -->
        <?php elseif (isset($_SESSION['user_id']) && (in_array($page, ['dashboard', 'dashboard-videos', 'dashboard-news', 'dashboard-wallet']))): ?>
            <!-- No container for these pages as they have their own layout -->
        <?php else: ?>
            <div class="container mt-4">
        <?php endif;

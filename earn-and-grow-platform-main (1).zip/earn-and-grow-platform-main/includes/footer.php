
        <?php if (!(isset($_SESSION['user_id']) && $_SESSION['user_role'] === 'admin' && $page === 'admin') && 
                 !(isset($_SESSION['user_id']) && in_array($page, ['dashboard', 'videos', 'news', 'wallet']))): ?>
            </div>
        <?php endif; ?>
    </main>
    
    <footer class="footer mt-auto py-3 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0">
                        &copy; <?php echo date("Y"); ?> <?php echo getSiteSettings()['site_name'] ?? 'Rewards Platform'; ?>. All rights reserved.
                    </p>
                </div>
                <div class="col-md-6 text-md-end">
                    <a class="text-dark me-3" href="index.php?page=terms">Terms of Service</a>
                    <a class="text-dark me-3" href="index.php?page=privacy">Privacy Policy</a>
                    <a class="text-dark" href="index.php?page=contact">Contact Us</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Custom JS -->
    <script src="assets/js/script.js"></script>

    <!-- Theme Switcher Script -->
    <script>
        function toggleTheme() {
            const currentTheme = document.cookie.replace(/(?:(?:^|.*;\s*)theme\s*\=\s*([^;]*).*$)|^.*$/, "$1") || 'light';
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            
            document.cookie = `theme=${newTheme}; path=/; max-age=31536000`; // 1 year expiry
            window.location.reload();
        }
    </script>
</body>
</html>

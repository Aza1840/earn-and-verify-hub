
<?php
// Function to sanitize input data
function clean_input($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    $data = $conn->real_escape_string($data);
    return $data;
}

// Function to check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Function to check if user is admin
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

// Function to get user balance
function getUserBalance($userId) {
    global $conn;
    $sql = "SELECT balance FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row['balance'];
    }
    return 0;
}

// Function to get user task count
function getUserTaskCount($userId) {
    global $conn;
    $sql = "SELECT COUNT(*) as count FROM completed_tasks WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row['count'];
    }
    return 0;
}

// Function to get pending deposits
function getPendingDeposits($userId) {
    global $conn;
    $sql = "SELECT COUNT(*) as count FROM deposits WHERE user_id = ? AND status = 'pending'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row['count'];
    }
    return 0;
}

// Function to get pending withdrawals
function getPendingWithdrawals($userId) {
    global $conn;
    $sql = "SELECT COUNT(*) as count FROM withdrawals WHERE user_id = ? AND status = 'pending'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        return $row['count'];
    }
    return 0;
}

// Function to get site settings
function getSiteSettings() {
    global $conn;
    $settings = array();
    $sql = "SELECT name, value FROM settings";
    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $settings[$row['name']] = $row['value'];
        }
    }
    return $settings;
}

// Function to log admin actions
function logAdminAction($adminId, $action, $details = '') {
    global $conn;
    $sql = "INSERT INTO admin_logs (admin_id, action, details, ip_address) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $ipAddress = $_SERVER['REMOTE_ADDR'];
    $stmt->bind_param("isss", $adminId, $action, $details, $ipAddress);
    $stmt->execute();
}

// Function to log user activity
function logUserActivity($userId, $activity, $details = '') {
    global $conn;
    $sql = "INSERT INTO user_activities (user_id, activity, details, ip_address) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $ipAddress = $_SERVER['REMOTE_ADDR'];
    $stmt->bind_param("isss", $userId, $activity, $details, $ipAddress);
    $stmt->execute();
}

// Function to generate random string
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

// Function to generate referral code
function generateReferralCode() {
    global $conn;
    $code = generateRandomString(8);
    
    // Check if code already exists
    $sql = "SELECT id FROM users WHERE referral_code = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $code);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // If code exists, generate another one
    if ($result->num_rows > 0) {
        return generateReferralCode();
    }
    
    return $code;
}

// Function to calculate task reward
function calculateTaskReward($baseReward, $userId) {
    global $conn;
    
    // Get user data
    $sql = "SELECT is_premium FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    // Get settings
    $settings = getSiteSettings();
    $taskMultiplier = isset($settings['task_reward_multiplier']) ? floatval($settings['task_reward_multiplier']) : 1.0;
    $premiumMultiplier = isset($settings['premium_multiplier']) ? floatval($settings['premium_multiplier']) : 2.0;
    
    // Calculate reward
    $reward = $baseReward * $taskMultiplier;
    
    // Apply premium multiplier if user is premium
    if ($user['is_premium']) {
        $reward *= $premiumMultiplier;
    }
    
    return $reward;
}

// Function to format number with suffix
function formatNumberWithSuffix($number) {
    if ($number < 1000) {
        return $number;
    }
    
    $suffixes = array('', 'k', 'm', 'b', 't');
    $suffixIndex = 0;
    
    while ($number >= 1000 && $suffixIndex < count($suffixes) - 1) {
        $number /= 1000;
        $suffixIndex++;
    }
    
    return number_format($number, 1) . $suffixes[$suffixIndex];
}

// Function to get total users
function getTotalUsers() {
    global $conn;
    $sql = "SELECT COUNT(*) as count FROM users WHERE role = 'user'";
    $result = $conn->query($sql);
    if ($row = $result->fetch_assoc()) {
        return $row['count'];
    }
    return 0;
}

// Function to get total revenue
function getTotalRevenue() {
    global $conn;
    $sql = "SELECT SUM(amount) as total FROM deposits WHERE status = 'completed'";
    $result = $conn->query($sql);
    if ($row = $result->fetch_assoc()) {
        return $row['total'] ?? 0;
    }
    return 0;
}

// Function to check if email exists
function emailExists($email) {
    global $conn;
    $sql = "SELECT id FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

// Function to check if username exists
function usernameExists($username) {
    global $conn;
    $sql = "SELECT id FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}
?>

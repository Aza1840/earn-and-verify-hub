
<?php
session_start();
require_once 'config/db.php';
require_once 'includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['message'] = "Please login to continue.";
    $_SESSION['message_type'] = "danger";
    header("Location: index.php?page=login");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['user_id'];
    $cryptoType = clean_input($_POST['crypto_type']);
    $amount = floatval($_POST['amount']);
    $transactionHash = clean_input($_POST['transaction_hash']);
    
    // Validate inputs
    if (empty($cryptoType) || $amount <= 0 || empty($transactionHash)) {
        $_SESSION['message'] = "Please fill all required fields with valid values.";
        $_SESSION['message_type'] = "danger";
        header("Location: index.php?page=dashboard-deposit");
        exit;
    }
    
    // Get settings for minimum deposit
    $settings = getSiteSettings();
    $minDepositKey = "min_deposit_" . $cryptoType;
    $minDeposit = isset($settings[$minDepositKey]) ? floatval($settings[$minDepositKey]) : 0.001;
    
    if ($amount < $minDeposit) {
        $_SESSION['message'] = "Minimum deposit amount is " . $minDeposit . " " . strtoupper($cryptoType) . ".";
        $_SESSION['message_type'] = "danger";
        header("Location: index.php?page=dashboard-deposit");
        exit;
    }
    
    // Check if transaction hash already exists
    $sql = "SELECT id FROM deposits WHERE transaction_hash = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $transactionHash);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $_SESSION['message'] = "This transaction has already been processed.";
        $_SESSION['message_type'] = "danger";
        header("Location: index.php?page=dashboard-deposit");
        exit;
    }
    
    // Insert deposit
    $sql = "INSERT INTO deposits (user_id, amount, crypto_type, transaction_hash, status, created_at) VALUES (?, ?, ?, ?, 'pending', NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("idss", $userId, $amount, $cryptoType, $transactionHash);
    
    if ($stmt->execute()) {
        $depositId = $conn->insert_id;
        
        // Record in transactions table
        $sql = "INSERT INTO transactions (user_id, amount, type, description, status, created_at) VALUES (?, ?, 'deposit', ?, 'pending', NOW())";
        $description = "Deposit of " . $amount . " " . strtoupper($cryptoType);
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ids", $userId, $amount, $description);
        $stmt->execute();
        
        // Log user activity
        $activityDetails = "Deposit request of " . $amount . " " . strtoupper($cryptoType) . " with transaction hash " . $transactionHash;
        logUserActivity($userId, "deposit_request", $activityDetails);
        
        $_SESSION['message'] = "Deposit request submitted successfully. It will be processed within 24 hours.";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error submitting deposit request. Please try again.";
        $_SESSION['message_type'] = "danger";
    }
    
    header("Location: index.php?page=dashboard-deposit");
    exit;
} else {
    header("Location: index.php?page=dashboard");
    exit;
}
?>

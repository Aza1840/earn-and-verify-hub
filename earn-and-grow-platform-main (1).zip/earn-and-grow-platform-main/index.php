
<?php
session_start();
require_once 'config/db.php';
require_once 'includes/functions.php';

// Set default page to home
$page = isset($_GET['page']) ? $_GET['page'] : 'home';
$section = isset($_GET['section']) ? $_GET['section'] : '';
$action = isset($_GET['action']) ? $_GET['action'] : '';

// Include header
include_once 'includes/header.php';

// Load the requested page
switch ($page) {
    // Public pages
    case 'home':
        include_once 'pages/home.php';
        break;
    case 'login':
        include_once 'pages/login.php';
        break;
    case 'admin-login':
        include_once 'pages/admin/login.php';
        break;
    case 'register':
        include_once 'pages/register.php';
        break;
    case 'forgot-password':
        include_once 'pages/forgot-password.php';
        break;
    case 'about':
        include_once 'pages/about.php';
        break;
    case 'contact':
        include_once 'pages/contact.php';
        break;
    case 'privacy':
        include_once 'pages/privacy.php';
        break;
    case 'terms':
        include_once 'pages/terms.php';
        break;
    case 'leaderboard':
        include_once 'pages/leaderboard.php';
        break;
    case 'profile':
        // Check if user is logged in
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['message'] = "Please login to view your profile.";
            header("Location: index.php?page=login");
            exit;
        }
        include_once 'pages/profile.php';
        break;
    
    // User dashboard pages
    case 'dashboard':
        // Check if user is logged in
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['message'] = "Please login to access your dashboard.";
            header("Location: index.php?page=login");
            exit;
        }
        include_once 'pages/dashboard.php';
        break;
    case 'dashboard-videos':
        // Check if user is logged in
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] === 'admin') {
            $_SESSION['message'] = "Please login to access videos.";
            header("Location: index.php?page=login");
            exit;
        }
        include_once 'pages/dashboard/videos.php';
        break;
    case 'dashboard-news':
        // Check if user is logged in
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] === 'admin') {
            $_SESSION['message'] = "Please login to access news.";
            header("Location: index.php?page=login");
            exit;
        }
        include_once 'pages/dashboard/news.php';
        break;
    case 'dashboard-referrals':
        // Check if user is logged in
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] === 'admin') {
            $_SESSION['message'] = "Please login to access your referrals.";
            header("Location: index.php?page=login");
            exit;
        }
        include_once 'pages/dashboard/referrals.php';
        break;
    case 'dashboard-wallet':
        // Check if user is logged in
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] === 'admin') {
            $_SESSION['message'] = "Please login to access your wallet.";
            header("Location: index.php?page=login");
            exit;
        }
        include_once 'pages/dashboard/wallet.php';
        break;
    case 'dashboard-deposit':
        // Check if user is logged in
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] === 'admin') {
            $_SESSION['message'] = "Please login to make a deposit.";
            header("Location: index.php?page=login");
            exit;
        }
        include_once 'pages/dashboard/deposit.php';
        break;
    case 'dashboard-withdraw':
        // Check if user is logged in
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] === 'admin') {
            $_SESSION['message'] = "Please login to make a withdrawal.";
            header("Location: index.php?page=login");
            exit;
        }
        include_once 'pages/dashboard/withdraw.php';
        break;
    case 'dashboard-convert':
        // Check if user is logged in
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] === 'admin') {
            $_SESSION['message'] = "Please login to convert currencies.";
            header("Location: index.php?page=login");
            exit;
        }
        include_once 'pages/dashboard/convert.php';
        break;
    case 'dashboard-kyc':
        // Check if user is logged in
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] === 'admin') {
            $_SESSION['message'] = "Please login to access KYC verification.";
            header("Location: index.php?page=login");
            exit;
        }
        include_once 'pages/dashboard/kyc.php';
        break;
    case 'dashboard-leaderboard':
        // Check if user is logged in
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] === 'admin') {
            $_SESSION['message'] = "Please login to view the leaderboard.";
            header("Location: index.php?page=login");
            exit;
        }
        include_once 'pages/dashboard/leaderboard.php';
        break;
    case 'settings':
        // Check if user is logged in
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['message'] = "Please login to change settings.";
            header("Location: index.php?page=login");
            exit;
        }
        include_once 'pages/settings.php';
        break;
    case 'task':
        // Check if user is logged in
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['message'] = "Please login to view tasks.";
            header("Location: index.php?page=login");
            exit;
        }
        include_once 'pages/task.php';
        break;
    case 'upgrade':
        // Check if user is logged in
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['message'] = "Please login to upgrade your account.";
            header("Location: index.php?page=login");
            exit;
        }
        include_once 'pages/upgrade.php';
        break;
    case 'history':
        // Check if user is logged in
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['message'] = "Please login to view your history.";
            header("Location: index.php?page=login");
            exit;
        }
        include_once 'pages/history.php';
        break;
    
    // Admin pages
    case 'admin':
        // Check if user is admin
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
            $_SESSION['message'] = "You don't have permission to access this page.";
            header("Location: index.php?page=admin-login");
            exit;
        }
        
        // If no section is specified, show the dashboard
        if (empty($section)) {
            include_once 'pages/admin/index.php';
        } else {
            // Handle admin sections
            switch ($section) {
                case 'videos':
                    include_once 'pages/admin/videos.php';
                    break;
                case 'users':
                    include_once 'pages/admin/users.php';
                    break;
                case 'email':
                    include_once 'pages/admin/email.php';
                    break;
                case 'email-config':
                    include_once 'pages/admin/email-config.php';
                    break;
                case 'kyc':
                    include_once 'pages/admin/kyc.php';
                    break;
                case 'deposits':
                    include_once 'pages/admin/deposits.php';
                    break;
                case 'withdrawals':
                    include_once 'pages/admin/withdrawals.php';
                    break;
                case 'accounts':
                    include_once 'pages/admin/accounts.php';
                    break;
                case 'tasks':
                    include_once 'pages/admin/tasks.php';
                    break;
                case 'administrators':
                    include_once 'pages/admin/administrators.php';
                    break;
                case 'settings':
                    include_once 'pages/admin/settings.php';
                    break;
                case 'profile':
                    include_once 'pages/admin/profile.php';
                    break;
                case 'news':
                    include_once 'pages/admin/news.php';
                    break;
                case 'logs':
                    include_once 'pages/admin/logs.php';
                    break;
                default:
                    include_once 'pages/404.php';
                    break;
            }
        }
        break;
    
    default:
        include_once 'pages/404.php';
        break;
}

// Include footer
include_once 'includes/footer.php';
?>

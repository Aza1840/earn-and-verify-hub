
# Rewards Platform PHP Application

A PHP-based rewards platform that allows users to earn rewards by completing tasks such as watching videos and reading news articles.

## Directory Structure

```
├── assets/
│   ├── css/
│   │   ├── style.css           # Main stylesheet
│   │   ├── dark.css            # Dark theme stylesheet
│   │   └── light.css           # Light theme stylesheet
│   ├── img/                    # Images directory
│   │   ├── favicon.ico
│   │   └── logo.png
│   └── js/                     # JavaScript files
│       └── script.js
├── config/
│   └── db.php                  # Database configuration
├── includes/
│   ├── functions.php           # Common functions
│   ├── header.php              # Page header
│   └── footer.php              # Page footer
├── pages/
│   ├── admin/                  # Admin pages
│   │   ├── index.php           # Admin dashboard
│   │   ├── sidebar.php         # Admin sidebar
│   │   ├── users.php           # User management
│   │   ├── videos.php          # Video content management
│   │   ├── news.php            # News content management
│   │   ├── kyc.php             # KYC applications
│   │   ├── deposits.php        # Deposit management
│   │   ├── withdrawals.php     # Withdrawal management
│   │   ├── accounts.php        # Account management
│   │   ├── tasks.php           # Task management
│   │   ├── administrators.php  # Admin management
│   │   ├── email.php           # Email services
│   │   ├── email-config.php    # Email configuration
│   │   └── settings.php        # Site settings
│   ├── home.php                # Home page
│   ├── login.php               # Login page
│   ├── register.php            # Registration page
│   ├── dashboard.php           # User dashboard
│   ├── profile.php             # User profile
│   ├── videos.php              # Videos listing
│   ├── news.php                # News listing
│   ├── wallet.php              # Crypto wallets
│   ├── withdraw.php            # Withdrawal page
│   ├── deposit.php             # Deposit page
│   ├── convert.php             # Currency conversion
│   ├── referrals.php           # Referral system
│   ├── upgrade.php             # Premium upgrade
│   ├── task.php                # Individual task page
│   └── 404.php                 # 404 error page
├── actions/                    # Action handlers
│   ├── complete_task.php
│   ├── save_wallet.php
│   ├── withdraw_request.php
│   ├── deposit_request.php
│   └── upload_kyc.php
├── uploads/                    # File uploads
│   ├── kyc/                    # KYC documents
│   ├── profile/                # Profile pictures
│   └── thumbnails/             # Task thumbnails
├── sql/
│   └── create_tables.sql       # Database schema
├── index.php                   # Main entry point
├── logout.php                  # Logout script
└── README.md                   # Project documentation
```

## Installation Instructions

1. Upload all files to your web hosting directory.
2. Create a MySQL database.
3. Import the SQL schema from `sql/create_tables.sql`.
4. Update database configuration in `config/db.php` with your database credentials.
5. Ensure the `uploads` directory and its subdirectories are writable.
6. Visit your website to start using the application.

## Default Admin Account

- Username: admin
- Password: password
- Email: admin@example.com

## Features

- User authentication (login/register)
- User dashboard showing earnings and tasks
- Task completion (videos and news)
- Cryptocurrency wallet management
- Deposit and withdrawal functionality
- Referral system
- Premium user accounts with 2x rewards
- KYC verification
- Admin panel with comprehensive management features
- Customizable site settings
- Email communication system

## Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher
- GD Library for image processing
- FileInfo extension for file uploads

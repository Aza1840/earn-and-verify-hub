
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useSiteSettings } from '@/contexts/SiteSettingsContext';
import { Button } from '@/components/ui/button';
import { 
  CheckCircle, 
  Play, 
  Newspaper, 
  Users, 
  Wallet, 
  ArrowRight 
} from 'lucide-react';

const Home = () => {
  const { user } = useAuth();
  const { settings } = useSiteSettings();
  
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-primary/5 via-transparent to-transparent py-20 md:py-32">
        <div className="container px-4 mx-auto">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-12 md:mb-0 md:pr-12">
              <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-6">
                Complete Tasks, <span className="text-primary">Earn Rewards</span>
              </h1>
              <p className="text-lg mb-8 text-muted-foreground">
                Watch videos, read news, complete simple tasks, and earn rewards that you can withdraw as cryptocurrency.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                {user ? (
                  <Button asChild size="lg">
                    <Link to="/dashboard">
                      Go to Dashboard <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                ) : (
                  <>
                    <Button asChild size="lg">
                      <Link to="/register">
                        Create Account <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                    <Button asChild variant="outline" size="lg">
                      <Link to="/login">Sign In</Link>
                    </Button>
                  </>
                )}
              </div>
            </div>
            <div className="md:w-1/2">
              <div className="relative">
                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl p-4 md:p-8 border">
                  <div className="flex justify-between mb-6">
                    <div>
                      <h3 className="font-bold text-xl">Your Earnings</h3>
                      <p className="text-muted-foreground text-sm">Complete tasks to earn more</p>
                    </div>
                    <div className="bg-primary/10 rounded-full h-12 w-12 flex items-center justify-center">
                      <Wallet className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="p-4 rounded-lg bg-muted/50 flex justify-between items-center">
                      <div>
                        <p className="font-medium">Watch Video Tasks</p>
                        <p className="text-xs text-muted-foreground">10-15 credits per task</p>
                      </div>
                      <Play className="h-5 w-5 text-primary" />
                    </div>
                    <div className="p-4 rounded-lg bg-muted/50 flex justify-between items-center">
                      <div>
                        <p className="font-medium">Read News Articles</p>
                        <p className="text-xs text-muted-foreground">5-8 credits per article</p>
                      </div>
                      <Newspaper className="h-5 w-5 text-primary" />
                    </div>
                    <div className="p-4 rounded-lg bg-muted/50 flex justify-between items-center">
                      <div>
                        <p className="font-medium">Refer Friends</p>
                        <p className="text-xs text-muted-foreground">20 credits per referral</p>
                      </div>
                      <Users className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                </div>
                <div className="absolute -right-3 -bottom-3 bg-premium text-white rounded-xl px-4 py-2 shadow-lg">
                  <div className="flex items-center gap-2">
                    <div className="bg-white/20 rounded-full p-1">
                      <CheckCircle className="h-4 w-4" />
                    </div>
                    <p className="font-bold text-sm">2x for Premium Users</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4 mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">How It Works</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Earn rewards by completing simple tasks on our platform and withdraw to your cryptocurrency wallet.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-card rounded-xl p-6 shadow-sm border">
              <div className="bg-primary/10 rounded-full h-12 w-12 flex items-center justify-center mb-4">
                <Play className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Watch Videos</h3>
              <p className="text-muted-foreground mb-4">
                Watch educational videos about cryptocurrency, finance, and other topics to earn rewards.
              </p>
              <Button variant="link" className="p-0" asChild>
                <Link to="/videos">
                  Browse Videos <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
            
            <div className="bg-card rounded-xl p-6 shadow-sm border">
              <div className="bg-primary/10 rounded-full h-12 w-12 flex items-center justify-center mb-4">
                <Newspaper className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Read News</h3>
              <p className="text-muted-foreground mb-4">
                Stay informed with the latest news articles while earning rewards for reading.
              </p>
              <Button variant="link" className="p-0" asChild>
                <Link to="/news">
                  Browse News <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
            
            <div className="bg-card rounded-xl p-6 shadow-sm border">
              <div className="bg-primary/10 rounded-full h-12 w-12 flex items-center justify-center mb-4">
                <Wallet className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Get Paid</h3>
              <p className="text-muted-foreground mb-4">
                Withdraw your earnings to your preferred cryptocurrency wallet once you reach the minimum threshold.
              </p>
              <Button variant="link" className="p-0" asChild>
                <Link to="/wallet">
                  Learn More <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Premium Section */}
      <section className="py-20">
        <div className="container px-4 mx-auto">
          <div className="bg-gradient-to-r from-premium/90 to-premium-dark text-white rounded-xl p-8 md:p-12">
            <div className="flex flex-col md:flex-row md:items-center">
              <div className="md:w-2/3 md:pr-12 mb-8 md:mb-0">
                <h2 className="text-3xl font-bold mb-4">
                  Upgrade to Premium
                </h2>
                <p className="mb-6 text-white/90">
                  Premium users earn 2x rewards on all completed tasks! Upgrade your account to maximize your earnings.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 mr-3" />
                    <span>2x multiplier on all task rewards</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 mr-3" />
                    <span>Priority withdrawal processing</span>
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-5 w-5 mr-3" />
                    <span>Access to exclusive premium tasks</span>
                  </li>
                </ul>
                <Button className="bg-white text-premium-dark hover:bg-white/90" size="lg" asChild>
                  <Link to="/upgrade">Upgrade Now</Link>
                </Button>
              </div>
              <div className="md:w-1/3 flex justify-center">
                <div className="bg-white/20 backdrop-blur-sm rounded-xl p-6 border-2 border-white/30 shadow-xl">
                  <div className="text-center">
                    <h3 className="text-2xl font-bold mb-2">2x</h3>
                    <p className="text-sm mb-4">Reward Multiplier</p>
                    <div className="text-4xl font-bold mb-2">
                      <span className="line-through text-white/60 mr-2 text-lg">1x</span>
                      2x
                    </div>
                    <p className="text-sm text-white/70">
                      All earnings are doubled for premium users
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4 mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">What Our Users Say</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Join thousands of satisfied users who are earning rewards daily
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-card rounded-xl p-6 shadow-sm border">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                  <span className="text-primary font-bold">JD</span>
                </div>
                <div>
                  <h4 className="font-bold">John Doe</h4>
                  <p className="text-sm text-muted-foreground">Premium User</p>
                </div>
              </div>
              <p className="text-muted-foreground">
                "I've earned enough to pay my monthly streaming subscriptions just by watching videos and reading news in my free time!"
              </p>
            </div>
            
            <div className="bg-card rounded-xl p-6 shadow-sm border">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                  <span className="text-primary font-bold">AS</span>
                </div>
                <div>
                  <h4 className="font-bold">Alice Smith</h4>
                  <p className="text-sm text-muted-foreground">Regular User</p>
                </div>
              </div>
              <p className="text-muted-foreground">
                "The platform is so easy to use. I complete tasks while on my lunch breaks and have already withdrawn to my crypto wallet twice!"
              </p>
            </div>
            
            <div className="bg-card rounded-xl p-6 shadow-sm border">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                  <span className="text-primary font-bold">RJ</span>
                </div>
                <div>
                  <h4 className="font-bold">Robert Johnson</h4>
                  <p className="text-sm text-muted-foreground">Premium User</p>
                </div>
              </div>
              <p className="text-muted-foreground">
                "The premium account is definitely worth it. I'm earning twice as much as before, and the exclusive tasks are actually interesting!"
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary/5">
        <div className="container px-4 mx-auto">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold mb-4">Ready to Start Earning?</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Join our platform today and start completing tasks to earn rewards that you can withdraw to your cryptocurrency wallet.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {user ? (
                <Button asChild size="lg">
                  <Link to="/dashboard">
                    Go to Dashboard <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              ) : (
                <>
                  <Button asChild size="lg">
                    <Link to="/register">
                      Create Account <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="lg">
                    <Link to="/login">Sign In</Link>
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;

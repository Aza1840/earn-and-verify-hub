
import { useAuth } from '@/contexts/AuthContext';
import { useTask } from '@/contexts/TaskContext';
import { Navigate } from 'react-router-dom';
import { Wallet, CheckCircle, Upload, Download, Play, Newspaper, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Link } from 'react-router-dom';
import StatCard from '@/components/dashboard/StatCard';
import TaskCard from '@/components/dashboard/TaskCard';
import PremiumBanner from '@/components/dashboard/PremiumBanner';

const Dashboard = () => {
  const { user, isLoading } = useAuth();
  const { tasks } = useTask();
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-pulse">Loading...</div>
      </div>
    );
  }
  
  if (!user) {
    return <Navigate to="/login" />;
  }
  
  // Sort tasks by creation date (newest first)
  const sortedTasks = [...tasks].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
  
  // Filter video and news tasks
  const videoTasks = sortedTasks.filter(task => task.type === 'video');
  const newsTasks = sortedTasks.filter(task => task.type === 'news');
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome back, {user.name}
            {user.isPremium && <span className="ml-2 text-premium">(Premium)</span>}
          </p>
        </div>
        
        <div className="mt-4 md:mt-0 flex gap-3">
          <Button asChild variant="outline">
            <Link to="/wallet">
              <Wallet className="h-4 w-4 mr-2" />
              My Wallet
            </Link>
          </Button>
          
          <Button asChild>
            <Link to="/videos">
              <Play className="h-4 w-4 mr-2" />
              Watch Videos
            </Link>
          </Button>
        </div>
      </div>
      
      <PremiumBanner />
      
      {/* Stats row */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mt-6">
        <StatCard
          title="Account Balance"
          value={`${user.balance} credits`}
          icon={<Wallet className="h-4 w-4" />}
          description="Available for withdrawal"
        />
        
        <StatCard
          title="Tasks Completed"
          value={user.tasksCompleted}
          icon={<CheckCircle className="h-4 w-4" />}
          description="Videos and other activities"
        />
        
        <StatCard
          title="Pending Deposits"
          value={`${user.pendingDeposits} credits`}
          icon={<Upload className="h-4 w-4" />}
          description="Awaiting approval"
        />
        
        <StatCard
          title="Pending Withdrawals"
          value={`${user.pendingWithdrawals} credits`}
          icon={<Download className="h-4 w-4" />}
          description="Processing requests"
        />
      </div>
      
      {/* Tasks section */}
      <div className="mt-10">
        <Tabs defaultValue="all">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold">Available Tasks</h2>
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="videos">Videos</TabsTrigger>
              <TabsTrigger value="news">News</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="all" className="space-y-6">
            {sortedTasks.length === 0 ? (
              <Card>
                <CardContent className="py-10 text-center">
                  <Clock className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                  <h3 className="text-lg font-medium mb-1">No tasks available</h3>
                  <p className="text-muted-foreground">Check back later for new tasks</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {sortedTasks.map(task => (
                  <TaskCard key={task.id} task={task} />
                ))}
              </div>
            )}
            
            <div className="text-center mt-8">
              <Button asChild variant="outline">
                <Link to="/tasks">View All Tasks</Link>
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="videos">
            {videoTasks.length === 0 ? (
              <Card>
                <CardContent className="py-10 text-center">
                  <Play className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                  <h3 className="text-lg font-medium mb-1">No video tasks available</h3>
                  <p className="text-muted-foreground">Check back later for new video tasks</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {videoTasks.map(task => (
                  <TaskCard key={task.id} task={task} />
                ))}
              </div>
            )}
            
            <div className="text-center mt-8">
              <Button asChild variant="outline">
                <Link to="/videos">View All Videos</Link>
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="news">
            {newsTasks.length === 0 ? (
              <Card>
                <CardContent className="py-10 text-center">
                  <Newspaper className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                  <h3 className="text-lg font-medium mb-1">No news tasks available</h3>
                  <p className="text-muted-foreground">Check back later for new articles</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {newsTasks.map(task => (
                  <TaskCard key={task.id} task={task} />
                ))}
              </div>
            )}
            
            <div className="text-center mt-8">
              <Button asChild variant="outline">
                <Link to="/news">View All News</Link>
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Recent activity */}
      <div className="mt-10">
        <h2 className="text-2xl font-bold mb-4">Recent Activity</h2>
        <Card>
          <CardHeader>
            <CardTitle>Your latest actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center border-b pb-2">
                <div>
                  <p className="font-medium">Task completed</p>
                  <p className="text-sm text-muted-foreground">Advanced Online Earning Techniques</p>
                </div>
                <div className="text-right">
                  <p className="font-medium text-green-600">+15 credits</p>
                  <p className="text-xs text-muted-foreground">Today, 10:45 AM</p>
                </div>
              </div>
              
              <div className="flex justify-between items-center border-b pb-2">
                <div>
                  <p className="font-medium">Deposit requested</p>
                  <p className="text-sm text-muted-foreground">Bitcoin deposit</p>
                </div>
                <div className="text-right">
                  <p className="font-medium text-amber-600">Pending</p>
                  <p className="text-xs text-muted-foreground">Yesterday, 3:20 PM</p>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium">Referral signup</p>
                  <p className="text-sm text-muted-foreground">New user joined via your link</p>
                </div>
                <div className="text-right">
                  <p className="font-medium text-green-600">+20 credits</p>
                  <p className="text-xs text-muted-foreground">May 12, 2025</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;


import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogClose
} from '@/components/ui/dialog';
import { Trash2, UserPlus, UserCog, Shield } from 'lucide-react';

// This is a mockup for the frontend. In a real application, this would fetch from your PHP backend
const fetchAdministrators = async () => {
  // This would be replaced with an actual API call
  return [
    {
      id: 1,
      name: 'Admin User',
      email: 'admin@example.com',
      lastLogin: '2025-05-15 10:30:45',
      createdAt: '2025-01-01',
      profilePicture: null
    },
    {
      id: 2,
      name: 'System Admin',
      email: 'system@example.com',
      lastLogin: '2025-05-14 08:15:22',
      createdAt: '2025-01-02',
      profilePicture: null
    }
  ];
};

const AdminManagement = () => {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedAdmin, setSelectedAdmin] = useState<{id: number, name: string} | null>(null);
  const { toast } = useToast();

  const { data: administrators = [], isLoading, error } = useQuery({
    queryKey: ['administrators'],
    queryFn: fetchAdministrators
  });

  const handleAddAdmin = (event: React.FormEvent) => {
    event.preventDefault();
    toast({
      title: "Administrator Added",
      description: "The administrator has been successfully added."
    });
    setIsAddDialogOpen(false);
  };

  const handleDeleteAdmin = () => {
    if (selectedAdmin) {
      toast({
        title: "Administrator Deleted",
        description: `${selectedAdmin.name} has been removed from administrators.`
      });
      setIsDeleteDialogOpen(false);
      setSelectedAdmin(null);
    }
  };

  if (isLoading) return <div className="p-8 text-center">Loading administrators...</div>;
  if (error) return <div className="p-8 text-center text-red-500">Error loading administrators</div>;

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Administrators</h1>
          <p className="text-muted-foreground">
            Manage administrator accounts and permissions
          </p>
        </div>
        <Button onClick={() => setIsAddDialogOpen(true)}>
          <UserPlus className="w-4 h-4 mr-2" />
          Add Administrator
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="py-3 px-4 text-left">Name</th>
                  <th className="py-3 px-4 text-left">Email</th>
                  <th className="py-3 px-4 text-left">Last Login</th>
                  <th className="py-3 px-4 text-left">Created On</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody>
                {administrators.map((admin) => (
                  <tr key={admin.id} className="border-b hover:bg-muted/50">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        {admin.profilePicture ? (
                          <img 
                            src={admin.profilePicture} 
                            alt={admin.name} 
                            className="w-8 h-8 rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center">
                            {admin.name.charAt(0).toUpperCase()}
                          </div>
                        )}
                        <span>{admin.name}</span>
                        {admin.id === 1 && <span className="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">You</span>}
                      </div>
                    </td>
                    <td className="py-3 px-4">{admin.email}</td>
                    <td className="py-3 px-4">{admin.lastLogin}</td>
                    <td className="py-3 px-4">{admin.createdAt}</td>
                    <td className="py-3 px-4">
                      <div className="flex justify-center gap-2">
                        {admin.id !== 1 ? (
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => {
                              setSelectedAdmin({ id: admin.id, name: admin.name });
                              setIsDeleteDialogOpen(true);
                            }}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        ) : (
                          <Button variant="outline" size="sm">
                            <UserCog className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Add Administrator Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Administrator</DialogTitle>
            <DialogDescription>
              Create a new administrator account with full privileges.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAddAdmin}>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="name">Full Name</label>
                <Input id="name" placeholder="John Doe" required />
              </div>
              <div className="grid gap-2">
                <label htmlFor="email">Email Address</label>
                <Input id="email" type="email" placeholder="admin@example.com" required />
              </div>
              <div className="grid gap-2">
                <label htmlFor="password">Password</label>
                <Input id="password" type="password" required />
              </div>
              <div className="grid gap-2">
                <label htmlFor="confirmPassword">Confirm Password</label>
                <Input id="confirmPassword" type="password" required />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit">
                <Shield className="w-4 h-4 mr-2" />
                Add Administrator
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Administrator Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Administrator</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete administrator {selectedAdmin?.name}?
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteAdmin}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminManagement;


import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  User,
  PlaySquare,
  Wallet,
  Activity,
  BarChart3,
  UserCheck,
  Users,
  Mail,
  FileCheck,
  Download,
  Upload,
  Database,
} from 'lucide-react';

const AdminDashboard = () => {
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-pulse">Loading...</div>
      </div>
    );
  }
  
  if (!user || user.role !== 'admin') {
    return <Navigate to="/login" />;
  }
  
  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <p className="text-muted-foreground">
          Welcome back, {user.name}
        </p>
      </div>
      
      {/* Stats overview */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatCard 
          title="Total Users"
          value="583"
          description="+5 today"
          icon={<User className="h-5 w-5" />}
          trend="up"
        />
        
        <StatCard 
          title="Active Tasks"
          value="124"
          description="56 videos, 68 news"
          icon={<PlaySquare className="h-5 w-5" />}
          trend="up"
        />
        
        <StatCard 
          title="Total Earnings"
          value="$12,543"
          description="Platform revenue"
          icon={<Wallet className="h-5 w-5" />}
          trend="up"
        />
        
        <StatCard 
          title="Premium Users"
          value="217"
          description="37% of users"
          icon={<UserCheck className="h-5 w-5" />}
          trend="up"
        />
      </div>
      
      {/* Recent activity */}
      <div className="mt-8 grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="h-5 w-5 mr-2" />
              Recent Activity
            </CardTitle>
            <CardDescription>Latest platform events</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              <li className="flex items-start justify-between border-b pb-4">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5 rounded-full bg-blue-100 p-1.5 dark:bg-blue-900">
                    <User className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">New user registration</p>
                    <p className="text-xs text-muted-foreground">John Smith joined the platform</p>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">5m ago</span>
              </li>
              
              <li className="flex items-start justify-between border-b pb-4">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5 rounded-full bg-green-100 p-1.5 dark:bg-green-900">
                    <Upload className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">New deposit</p>
                    <p className="text-xs text-muted-foreground">$250 Bitcoin deposit from user Emma W.</p>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">15m ago</span>
              </li>
              
              <li className="flex items-start justify-between border-b pb-4">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5 rounded-full bg-amber-100 p-1.5 dark:bg-amber-900">
                    <FileCheck className="h-4 w-4 text-amber-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">New KYC application</p>
                    <p className="text-xs text-muted-foreground">New verification submitted by Robert J.</p>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">35m ago</span>
              </li>
              
              <li className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5 rounded-full bg-purple-100 p-1.5 dark:bg-purple-900">
                    <PlaySquare className="h-4 w-4 text-purple-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">New task created</p>
                    <p className="text-xs text-muted-foreground">Admin added "Crypto 101" video task</p>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">1h ago</span>
              </li>
            </ul>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="h-5 w-5 mr-2" />
              Dashboard Overview
            </CardTitle>
            <CardDescription>Quick access to key sections</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <QuickAccessCard 
                title="Users" 
                count="583" 
                icon={<Users className="h-5 w-5" />} 
                path="/admin/users" 
              />
              
              <QuickAccessCard 
                title="Videos" 
                count="56" 
                icon={<PlaySquare className="h-5 w-5" />} 
                path="/admin/videos" 
              />
              
              <QuickAccessCard 
                title="KYC Requests" 
                count="12" 
                icon={<FileCheck className="h-5 w-5" />} 
                path="/admin/kyc" 
              />
              
              <QuickAccessCard 
                title="Withdrawals" 
                count="25" 
                icon={<Download className="h-5 w-5" />} 
                path="/admin/withdrawals" 
              />
              
              <QuickAccessCard 
                title="Deposits" 
                count="18" 
                icon={<Upload className="h-5 w-5" />} 
                path="/admin/deposits" 
              />
              
              <QuickAccessCard 
                title="Email" 
                count="3" 
                icon={<Mail className="h-5 w-5" />} 
                path="/admin/email" 
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

interface StatCardProps {
  title: string;
  value: string;
  description: string;
  icon: React.ReactNode;
  trend: 'up' | 'down' | 'neutral';
}

const StatCard = ({ title, value, description, icon, trend }: StatCardProps) => {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <div className="rounded-md bg-primary/10 p-1 text-primary">
          {icon}
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">
          {description}
        </p>
      </CardContent>
    </Card>
  );
};

interface QuickAccessCardProps {
  title: string;
  count: string;
  icon: React.ReactNode;
  path: string;
}

const QuickAccessCard = ({ title, count, icon, path }: QuickAccessCardProps) => {
  return (
    <a 
      href={path}
      className="flex items-center gap-3 rounded-lg border p-4 hover:bg-accent transition-colors"
    >
      <div className="rounded-md bg-primary/10 p-2 text-primary">
        {icon}
      </div>
      <div>
        <h3 className="font-medium">{title}</h3>
        <p className="text-sm text-muted-foreground">{count}</p>
      </div>
    </a>
  );
};

export default AdminDashboard;

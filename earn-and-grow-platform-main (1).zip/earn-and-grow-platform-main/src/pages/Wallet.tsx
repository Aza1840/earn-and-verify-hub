
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useWallet } from '@/contexts/WalletContext';
import { Navigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { 
  Wallet as WalletIcon, 
  CheckCircle, 
  Download, 
  Upload, 
  History,
  ArrowRightLeft,
  ChevronDown,
  Bitcoin,
  CreditCard,
  Clock
} from 'lucide-react';
import StatCard from '@/components/dashboard/StatCard';

const WalletPage = () => {
  const { user, isLoading } = useAuth();
  const { walletAddresses, transactions } = useWallet();
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-pulse">Loading...</div>
      </div>
    );
  }
  
  if (!user) {
    return <Navigate to="/login" />;
  }
  
  // Sort transactions by date (most recent first)
  const sortedTransactions = [...transactions].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold">My Wallet</h1>
          <p className="text-muted-foreground">
            Manage your funds and transactions
          </p>
        </div>
        
        <div className="mt-4 md:mt-0">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button>
                Actions <ChevronDown className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem asChild>
                <Link to="/withdraw" className="w-full cursor-pointer">
                  <Download className="mr-2 h-4 w-4" />
                  Withdraw
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link to="/deposit" className="w-full cursor-pointer">
                  <Upload className="mr-2 h-4 w-4" />
                  Deposit
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link to="/convert" className="w-full cursor-pointer">
                  <ArrowRightLeft className="mr-2 h-4 w-4" />
                  Convert
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link to="/history" className="w-full cursor-pointer">
                  <History className="mr-2 h-4 w-4" />
                  History
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      {/* Stats row */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mt-6">
        <StatCard
          title="Available Balance"
          value={`${user.balance} credits`}
          icon={<WalletIcon className="h-4 w-4" />}
          description="Updated just now"
        />
        
        <StatCard
          title="Tasks Performed"
          value={user.tasksCompleted}
          icon={<CheckCircle className="h-4 w-4" />}
          description="Completed tasks"
        />
        
        <StatCard
          title="Total Withdrawals"
          value={`${user.totalWithdrawals} credits`}
          icon={<Download className="h-4 w-4" />}
          description="All time"
        />
        
        <StatCard
          title="Premium Balance"
          value={`${user.premiumBalance} credits`}
          icon={<CreditCard className="h-4 w-4" />}
          description="Premium earnings"
          className={user.isPremium ? "border-premium" : ""}
        />
      </div>
      
      {/* Wallet Addresses */}
      <div className="mt-10">
        <h2 className="text-2xl font-bold mb-4">Wallet Addresses</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {walletAddresses.map((wallet) => (
            <Card key={wallet.type}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {wallet.type === 'bitcoin' ? (
                      <Bitcoin className="h-5 w-5 text-amber-500" />
                    ) : (
                      <WalletIcon className="h-5 w-5" />
                    )}
                    <CardTitle>{wallet.name}</CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="bg-muted p-3 rounded-md overflow-hidden">
                  <p className="text-xs sm:text-sm font-mono truncate">{wallet.address}</p>
                </div>
                <div className="flex justify-between mt-4">
                  <Button size="sm" variant="outline" asChild>
                    <Link to={`/deposit?currency=${wallet.type}`}>
                      <Upload className="h-4 w-4 mr-2" />
                      Deposit
                    </Link>
                  </Button>
                  <Button size="sm" asChild>
                    <Link to={`/withdraw?currency=${wallet.type}`}>
                      <Download className="h-4 w-4 mr-2" />
                      Withdraw
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
          
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center h-full py-8">
              <Button variant="ghost" size="lg" className="h-20 w-20 rounded-full mb-4" asChild>
                <Link to="/add-wallet">
                  <WalletIcon className="h-10 w-10" />
                </Link>
              </Button>
              <p className="font-medium">Add New Wallet</p>
              <p className="text-sm text-muted-foreground">
                Connect a new cryptocurrency wallet
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Recent Transactions */}
      <div className="mt-10">
        <h2 className="text-2xl font-bold mb-4">Recent Transactions</h2>
        <Tabs defaultValue="all">
          <TabsList className="mb-4">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="deposits">Deposits</TabsTrigger>
            <TabsTrigger value="withdrawals">Withdrawals</TabsTrigger>
            <TabsTrigger value="conversions">Conversions</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all">
            <TransactionsList transactions={sortedTransactions} />
          </TabsContent>
          
          <TabsContent value="deposits">
            <TransactionsList 
              transactions={sortedTransactions.filter(t => t.type === 'deposit')} 
            />
          </TabsContent>
          
          <TabsContent value="withdrawals">
            <TransactionsList 
              transactions={sortedTransactions.filter(t => t.type === 'withdrawal')} 
            />
          </TabsContent>
          
          <TabsContent value="conversions">
            <TransactionsList 
              transactions={sortedTransactions.filter(t => t.type === 'conversion')} 
            />
          </TabsContent>
        </Tabs>
        
        <div className="text-center mt-6">
          <Button variant="outline" asChild>
            <Link to="/history">View Full History</Link>
          </Button>
        </div>
      </div>
    </div>
  );
};

interface TransactionsListProps {
  transactions: Array<any>;
}

const TransactionsList = ({ transactions }: TransactionsListProps) => {
  if (transactions.length === 0) {
    return (
      <Card>
        <CardContent className="py-10 text-center">
          <History className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
          <h3 className="text-lg font-medium mb-1">No transactions found</h3>
          <p className="text-muted-foreground">Make your first transaction to see it here</p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardContent className="p-0">
        <div className="divide-y">
          {transactions.map((transaction) => (
            <div key={transaction.id} className="flex justify-between items-center p-4">
              <div className="flex items-start gap-3">
                {transaction.type === 'deposit' ? (
                  <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center text-green-600">
                    <Upload className="h-5 w-5" />
                  </div>
                ) : transaction.type === 'withdrawal' ? (
                  <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600">
                    <Download className="h-5 w-5" />
                  </div>
                ) : (
                  <div className="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center text-purple-600">
                    <ArrowRightLeft className="h-5 w-5" />
                  </div>
                )}
                
                <div>
                  <p className="font-medium">
                    {transaction.type === 'deposit'
                      ? 'Deposit'
                      : transaction.type === 'withdrawal'
                      ? 'Withdrawal'
                      : 'Conversion'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {transaction.currency.toUpperCase()}
                    {transaction.type === 'conversion' && 
                      ` → ${transaction.toCurrency.toUpperCase()}`}
                  </p>
                </div>
              </div>
              
              <div className="text-right">
                <div className="flex items-center justify-end">
                  <p className="font-medium">
                    {transaction.type === 'deposit' ? '+' : transaction.type === 'withdrawal' ? '-' : ''}
                    {transaction.amount} {transaction.currency === 'credits' ? 'credits' : transaction.currency}
                  </p>
                  
                  <div className="ml-2">
                    {transaction.status === 'pending' ? (
                      <span className="inline-flex items-center rounded-full bg-yellow-50 px-2 py-1 text-xs font-medium text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-500">
                        <Clock className="mr-1 h-3 w-3" />
                        Pending
                      </span>
                    ) : transaction.status === 'completed' ? (
                      <span className="inline-flex items-center rounded-full bg-green-50 px-2 py-1 text-xs font-medium text-green-700 dark:bg-green-900/30 dark:text-green-500">
                        <CheckCircle className="mr-1 h-3 w-3" />
                        Completed
                      </span>
                    ) : (
                      <span className="inline-flex items-center rounded-full bg-red-50 px-2 py-1 text-xs font-medium text-red-700 dark:bg-red-900/30 dark:text-red-500">
                        Rejected
                      </span>
                    )}
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  {transaction.date.toLocaleDateString()}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default WalletPage;


import { useState } from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useTask, Task } from '@/contexts/TaskContext';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Video, Newspaper, CheckCircle, ExternalLink } from 'lucide-react';

interface TaskCardProps {
  task: Task;
  compact?: boolean;
}

const TaskCard = ({ task, compact = false }: TaskCardProps) => {
  const [verifying, setVerifying] = useState(false);
  const { completeTask, isTaskCompleted } = useTask();
  const { user } = useAuth();
  
  const taskCompleted = isTaskCompleted(task.id);
  
  const handleViewTask = () => {
    window.open(task.url, '_blank');
  };
  
  const handleVerifyTask = async () => {
    if (!user) {
      toast.error('Please log in to complete tasks');
      return;
    }
    
    try {
      setVerifying(true);
      await completeTask(task.id);
    } catch (error) {
      console.error('Error completing task:', error);
      toast.error('Failed to verify task completion');
    } finally {
      setVerifying(false);
    }
  };
  
  if (compact) {
    return (
      <Card className={`task-card ${taskCompleted ? 'bg-muted/40' : ''}`}>
        <CardHeader className="p-4 pb-2">
          <div className="flex justify-between items-start">
            <CardTitle className="text-sm line-clamp-1">{task.title}</CardTitle>
            <Badge variant={task.type === 'video' ? 'default' : 'secondary'} className="h-5">
              {task.type === 'video' ? (
                <Video className="h-3 w-3 mr-1" />
              ) : (
                <Newspaper className="h-3 w-3 mr-1" />
              )}
              {task.type}
            </Badge>
          </div>
        </CardHeader>
        <CardFooter className="p-4 pt-2 flex justify-between">
          <div className="text-xs text-muted-foreground">
            Reward: <span className="font-semibold">{task.reward} credits</span>
          </div>
          {taskCompleted ? (
            <Badge variant="outline" className="text-green-500 border-green-500">
              <CheckCircle className="h-3 w-3 mr-1" />
              Completed
            </Badge>
          ) : (
            <Button size="sm" variant="ghost" onClick={handleViewTask}>
              View
            </Button>
          )}
        </CardFooter>
      </Card>
    );
  }
  
  return (
    <Card className={`task-card ${taskCompleted ? 'bg-muted/40' : ''}`}>
      <div className="aspect-video overflow-hidden relative">
        <img 
          src={task.thumbnail} 
          alt={task.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-2 right-2">
          <Badge variant={task.type === 'video' ? 'default' : 'secondary'}>
            {task.type === 'video' ? (
              <Video className="h-3 w-3 mr-1" />
            ) : (
              <Newspaper className="h-3 w-3 mr-1" />
            )}
            {task.type}
          </Badge>
        </div>
        {taskCompleted && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/30">
            <Badge className="text-lg bg-green-500 hover:bg-green-600">
              <CheckCircle className="h-5 w-5 mr-2" />
              Completed
            </Badge>
          </div>
        )}
      </div>
      <CardHeader className="p-4 pb-2">
        <CardTitle className="text-lg">{task.title}</CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-0 pb-2">
        <p className="text-sm text-muted-foreground line-clamp-2">{task.description}</p>
        <div className="mt-3 text-sm">
          Reward: <span className="font-semibold">{task.reward} credits</span>
          {user?.isPremium && (
            <span className="text-premium ml-1">
              (x{user.isPremium ? '2' : '1'} as Premium)
            </span>
          )}
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-2 flex gap-2 justify-end">
        {taskCompleted ? (
          <Button disabled variant="outline" className="w-full">
            <CheckCircle className="h-4 w-4 mr-2" />
            Completed
          </Button>
        ) : (
          <>
            <Button onClick={handleViewTask} variant="outline">
              <ExternalLink className="h-4 w-4 mr-2" />
              View
            </Button>
            <Button 
              onClick={handleVerifyTask} 
              disabled={verifying}
              className="flex-1"
            >
              {verifying ? 'Verifying...' : 'Verify Completion'}
            </Button>
          </>
        )}
      </CardFooter>
    </Card>
  );
};

export default TaskCard;

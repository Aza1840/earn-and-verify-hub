
import { useAuth } from '@/contexts/AuthContext';
import { useSiteSettings } from '@/contexts/SiteSettingsContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { CheckCircle, Diamond } from 'lucide-react';

const PremiumBanner = () => {
  const { user } = useAuth();
  const { settings } = useSiteSettings();
  
  if (!user || user.isPremium) {
    return null;
  }
  
  return (
    <Card className="relative overflow-hidden border-2 border-premium">
      <div className="absolute top-0 right-0 w-24 h-24 -mt-8 -mr-8 bg-gradient-to-br from-premium-light to-premium rotate-45" />
      <div className="p-6 flex flex-col sm:flex-row justify-between gap-4 items-center">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <Diamond className="h-5 w-5 text-premium" />
            <h3 className="font-bold text-xl">Upgrade to Premium</h3>
          </div>
          <p className="text-sm mt-2 text-muted-foreground">
            Unlock premium benefits and earn {settings.premiumMultiplier}x rewards on all completed tasks!
          </p>
          
          <ul className="mt-3 space-y-1">
            <li className="flex items-center text-sm">
              <CheckCircle className="h-4 w-4 mr-2 text-premium" />
              <span>{settings.premiumMultiplier}x earning multiplier on all tasks</span>
            </li>
            <li className="flex items-center text-sm">
              <CheckCircle className="h-4 w-4 mr-2 text-premium" />
              <span>Priority withdrawal processing</span>
            </li>
            <li className="flex items-center text-sm">
              <CheckCircle className="h-4 w-4 mr-2 text-premium" />
              <span>Access to exclusive premium tasks</span>
            </li>
          </ul>
        </div>
        <div className="flex flex-col gap-2 sm:items-end">
          <Button className="bg-premium hover:bg-premium-dark" asChild>
            <Link to="/upgrade">
              <Diamond className="h-4 w-4 mr-2" />
              Upgrade Now
            </Link>
          </Button>
          <div className="text-xs text-center sm:text-right text-muted-foreground mt-1">
            Only {user.balance} credits needed to upgrade
          </div>
        </div>
      </div>
    </Card>
  );
};

export default PremiumBanner;


import { Link } from 'react-router-dom';
import { useSiteSettings } from '@/contexts/SiteSettingsContext';

const Footer = () => {
  const { settings } = useSiteSettings();
  
  return (
    <footer className="bg-white dark:bg-gray-900 border-t mt-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand column */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <img src={settings.logo} alt={settings.siteName} className="h-8 w-auto" />
              <span className="font-bold text-xl">{settings.siteName}</span>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Complete tasks, earn rewards, and withdraw to your preferred cryptocurrency.
            </p>
          </div>
          
          {/* Links column */}
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/" className="text-gray-600 dark:text-gray-400 hover:text-primary">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-600 dark:text-gray-400 hover:text-primary">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-gray-600 dark:text-gray-400 hover:text-primary">
                  FAQ
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-gray-600 dark:text-gray-400 hover:text-primary">
                  Terms &amp; Conditions
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="text-gray-600 dark:text-gray-400 hover:text-primary">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Contact column */}
          <div>
            <h3 className="font-semibold mb-4">Contact Us</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
              Have questions? Reach out to us!
            </p>
            <a 
              href={`mailto:${settings.contactEmail}`}
              className="text-sm text-primary hover:underline"
            >
              {settings.contactEmail}
            </a>
            
            {/* Social links */}
            <div className="flex gap-4 mt-4">
              <a 
                href={settings.socialLinks.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-600 dark:text-gray-400 hover:text-primary"
              >
                Facebook
              </a>
              <a 
                href={settings.socialLinks.twitter}
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-600 dark:text-gray-400 hover:text-primary"
              >
                Twitter
              </a>
              <a 
                href={settings.socialLinks.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-600 dark:text-gray-400 hover:text-primary"
              >
                Instagram
              </a>
            </div>
          </div>
        </div>
        
        {/* Bottom text */}
        <div className="border-t mt-8 pt-6 text-center text-sm text-gray-600 dark:text-gray-400">
          {settings.footerText}
        </div>
      </div>
    </footer>
  );
};

export default Footer;

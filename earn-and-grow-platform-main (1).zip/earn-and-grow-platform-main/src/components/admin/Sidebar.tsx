
import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAuth } from '@/contexts/AuthContext';
import { useSiteSettings } from '@/contexts/SiteSettingsContext';
import {
  LayoutDashboard,
  Users,
  Video,
  Mail,
  Upload,
  Download,
  Settings,
  User,
  FileCheck,
  Database,
  ListChecks,
  UserCog,
  ChevronLeft,
  ChevronRight,
  Newspaper,
  Settings2
} from 'lucide-react';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

const Sidebar = ({ collapsed, onToggle }: SidebarProps) => {
  const { user } = useAuth();
  const { settings } = useSiteSettings();
  const location = useLocation();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!user || user.role !== 'admin') {
    return null;
  }

  return (
    <div
      className={cn(
        'relative h-screen border-r bg-sidebar text-sidebar-foreground transition-all duration-300',
        collapsed ? 'w-16' : 'w-64'
      )}
    >
      {/* Toggle button */}
      <Button
        variant="outline"
        size="icon"
        className="absolute -right-3 top-6 z-10 h-6 w-6 rounded-full border shadow-sm hidden md:flex"
        onClick={onToggle}
      >
        {collapsed ? (
          <ChevronRight className="h-3 w-3" />
        ) : (
          <ChevronLeft className="h-3 w-3" />
        )}
      </Button>

      {/* Header */}
      <div className={cn(
        'flex h-16 items-center border-b px-4',
        collapsed ? 'justify-center' : 'justify-between'
      )}>
        {collapsed ? (
          <Link to="/admin" className="flex items-center justify-center">
            <img src={settings.logo} alt="Logo" className="h-10 w-10" />
          </Link>
        ) : (
          <Link to="/admin" className="flex items-center gap-2">
            <img src={settings.logo} alt="Logo" className="h-10 w-10" />
            <span className="font-semibold">{settings.siteName} Admin</span>
          </Link>
        )}
      </div>

      {/* Sidebar content */}
      <ScrollArea className="h-[calc(100vh-4rem)]">
        <div className={cn('flex flex-col gap-1 p-2')}>
          {/* User section */}
          <div className={cn(
            'flex items-center mb-4 rounded-md p-2',
            collapsed ? 'justify-center' : 'px-3'
          )}>
            {user.profileImage ? (
              <img
                src={user.profileImage}
                alt={user.name}
                className="h-10 w-10 rounded-full"
              />
            ) : (
              <div className="h-10 w-10 rounded-full bg-sidebar-accent flex items-center justify-center">
                <User className="h-6 w-6" />
              </div>
            )}
            {!collapsed && (
              <div className="ml-2 overflow-hidden">
                <p className="truncate font-medium text-sm">{user.name}</p>
                <p className="truncate text-xs text-sidebar-foreground/70">Administrator</p>
              </div>
            )}
          </div>

          {/* Navigation items */}
          <NavItem
            to="/admin"
            icon={<LayoutDashboard className="h-5 w-5" />}
            label="Dashboard"
            collapsed={collapsed}
            current={location.pathname === '/admin'}
          />

          <NavItem
            to="/admin/videos"
            icon={<Video className="h-5 w-5" />}
            label="Videos"
            collapsed={collapsed}
            current={location.pathname === '/admin/videos'}
          />
          
          <NavItem
            to="/admin/news"
            icon={<Newspaper className="h-5 w-5" />}
            label="News"
            collapsed={collapsed}
            current={location.pathname === '/admin/news'}
          />

          <NavItem
            to="/admin/users"
            icon={<Users className="h-5 w-5" />}
            label="Manage Users"
            collapsed={collapsed}
            current={location.pathname === '/admin/users'}
          />

          <NavItem
            to="/admin/email"
            icon={<Mail className="h-5 w-5" />}
            label="Email Services"
            collapsed={collapsed}
            current={location.pathname === '/admin/email'}
          />

          <NavItem
            to="/admin/email-config"
            icon={<Settings2 className="h-5 w-5" />}
            label="Email Config"
            collapsed={collapsed}
            current={location.pathname === '/admin/email-config'}
          />

          <NavItem
            to="/admin/kyc"
            icon={<FileCheck className="h-5 w-5" />}
            label="KYC Applications"
            collapsed={collapsed}
            current={location.pathname === '/admin/kyc'}
          />

          <NavItem
            to="/admin/deposits"
            icon={<Upload className="h-5 w-5" />}
            label="Manage Deposits"
            collapsed={collapsed}
            current={location.pathname === '/admin/deposits'}
          />

          <NavItem
            to="/admin/withdrawals"
            icon={<Download className="h-5 w-5" />}
            label="Manage Withdrawals"
            collapsed={collapsed}
            current={location.pathname === '/admin/withdrawals'}
          />

          <NavItem
            to="/admin/accounts"
            icon={<Database className="h-5 w-5" />}
            label="Manage Accounts"
            collapsed={collapsed}
            current={location.pathname === '/admin/accounts'}
          />

          <NavItem
            to="/admin/tasks"
            icon={<ListChecks className="h-5 w-5" />}
            label="Tasks"
            collapsed={collapsed}
            current={location.pathname === '/admin/tasks'}
          />

          <NavItem
            to="/admin/administrators"
            icon={<UserCog className="h-5 w-5" />}
            label="Administrators"
            collapsed={collapsed}
            current={location.pathname === '/admin/administrators'}
          />

          <NavItem
            to="/admin/settings"
            icon={<Settings className="h-5 w-5" />}
            label="Settings"
            collapsed={collapsed}
            current={location.pathname === '/admin/settings'}
          />
        </div>
      </ScrollArea>
    </div>
  );
};

interface NavItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  collapsed: boolean;
  current: boolean;
}

const NavItem = ({ to, icon, label, collapsed, current }: NavItemProps) => {
  return (
    <Link
      to={to}
      className={cn(
        'flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors',
        current
          ? 'bg-sidebar-accent text-sidebar-accent-foreground'
          : 'text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground',
        collapsed ? 'justify-center px-0' : ''
      )}
    >
      {icon}
      {!collapsed && <span>{label}</span>}
    </Link>
  );
};

export default Sidebar;

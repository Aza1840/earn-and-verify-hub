
import React, { createContext, useState, useContext, useEffect } from 'react';

export interface SiteSettings {
  siteName: string;
  logo: string;
  favicon: string;
  theme: 'light' | 'dark';
  contactEmail: string;
  footerText: string;
  socialLinks: {
    facebook: string;
    twitter: string;
    instagram: string;
  };
  videoTaskReward: number;
  newsTaskReward: number;
  referralReward: number;
  premiumMultiplier: number;
  minimumWithdrawal: number;
  videoTaskDuration: number;
}

interface SiteSettingsContextType {
  settings: SiteSettings;
  updateSettings: (updates: Partial<SiteSettings>) => void;
  toggleTheme: () => void;
}

const SiteSettingsContext = createContext<SiteSettingsContextType | undefined>(undefined);

// Default site settings
const defaultSettings: SiteSettings = {
  siteName: 'EarnRewards',
  logo: '/placeholder.svg',
  favicon: '/favicon.ico',
  theme: 'light',
  contactEmail: 'contact@earnrewards.com',
  footerText: '© 2025 EarnRewards. All rights reserved.',
  socialLinks: {
    facebook: 'https://facebook.com/',
    twitter: 'https://twitter.com/',
    instagram: 'https://instagram.com/'
  },
  videoTaskReward: 10,
  newsTaskReward: 5,
  referralReward: 20,
  premiumMultiplier: 2,
  minimumWithdrawal: 100,
  videoTaskDuration: 60 // seconds
};

export const SiteSettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<SiteSettings>(() => {
    const savedSettings = localStorage.getItem('site_settings');
    return savedSettings ? JSON.parse(savedSettings) : defaultSettings;
  });

  useEffect(() => {
    localStorage.setItem('site_settings', JSON.stringify(settings));
    
    // Apply theme
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    
    // Apply favicon
    const faviconLink = document.querySelector("link[rel*='icon']") || document.createElement('link');
    faviconLink.setAttribute('rel', 'shortcut icon');
    faviconLink.setAttribute('href', settings.favicon);
    document.head.appendChild(faviconLink);
    
    // Update document title
    document.title = settings.siteName;
  }, [settings]);

  const updateSettings = (updates: Partial<SiteSettings>) => {
    setSettings(prev => ({
      ...prev,
      ...updates
    }));
  };

  const toggleTheme = () => {
    setSettings(prev => ({
      ...prev,
      theme: prev.theme === 'light' ? 'dark' : 'light'
    }));
  };

  return (
    <SiteSettingsContext.Provider value={{ settings, updateSettings, toggleTheme }}>
      {children}
    </SiteSettingsContext.Provider>
  );
};

export const useSiteSettings = () => {
  const context = useContext(SiteSettingsContext);
  if (context === undefined) {
    throw new Error('useSiteSettings must be used within a SiteSettingsProvider');
  }
  return context;
};


import React, { createContext, useState, useContext, useEffect } from 'react';
import { toast } from 'sonner';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  profileImage?: string;
  isPremium: boolean;
  balance: number;
  premiumBalance: number;
  totalWithdrawals: number;
  tasksCompleted: number;
  pendingDeposits: number;
  pendingWithdrawals: number;
  referrals: number;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  register: (name: string, email: string, password: string) => Promise<void>;
  updateUserProfile: (updates: Partial<User>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users for demo
const mockUsers: User[] = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@example.com',
    role: 'admin',
    profileImage: 'https://i.pravatar.cc/150?img=1',
    isPremium: true,
    balance: 5000,
    premiumBalance: 2500,
    totalWithdrawals: 1000,
    tasksCompleted: 75,
    pendingDeposits: 250,
    pendingWithdrawals: 500,
    referrals: 10
  },
  {
    id: '2',
    name: 'Test User',
    email: 'user@example.com',
    role: 'user',
    profileImage: 'https://i.pravatar.cc/150?img=2',
    isPremium: false,
    balance: 250,
    premiumBalance: 0,
    totalWithdrawals: 100,
    tasksCompleted: 25,
    pendingDeposits: 50,
    pendingWithdrawals: 0,
    referrals: 2
  }
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored user in localStorage (simulating session)
    const storedUser = localStorage.getItem('earnrewards_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Find user by email (mock login)
      const foundUser = mockUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
      
      if (foundUser) {
        // In a real app, you'd verify the password here
        setUser(foundUser);
        localStorage.setItem('earnrewards_user', JSON.stringify(foundUser));
        toast.success(`Welcome back, ${foundUser.name}!`);
      } else {
        toast.error('Invalid email or password');
        throw new Error('Invalid credentials');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('earnrewards_user');
    setUser(null);
    toast.success('Logged out successfully');
  };

  const register = async (name: string, email: string, password: string) => {
    setIsLoading(true);
    
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if user already exists
      const userExists = mockUsers.some(u => u.email.toLowerCase() === email.toLowerCase());
      
      if (userExists) {
        toast.error('Email already in use');
        throw new Error('Email already in use');
      }
      
      // Create new user (in a real app, this would be an API call)
      const newUser: User = {
        id: (mockUsers.length + 1).toString(),
        name,
        email,
        role: 'user',
        isPremium: false,
        balance: 0,
        premiumBalance: 0,
        totalWithdrawals: 0,
        tasksCompleted: 0,
        pendingDeposits: 0,
        pendingWithdrawals: 0,
        referrals: 0
      };
      
      mockUsers.push(newUser);
      
      // Auto login after registration
      setUser(newUser);
      localStorage.setItem('earnrewards_user', JSON.stringify(newUser));
      toast.success('Registration successful!');
    } finally {
      setIsLoading(false);
    }
  };

  const updateUserProfile = async (updates: Partial<User>) => {
    setIsLoading(true);
    
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      if (user) {
        const updatedUser = {...user, ...updates};
        setUser(updatedUser);
        localStorage.setItem('earnrewards_user', JSON.stringify(updatedUser));
        toast.success('Profile updated successfully');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider 
      value={{ 
        user, 
        isAuthenticated: !!user, 
        isLoading,
        login,
        logout,
        register,
        updateUserProfile
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};


import React, { createContext, useState, useContext, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { toast } from 'sonner';
import { useSiteSettings } from './SiteSettingsContext';

export interface Task {
  id: string;
  type: 'video' | 'news';
  title: string;
  description: string;
  thumbnail: string;
  url: string;
  reward: number;
  createdAt: Date;
}

interface TaskContextType {
  tasks: Task[];
  completedTasks: string[];
  createTask: (task: Omit<Task, 'id' | 'createdAt'>) => void;
  updateTask: (id: string, task: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  completeTask: (taskId: string) => Promise<void>;
  isTaskCompleted: (taskId: string) => boolean;
}

const TaskContext = createContext<TaskContextType | undefined>(undefined);

// Initial mock tasks
const initialTasks: Task[] = [
  {
    id: '1',
    type: 'video',
    title: 'How to Earn Online - Beginner Guide',
    description: 'Learn the basics of earning money online with simple tasks.',
    thumbnail: 'https://i.ytimg.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
    url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    reward: 10,
    createdAt: new Date('2025-05-10')
  },
  {
    id: '2',
    type: 'video',
    title: 'Advanced Online Earning Techniques',
    description: 'Take your online earnings to the next level with these tips.',
    thumbnail: 'https://i.ytimg.com/vi/jNQXAC9IVRw/maxresdefault.jpg',
    url: 'https://www.youtube.com/watch?v=jNQXAC9IVRw',
    reward: 15,
    createdAt: new Date('2025-05-11')
  },
  {
    id: '3',
    type: 'news',
    title: 'New Opportunities in Online Earning',
    description: 'Recent developments have created new ways to earn online.',
    thumbnail: 'https://images.unsplash.com/photo-1508385082359-f38ae991e8f2',
    url: '/news/new-opportunities',
    reward: 5,
    createdAt: new Date('2025-05-12')
  },
  {
    id: '4',
    type: 'news',
    title: 'Crypto Earning Guide for Beginners',
    description: 'Start earning cryptocurrency with this simple guide.',
    thumbnail: 'https://images.unsplash.com/photo-1621761191319-c6fb62004040',
    url: '/news/crypto-guide',
    reward: 8,
    createdAt: new Date('2025-05-13')
  },
  {
    id: '5',
    type: 'video',
    title: 'Maximize Your Referral Earnings',
    description: 'Learn how to effectively use referral programs to boost your earnings.',
    thumbnail: 'https://i.ytimg.com/vi/xvFZjo5PgG0/maxresdefault.jpg',
    url: 'https://www.youtube.com/watch?v=xvFZjo5PgG0',
    reward: 12,
    createdAt: new Date('2025-05-14')
  }
];

export const TaskProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [completedTasks, setCompletedTasks] = useState<string[]>(() => {
    const stored = localStorage.getItem('completedTasks');
    return stored ? JSON.parse(stored) : [];
  });
  
  const { user, updateUserProfile } = useAuth();
  const { settings } = useSiteSettings();

  useEffect(() => {
    localStorage.setItem('completedTasks', JSON.stringify(completedTasks));
  }, [completedTasks]);

  const createTask = (task: Omit<Task, 'id' | 'createdAt'>) => {
    const newTask: Task = {
      ...task,
      id: Math.random().toString(36).substring(2, 11),
      createdAt: new Date()
    };
    
    setTasks(prev => [newTask, ...prev]);
  };

  const updateTask = (id: string, taskUpdates: Partial<Task>) => {
    setTasks(prev => 
      prev.map(task => 
        task.id === id ? { ...task, ...taskUpdates } : task
      )
    );
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(task => task.id !== id));
  };

  const completeTask = async (taskId: string) => {
    if (!user) {
      toast.error('You need to be logged in to complete tasks');
      throw new Error('Authentication required');
    }
    
    if (completedTasks.includes(taskId)) {
      toast.error('You have already completed this task');
      return;
    }
    
    // Find the task
    const task = tasks.find(t => t.id === taskId);
    if (!task) {
      toast.error('Task not found');
      return;
    }
    
    // Simulate verification delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Calculate reward based on user's premium status
    const multiplier = user.isPremium ? settings.premiumMultiplier : 1;
    const earnedReward = task.reward * multiplier;
    
    // Update completed tasks
    setCompletedTasks(prev => [...prev, taskId]);
    
    // Update user stats
    await updateUserProfile({
      balance: user.balance + earnedReward,
      tasksCompleted: user.tasksCompleted + 1,
      premiumBalance: user.isPremium ? user.premiumBalance + earnedReward : user.premiumBalance
    });
    
    toast.success(`Task completed! Earned ${earnedReward} credits.`);
  };

  const isTaskCompleted = (taskId: string) => {
    return completedTasks.includes(taskId);
  };

  return (
    <TaskContext.Provider 
      value={{
        tasks,
        completedTasks,
        createTask,
        updateTask,
        deleteTask,
        completeTask,
        isTaskCompleted
      }}
    >
      {children}
    </TaskContext.Provider>
  );
};

export const useTask = () => {
  const context = useContext(TaskContext);
  if (context === undefined) {
    throw new Error('useTask must be used within a TaskProvider');
  }
  return context;
};


import React, { createContext, useState, useContext } from 'react';
import { useAuth } from './AuthContext';
import { toast } from 'sonner';

export type CryptoType = 'bitcoin' | 'ethereum' | 'usdt' | 'solana' | 'ada' | 'avax' | 'doge' | 'ton';

export interface WalletAddress {
  type: CryptoType;
  address: string;
  name: string;
  icon: string;
}

export interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal' | 'conversion';
  amount: number;
  currency: CryptoType | 'credits';
  toCurrency?: CryptoType | 'credits';
  status: 'pending' | 'completed' | 'rejected';
  date: Date;
  walletAddress?: string;
}

interface WalletContextType {
  walletAddresses: WalletAddress[];
  transactions: Transaction[];
  addWalletAddress: (wallet: Omit<WalletAddress, 'id'>) => void;
  requestWithdrawal: (amount: number, currency: CryptoType | 'credits', walletAddress?: string) => Promise<void>;
  requestDeposit: (amount: number, currency: CryptoType) => Promise<void>;
  convertCurrency: (fromAmount: number, fromCurrency: CryptoType | 'credits', toCurrency: CryptoType | 'credits') => Promise<void>;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

// Sample wallet addresses and transactions
const defaultWalletAddresses: WalletAddress[] = [
  {
    type: 'bitcoin',
    address: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
    name: 'Bitcoin',
    icon: 'bitcoin'
  },
  {
    type: 'ethereum',
    address: '0x742d35Cc6634C0532925a3b844Bc454e4438f44e',
    name: 'Ethereum',
    icon: 'ethereum'
  },
  {
    type: 'usdt',
    address: '0x742d35Cc6634C0532925a3b844Bc454e4438f44e',
    name: 'USDT',
    icon: 'usdt'
  }
];

const sampleTransactions: Transaction[] = [
  {
    id: '1',
    type: 'deposit',
    amount: 100,
    currency: 'usdt',
    status: 'completed',
    date: new Date('2025-05-01')
  },
  {
    id: '2',
    type: 'withdrawal',
    amount: 50,
    currency: 'bitcoin',
    status: 'pending',
    date: new Date('2025-05-10'),
    walletAddress: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa'
  },
  {
    id: '3',
    type: 'conversion',
    amount: 200,
    currency: 'credits',
    toCurrency: 'ethereum',
    status: 'completed',
    date: new Date('2025-05-08')
  }
];

export const WalletProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [walletAddresses, setWalletAddresses] = useState<WalletAddress[]>(defaultWalletAddresses);
  const [transactions, setTransactions] = useState<Transaction[]>(sampleTransactions);
  const { user, updateUserProfile } = useAuth();

  const addWalletAddress = (wallet: Omit<WalletAddress, 'id'>) => {
    // Check if this type of wallet already exists
    const exists = walletAddresses.some(w => w.type === wallet.type);
    
    if (exists) {
      // Update existing wallet
      setWalletAddresses(prev => 
        prev.map(w => w.type === wallet.type ? { ...w, ...wallet } : w)
      );
      toast.success(`${wallet.name} wallet address updated`);
    } else {
      // Add new wallet
      setWalletAddresses(prev => [...prev, wallet]);
      toast.success(`${wallet.name} wallet address added`);
    }
  };

  const requestWithdrawal = async (amount: number, currency: CryptoType | 'credits', walletAddress?: string) => {
    if (!user) {
      toast.error('You must be logged in to request a withdrawal');
      return;
    }

    // For credits, check user balance
    if (currency === 'credits') {
      if (user.balance < amount) {
        toast.error('Insufficient balance for withdrawal');
        return;
      }
    }

    // Create new transaction
    const newTransaction: Transaction = {
      id: Math.random().toString(36).substring(2, 11),
      type: 'withdrawal',
      amount,
      currency,
      status: 'pending',
      date: new Date(),
      walletAddress
    };

    setTransactions(prev => [newTransaction, ...prev]);

    // Update user's pending withdrawals
    if (currency === 'credits') {
      await updateUserProfile({
        balance: user.balance - amount,
        pendingWithdrawals: user.pendingWithdrawals + amount
      });
    }

    toast.success('Withdrawal request submitted');
  };

  const requestDeposit = async (amount: number, currency: CryptoType) => {
    if (!user) {
      toast.error('You must be logged in to make a deposit');
      return;
    }

    // Create new transaction
    const newTransaction: Transaction = {
      id: Math.random().toString(36).substring(2, 11),
      type: 'deposit',
      amount,
      currency,
      status: 'pending',
      date: new Date()
    };

    setTransactions(prev => [newTransaction, ...prev]);

    // Update user's pending deposits
    await updateUserProfile({
      pendingDeposits: user.pendingDeposits + amount
    });

    toast.success('Deposit request submitted');
  };

  const convertCurrency = async (
    fromAmount: number, 
    fromCurrency: CryptoType | 'credits', 
    toCurrency: CryptoType | 'credits'
  ) => {
    if (!user) {
      toast.error('You must be logged in to convert currency');
      return;
    }

    // Check if user has sufficient balance for credits conversion
    if (fromCurrency === 'credits' && user.balance < fromAmount) {
      toast.error('Insufficient balance for conversion');
      return;
    }

    // Create new transaction
    const newTransaction: Transaction = {
      id: Math.random().toString(36).substring(2, 11),
      type: 'conversion',
      amount: fromAmount,
      currency: fromCurrency,
      toCurrency,
      status: 'completed', // Instant conversion for demo
      date: new Date()
    };

    setTransactions(prev => [newTransaction, ...prev]);

    // Handle credits conversion
    if (fromCurrency === 'credits') {
      await updateUserProfile({
        balance: user.balance - fromAmount
      });
    }
    
    if (toCurrency === 'credits') {
      // Simple 1:1 conversion for demo
      await updateUserProfile({
        balance: user.balance + fromAmount
      });
    }

    toast.success('Currency converted successfully');
  };

  return (
    <WalletContext.Provider
      value={{
        walletAddresses,
        transactions,
        addWalletAddress,
        requestWithdrawal,
        requestDeposit,
        convertCurrency
      }}
    >
      {children}
    </WalletContext.Provider>
  );
};

export const useWallet = () => {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};
